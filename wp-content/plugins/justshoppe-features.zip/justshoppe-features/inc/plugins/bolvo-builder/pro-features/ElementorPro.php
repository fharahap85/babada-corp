<?php
/**
 * Version: 3.4.1
 */
namespace Bolvo_Builder\ElementorPro;

use Elementor\Utils;

class ElementorPro {

  protected static $instance = null;

  public static function get_instance() {
    if(self::$instance === null) {
      self::$instance = new self();
    }
    return self::$instance;
  }

  /**
   * ProFeatures constructor.
   */
  public function __construct() {
    spl_autoload_register( [ $this, 'autoload' ] );
    Modules\Forms\Module::instance();
    Modules\Gallery\Module::instance();

    if ( !defined( 'ELEMENTOR_PRO_VERSION' ) ) {
      Modules\GlobalWidget\Module::instance();
      Modules\Library\Module::instance();
      Modules\QueryControl\Module::instance();
      Modules\AssetsManager\Module::instance();
      Modules\CustomCss\Module::instance();
      Modules\MotionFX\Module::instance();
    }

    add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
    add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'editor_enqueue_scripts' ] );
    add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'enqueue_frontend_styles' ] );
    add_action( 'elementor/frontend/before_enqueue_scripts', [ $this, 'enqueue_frontend_scripts' ] );
    add_action( 'elementor/preview/enqueue_scripts', [ $this, 'register_preview_scripts' ] );
    add_action( 'elementor/preview/enqueue_styles', [ $this, 'preview_enqueue_styles' ] );
    add_filter( 'bolvo_builder_pro_features_settings', [ $this, 'localize_settings' ] );
  }

  public function localize_settings( array $settings ) {
    $settings = array_replace_recursive( $settings, [
      'i18n' => [
        // 'edit_element' is here for Backwards Compatibility for Elementor Pro versions <3.1.0
        'edit_element' => __( 'Edit %s', 'elementor-pro' ),
      ],
    ] );
    return $settings;
  }

  public function preview_enqueue_styles() {
    /* bolvo */
    wp_enqueue_style(
      BLVB_PREFIX . '-bolvo-preview',
      BLVB_URL . '/pro-features/assets/css/preview.css',
      [],
      BLVB_VERSION
    );
  }

  public function register_preview_scripts() {
    wp_enqueue_script(
      BLVB_PREFIX . 'bolvo-preview',
      BLVB_URL . '/pro-features/assets/js/preview.js',
      [
        'elementor-frontend',
      ],
      BLVB_VERSION,
      true
    );
  }

  public function editor_enqueue_scripts() {
    wp_enqueue_style( BLVB_PREFIX . '-pro-features', BLVB_URL . '/pro-features/assets/css/editor.css', array(), BLVB_VERSION );
    wp_enqueue_script(BLVB_PREFIX . '-pro-features', BLVB_URL . '/pro-features/assets/js/editor.js', array('backbone-marionette', 'elementor-common', 'elementor-editor-modules', 'elementor-editor-document'), BLVB_VERSION, TRUE);

    wp_localize_script(
      'blvb-editor-scripts',
      'elementorBolvoEditorConfig',
      $this->add_templates_localize_data()
    );
  }

  public function enqueue_admin_scripts() {
	  wp_enqueue_script(BLVB_PREFIX . '-bolvo-admin-script', BLVB_URL . '/pro-features/assets/js/admin.js', ['elementor-common'], BLVB_VERSION, TRUE);
	  wp_enqueue_style(BLVB_PREFIX . '-bolvo-admin-style', BLVB_URL . '/pro-features/assets/css/admin.css', [], BLVB_VERSION);

	  Utils::print_js_config(
		  BLVB_PREFIX . '-bolvo-admin-script',
		  'ElementorBolvoConfig',
		  $this->add_admin_localize_data()
	  );
  }

  public function add_admin_localize_data() {
     return apply_filters( 'bolvo_builder_pro_features_settings', array() );
  }

  public function enqueue_frontend_styles() {
    wp_enqueue_style( BLVB_PREFIX . '-pro-features', BLVB_URL . '/pro-features/assets/css/frontend.css', array(), BLVB_VERSION );
  }

  public function enqueue_frontend_scripts() {
    wp_register_script( BLVB_PREFIX . '-pro-features-webpack-runtime', BLVB_URL . '/pro-features/assets/js/webpack-pro.runtime.js', [], BLVB_VERSION, true );
    wp_enqueue_script(BLVB_PREFIX . '-pro-features', BLVB_URL . '/pro-features/assets/js/frontend.js', [ BLVB_PREFIX . '-pro-features-webpack-runtime', 'elementor-frontend-modules' ], BLVB_VERSION, TRUE);
    wp_enqueue_script( BLVB_PREFIX . '-pro-features-preloaded-elements-handlers', BLVB_URL . '/pro-features/assets/js/preloaded-elements-handlers.js', [ 'elementor-frontend' ], BLVB_VERSION, true );

    $locale_settings = [
      'ajaxurl' => admin_url( 'admin-ajax.php' ),
      'nonce' => wp_create_nonce( 'elementor-bolvo-frontend' ),
      'urls' => [
        'assets' => BLVB_URL . '/pro-features/assets/',
      ],
    ];
    wp_localize_script(
      BLVB_PREFIX . '-pro-features',
      'ElementorBolvoFrontendConfig',
      $locale_settings
    );
  }

  public function add_templates_localize_data() {
    return apply_filters( 'bolvo_builder_pro_features_settings', array() );
  }

  public function autoload( $class ) {
    if ( 0 !== strpos( $class, __NAMESPACE__ ) ) {
      return;
    }

    if ( ! class_exists( $class ) ) {
      $filename = strtolower(
        preg_replace(
          [ '/^' . __NAMESPACE__ . '\\\/', '/([a-z])([A-Z])/', '/_/', '/\\\/' ],
          [ '', '$1-$2', '-', DIRECTORY_SEPARATOR ],
          str_replace(__NAMESPACE__, '', $class)
        )
      );
      $filename = BLVB_DIR . '/pro-features/' . $filename . '.php';
      if ( is_readable( $filename ) ) {
        include( $filename );
      }
    }
  }
}
