<?php
/**
 * Created by PhpStorm.
 * User: mher
 * Date: 8/23/18
 * Time: 11:05 AM
 */

namespace Bolvo_Builder;

class SelectAjax extends \Elementor\Control_Select2 {

  public function __construct(){
    parent::__construct();
  }

  public function get_type(){
    return "BLVBSelectAjax";
  }

  public function enqueue(){
    parent::enqueue();
    wp_enqueue_script('blvb-control-select-ajax', BLVB_URL . '/assets/editor/js/select-ajax.js', ['jquery'], BLVB_VERSION);
  }
}