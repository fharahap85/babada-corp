<?php
namespace Bolvo_Builder\DynamicTags\Tags;

use Elementor\Core\DynamicTags\Data_Tag;
use Elementor\Core\DynamicTags\Tag;

if(!defined('ABSPATH')) exit; // Exit if accessed directly

abstract class Bolvo_Tag extends Tag {

  const BOLVO_GROUP = 'bolvo';
  const BOLVO_CATEGORY = 'bolvo';

  public function get_group() {
    $tag_title = 'Bolvo Tags';
    if ( BOLVO_WHITE_LABEL ) {
      $tag_title = 'Tags';
    }
    return [
      self::BOLVO_GROUP => [
        'title' => __( $tag_title, 'justshoppe-features' ),
      ],
    ];
  }

  public function get_categories() {
    return [ self::BOLVO_CATEGORY ];
  }
}

abstract class Bolvo_DataTag extends Data_Tag {

  const BOLVO_GROUP = 'bolvo';
  const BOLVO_CATEGORY = 'bolvo';

  public function get_group() {
    $tag_title = 'Bolvo Tags';
    if ( BOLVO_WHITE_LABEL ) {
      $tag_title = 'Tags';
    }
    return [
      self::BOLVO_GROUP => [
        'title' => __( $tag_title, 'justshoppe-features' ),
      ],
    ];
  }

  public function get_categories() {
    return [ self::BOLVO_CATEGORY ];
  }
}