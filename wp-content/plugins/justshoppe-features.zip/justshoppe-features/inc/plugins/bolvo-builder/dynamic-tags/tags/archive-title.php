<?php
namespace Bolvo_Builder\DynamicTags\Tags;

if(!defined('ABSPATH')) exit; // Exit if accessed directly

use Elementor\Controls_Manager;
use Elementor\Core\DynamicTags\Tag;
use Bolvo_Builder\DynamicTags\Module;

class Archive_Title extends Tag {

  public function get_name() {
    return 'bolvo-tag-archive-title';
  }

  public function get_title() {
    return __( 'Archive Title/Description', 'justshoppe-features' );
  }

  public function get_group() {
    return Module::BOLVO_GROUP;
  }

  public function get_categories() {
    return [ Module::TEXT_CATEGORY ];
  }

  public function render() {
    $show_description = 'description' === $this->get_settings('show_description');
    if ( $show_description ) {
      $title = get_the_archive_description();
    }
    else {
      $include_context = 'yes' === $this->get_settings('include_context');
      $title = $this->get_the_archive_title($include_context);
    }
    if ( !$title ) {
      $title = __( 'Archive description', 'justshoppe-features' );
    }
    echo wp_kses_post( $title );
  }

  public function get_the_archive_title( $include_context = true ) {
    if ( is_search() ) {
      $title = sprintf( __( 'Search Results for: %s', 'justshoppe-features' ), get_search_query() );
    } elseif ( is_category() ) {
      $title = single_cat_title( '', false );

      if ( $include_context ) {
        $title = sprintf( __( 'Category: %s', 'justshoppe-features' ), $title );
      }
    } elseif ( is_tag() ) {
      $title = single_tag_title( '', false );
      if ( $include_context ) {
        $title = sprintf( __( 'Tag: %s', 'justshoppe-features' ), $title );
      }
    } elseif ( is_author() ) {
      $title = '<span class="vcard">' . get_the_author() . '</span>';

      if ( $include_context ) {
        $title = sprintf( __( 'Author: %s', 'justshoppe-features' ), $title );
      }
    } elseif ( is_year() ) {
      $title = get_the_date( _x( 'Y', 'yearly archives date format', 'justshoppe-features' ) );

      if ( $include_context ) {
        $title = sprintf( __( 'Year: %s', 'justshoppe-features' ), $title );
      }
    } elseif ( is_month() ) {
      $title = get_the_date( _x( 'F Y', 'monthly archives date format', 'justshoppe-features' ) );

      if ( $include_context ) {
        $title = sprintf( __( 'Month: %s', 'justshoppe-features' ), $title );
      }
    } elseif ( is_day() ) {
      $title = get_the_date( _x( 'F j, Y', 'daily archives date format', 'justshoppe-features' ) );

      if ( $include_context ) {
        $title = sprintf( __( 'Day: %s', 'justshoppe-features' ), $title );
      }
    } elseif ( is_tax( 'post_format' ) ) {
      if ( is_tax( 'post_format', 'post-format-aside' ) ) {
        $title = _x( 'Asides', 'post format archive title', 'justshoppe-features' );
      } elseif ( is_tax( 'post_format', 'post-format-gallery' ) ) {
        $title = _x( 'Galleries', 'post format archive title', 'justshoppe-features' );
      } elseif ( is_tax( 'post_format', 'post-format-image' ) ) {
        $title = _x( 'Images', 'post format archive title', 'justshoppe-features' );
      } elseif ( is_tax( 'post_format', 'post-format-video' ) ) {
        $title = _x( 'Videos', 'post format archive title', 'justshoppe-features' );
      } elseif ( is_tax( 'post_format', 'post-format-quote' ) ) {
        $title = _x( 'Quotes', 'post format archive title', 'justshoppe-features' );
      } elseif ( is_tax( 'post_format', 'post-format-link' ) ) {
        $title = _x( 'Links', 'post format archive title', 'justshoppe-features' );
      } elseif ( is_tax( 'post_format', 'post-format-status' ) ) {
        $title = _x( 'Statuses', 'post format archive title', 'justshoppe-features' );
      } elseif ( is_tax( 'post_format', 'post-format-audio' ) ) {
        $title = _x( 'Audio', 'post format archive title', 'justshoppe-features' );
      } elseif ( is_tax( 'post_format', 'post-format-chat' ) ) {
        $title = _x( 'Chats', 'post format archive title', 'justshoppe-features' );
      }
    } elseif ( is_post_type_archive() ) {
      $title = post_type_archive_title( '', false );

      if ( $include_context ) {
        $title = sprintf( __( 'Archives: %s', 'justshoppe-features' ), $title );
      }
    } elseif ( is_tax() ) {
      $title = single_term_title( '', false );

      if ( $include_context ) {
        $tax = get_taxonomy( get_queried_object()->taxonomy );
        $title = sprintf( __( '%1$s: %2$s', 'justshoppe-features' ), $tax->labels->singular_name, $title );
      }
    } else {
      $title = __( 'Archives', 'justshoppe-features' );
    }

    return $title;
  }

  protected function register_controls() {
    $this->add_control(
      'include_context',
      [
        'label'   => __( 'Include Context', 'justshoppe-features' ),
        'type' => Controls_Manager::SWITCHER,
        'default' => 'no',
      ]
    );
    $this->add_control(
      'show_description',
      [
        'label'   => __( 'Show', 'justshoppe-features' ),
        'type' => Controls_Manager::SELECT,
        'default' => 'title',
        'options' => [
          'title' => __( 'Title', 'justshoppe-features' ),
          'description' => __( 'Description', 'justshoppe-features' ),
        ],
      ]
    );
  }
}
