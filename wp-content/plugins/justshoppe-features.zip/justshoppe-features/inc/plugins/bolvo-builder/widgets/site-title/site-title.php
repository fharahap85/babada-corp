<?php

namespace Bolvo_Builder;

use Bolvo_Builder\DynamicTags\Module as TagsModule;
use Elementor\Widget_Heading;

if(!defined('ABSPATH')) exit; // Exit if accessed directly

class Site_Title extends Widget_Heading {

  public function get_name() {
    return 'bolvo-site-title';
  }

  public function get_title() {
    return __( 'Site Title', 'justshoppe-features' );
  }

  public function get_icon() {
    return 'blvb-site-title blvb-widget-icon';
  }

  public function get_categories() {
    return [ 'bolvo-builder-widgets' ];
  }

  protected function register_controls() {
    parent::register_controls();

    $this->update_control(
      'title',
      [
        'dynamic' => [
          'default' => \Elementor\Plugin::instance()->dynamic_tags->tag_data_to_tag_text( null, 'bolvo-tag-site-title' ),
        ],
      ],
      [
        'recursive' => true,
      ]
    );

    $this->update_control(
      'link',
      [
        'dynamic' => [
          'default' => \Elementor\Plugin::instance()->dynamic_tags->tag_data_to_tag_text( null, 'bolvo-tag-site-url' ),
        ],
      ],
      [
        'recursive' => true,
      ]
    );
  }

  protected function get_html_wrapper_class() {
    return parent::get_html_wrapper_class() . ' elementor-widget-' . parent::get_name();
  }
}

\Elementor\Plugin::instance()->widgets_manager->register(new Site_Title());
