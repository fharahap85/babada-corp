<?php
namespace Bolvo_Builder;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color as Scheme_Color;
use Elementor\Core\Schemes\Typography as Scheme_Typography;
use Elementor\Utils;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Countdown extends Widget_Base {

	public function get_name() {
		return Builder::$prefix . 'countdown';
	}

	public function get_title() {
		return __( 'Countdown', 'justshoppe-features' );
	}

	public function get_icon() {
		return 'blvb-countdown blvb-widget-icon';
	}

  public function get_categories(){
    return ['bolvo-widgets'];
  }

	protected function register_controls() {
		$this->start_controls_section(
			'section_countdown',
			[
				'label' => __( 'Countdown', 'justshoppe-features' ),
			]
		);

		$this->add_control(
			'due_date',
			[
				'label' => __( 'Due Date', 'justshoppe-features' ),
				'type' => Controls_Manager::DATE_TIME,
				'default' => date( 'Y-m-d H:i', $this->timestamp('+1 month') ),
				'description' => sprintf( __( 'Date set according to your timezone: %s.', 'justshoppe-features' ), Utils::get_timezone_string() ),
			]
		);

		$this->add_control(
			'layout',
			[
				'label' => __( 'Layout', 'justshoppe-features' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'squares' => __( 'Squares', 'justshoppe-features' ),
					'circles' => __( 'Circles', 'justshoppe-features' ),
					'inline' => __( 'Inline', 'justshoppe-features' ),
				],
				'default' => 'squares',
				'prefix_class' => 'bolvo-countdown--layout-',
			]
		);

    $this->add_control(
      'show_delimiter',
      [
        'label' => __( 'Delimiter', 'justshoppe-features' ) . ' (:) ',
        'type' => Controls_Manager::SWITCHER,
        'label_on' => __( 'Show', 'justshoppe-features' ),
        'label_off' => __( 'Hide', 'justshoppe-features' ),
        'default' => 'no',
        'condition' => [
          'layout' => 'inline',
        ],
        'prefix_class' => 'bolvo-countdown--delimiters-',
      ]
    );

    $this->add_control(
      'show_months',
      [
        'label' => __( 'Months', 'justshoppe-features' ),
        'type' => Controls_Manager::SWITCHER,
        'label_on' => __( 'Show', 'justshoppe-features' ),
        'label_off' => __( 'Hide', 'justshoppe-features' ),
      ]
    );

		$this->add_control(
			'show_days',
			[
				'label' => __( 'Days', 'justshoppe-features' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'justshoppe-features' ),
				'label_off' => __( 'Hide', 'justshoppe-features' ),
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_hours',
			[
				'label' => __( 'Hours', 'justshoppe-features' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'justshoppe-features' ),
				'label_off' => __( 'Hide', 'justshoppe-features' ),
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_minutes',
			[
				'label' => __( 'Minutes', 'justshoppe-features' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'justshoppe-features' ),
				'label_off' => __( 'Hide', 'justshoppe-features' ),
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_seconds',
			[
				'label' => __( 'Seconds', 'justshoppe-features' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'justshoppe-features' ),
				'label_off' => __( 'Hide', 'justshoppe-features' ),
				'default' => 'yes',
			]
		);

    $this->add_control(
      'description',
      [
        'label' => __( 'Description', 'justshoppe-features' ),
        'type' => Controls_Manager::TEXTAREA,
        'placeholder' => "",
        'default' => "",
        'rows' => 3,
        'separator' => 'before',
      ]
    );

    $this->add_control(
      'hide_after_expiry',
      [
        'label' => __( 'Hide counter after expiry', 'justshoppe-features' ),
        'type' => Controls_Manager::SWITCHER,
        'label_on' => __( 'Yes', 'justshoppe-features' ),
        'label_off' => __( 'No', 'justshoppe-features' ),
        'default' => 'no',
      ]
    );

    $this->add_control(
      'after_expiry_text',
      [
        'label' => __( 'Expired event text', 'justshoppe-features' ),
        'type' => Controls_Manager::TEXTAREA,
        'placeholder' => __( 'Expired event text', 'justshoppe-features' ),
        'default' => "Expired event text",
        'rows' => 3,
        'condition' => [
          'hide_after_expiry' => 'yes',
        ],
      ]
    );

		$this->add_control(
			'show_labels',
			[
				'label' => __( 'Show Label', 'justshoppe-features' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'justshoppe-features' ),
				'label_off' => __( 'Hide', 'justshoppe-features' ),
				'default' => 'yes',
			]
		);

		$this->add_control(
			'custom_labels',
			[
				'label' => __( 'Custom Label', 'justshoppe-features' ),
				'type' => Controls_Manager::SWITCHER,
				'condition' => [
					'show_labels!' => '',
				],
			]
		);

    $this->add_control(
      'label_months',
      [
        'label' => __( 'Months', 'justshoppe-features' ),
        'type' => Controls_Manager::TEXT,
        'default' => __( 'Months', 'justshoppe-features' ),
        'placeholder' => __( 'Months', 'justshoppe-features' ),
        'condition' => [
          'show_labels!' => '',
          'custom_labels!' => '',
          'show_months' => 'yes',
        ],
      ]
    );

		$this->add_control(
			'label_days',
			[
				'label' => __( 'Days', 'justshoppe-features' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Days', 'justshoppe-features' ),
				'placeholder' => __( 'Days', 'justshoppe-features' ),
				'condition' => [
					'show_labels!' => '',
					'custom_labels!' => '',
					'show_days' => 'yes',
				],
			]
		);

		$this->add_control(
			'label_hours',
			[
				'label' => __( 'Hours', 'justshoppe-features' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Hours', 'justshoppe-features' ),
				'placeholder' => __( 'Hours', 'justshoppe-features' ),
				'condition' => [
					'show_labels!' => '',
					'custom_labels!' => '',
					'show_hours' => 'yes',
				],
			]
		);

		$this->add_control(
			'label_minutes',
			[
				'label' => __( 'Minutes', 'justshoppe-features' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Minutes', 'justshoppe-features' ),
				'placeholder' => __( 'Minutes', 'justshoppe-features' ),
				'condition' => [
					'show_labels!' => '',
					'custom_labels!' => '',
					'show_minutes' => 'yes',
				],
			]
		);

		$this->add_control(
			'label_seconds',
			[
				'label' => __( 'Seconds', 'justshoppe-features' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Seconds', 'justshoppe-features' ),
				'placeholder' => __( 'Seconds', 'justshoppe-features' ),
				'condition' => [
					'show_labels!' => '',
					'custom_labels!' => '',
					'show_seconds' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_box_style',
			[
				'label' => __( 'Boxes', 'justshoppe-features' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'container_width',
			[
				'label' => __( 'Container Width', 'justshoppe-features' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 2000,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'size_units' => [ '%', 'px' ],
				'selectors' => [
					'{{WRAPPER}} .bolvo-countdown-wrapper' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'box_background_color',
			[
				'label' => __( 'Background Color', 'justshoppe-features' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}}.bolvo-countdown--layout-squares .bolvo-countdown-item' => 'background-color: {{VALUE}};',
					'{{WRAPPER}}.bolvo-countdown--layout-circles .bolvo-countdown-item' => 'background-color: {{VALUE}};',
				],
				'condition' => [
				  'layout!' => 'inline',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'box_border',
				'selector' => '{{WRAPPER}} .bolvo-countdown-item',
				'separator' => 'before',
				'condition' => [
				  'layout!' => 'inline',
				]
			]
		);

		$this->add_control(
			'box_border_radius',
			[
				'label' => __( 'Border Radius', 'justshoppe-features' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .bolvo-countdown-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
				  'layout' => 'squares',
				]
			]
		);

		$this->add_responsive_control(
			'box_spacing',
			[
				'label' => __( 'Space Between', 'justshoppe-features' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 1,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'body:not(.rtl) {{WRAPPER}} .bolvo-countdown-item:not(:first-of-type)' => 'margin-left: calc( {{SIZE}}{{UNIT}}/2 );',
					'body:not(.rtl) {{WRAPPER}} .bolvo-countdown-item:not(:last-of-type)' => 'margin-right: calc( {{SIZE}}{{UNIT}}/2 );',
					'body.rtl {{WRAPPER}} .bolvo-countdown-item:not(:first-of-type)' => 'margin-right: calc( {{SIZE}}{{UNIT}}/2 );',
					'body.rtl {{WRAPPER}} .bolvo-countdown-item:not(:last-of-type)' => 'margin-left: calc( {{SIZE}}{{UNIT}}/2 );',
				],
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'label' => __( 'Padding', 'justshoppe-features' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'tablet_default' => [
					'size' => 0,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 0,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .bolvo-countdown-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_style',
			[
				'label' => __( 'Content', 'justshoppe-features' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'heading_description',
			[
				'label' => __( 'Description', 'justshoppe-features' ),
				'type' => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => __( 'Color', 'justshoppe-features' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .bolvo-countdown-description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'selector' => '{{WRAPPER}} .bolvo-countdown-description',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
			]
		);

		$this->add_control(
			'heading_digits',
			[
				'label' => __( 'Digits', 'justshoppe-features' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'digits_color',
			[
				'label' => __( 'Color', 'justshoppe-features' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_2,
				],
				'selectors' => [
					'{{WRAPPER}} .bolvo-countdown-digits' => 'color: {{VALUE}};',
				],
				'condition' => [
				  'layout!' => 'inline',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'digits_typography',
				'selector' => '{{WRAPPER}} .bolvo-countdown-digits',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
				'condition' => [
				  'layout!' => 'inline',
				],
			]
		);


    $this->add_control(
      'digits_color_inline',
      [
        'label' => __( 'Color', 'justshoppe-features' ),
        'type' => Controls_Manager::COLOR,
		'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_2,
				],
        'selectors' => [
          '{{WRAPPER}}.bolvo-countdown--layout-inline .bolvo-countdown-digits' => 'color: {{VALUE}};',
        ],
        'condition' => [
          'layout' => 'inline',
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'digits_typography_inline',
        'selector' => '{{WRAPPER}}.bolvo-countdown--layout-inline .bolvo-countdown-digits',
        'scheme' => Scheme_Typography::TYPOGRAPHY_3,
		'desktop_default' => [
					'size' => 53,
					'unit' => 'px',
				],
		'tablet_default' => [
			'size' => 38,
			'unit' => 'px',
		],
		'mobile_default' => [
			'size' => 25,
			'unit' => 'px',
		],
        'condition' => [
          'layout' => 'inline',
        ],
      ]
    );

		$this->add_control(
			'heading_label',
			[
				'label' => __( 'Label', 'justshoppe-features' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'label_color',
			[
				'label' => __( 'Color', 'justshoppe-features' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .bolvo-countdown-label' => 'color: {{VALUE}};',
				],
				'condition' => [
				  'layout!' => 'inline',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'label_typography',
				'selector' => '{{WRAPPER}} .bolvo-countdown-label',
				'scheme' => Scheme_Typography::TYPOGRAPHY_2,
				'condition' => [
				  'layout!' => 'inline',
				],
			]
		);

    $this->add_control(
      'label_color_inline',
      [
        'label' => __( 'Color', 'justshoppe-features' ),
        'type' => Controls_Manager::COLOR,
		'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_3,
				],
        'selectors' => [
          '{{WRAPPER}}.bolvo-countdown--layout-inline .bolvo-countdown-label' => 'color: {{VALUE}};',
        ],
        'condition' => [
          'layout' => 'inline',
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'label_typography_inline',
        'selector' => '{{WRAPPER}}.bolvo-countdown--layout-inline .bolvo-countdown-label',
        'scheme' => Scheme_Typography::TYPOGRAPHY_2,
		'desktop_default' => [
			'size' => 15,
			'unit' => 'px',
		],
		'tablet_default' => [
			'size' => 13,
			'unit' => 'px',
		],
		'mobile_default' => [
			'size' => 10,
			'unit' => 'px',
		],
        'condition' => [
          'layout' => 'inline',
        ],
      ]
    );

		$this->add_control(
			'heading_expiry_text',
			[
				'label' => __( 'Expiry Text', 'justshoppe-features' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'expiry_text_color',
			[
				'label' => __( 'Color', 'justshoppe-features' ),
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_3,
				],
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bolvo-countdown-expired' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'expiry_text_typography',
				'selector' => '{{WRAPPER}} .bolvo-countdown-wrapper.bolvo-countdown-header .bolvo-countdown-expired .bolvo-countdown-label',
				'scheme' => Scheme_Typography::TYPOGRAPHY_2,
			]
		);

		$this->end_controls_section();
	}

	private function timestamp($time) {
    return strtotime( $time ) + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
  }

	private function get_strftime( $instance ) {
		$string = '';
		$block_count = 0;
		if ( $instance['show_months'] ) {
      $string .= $this->render_countdown_item( $instance, 'label_months', 'bolvo-countdown-months', $block_count );
      $block_count++;
    }
		if ( $instance['show_days'] ) {
      $string .= $this->render_countdown_item( $instance, 'label_days', 'bolvo-countdown-days', $block_count );
      $block_count++;
    }
		if ( $instance['show_hours'] ) {
      $string .= $this->render_countdown_item( $instance, 'label_hours', 'bolvo-countdown-hours', $block_count );
      $block_count++;
    }
		if ( $instance['show_minutes'] ) {
      $string .= $this->render_countdown_item( $instance, 'label_minutes', 'bolvo-countdown-minutes', $block_count );
      $block_count++;
    }
		if ( $instance['show_seconds'] ) {
      $string .= $this->render_countdown_item( $instance, 'label_seconds', 'bolvo-countdown-seconds', $block_count );
    }

		return $string;
	}

	private $_default_countdown_labels;

	private function _init_default_countdown_labels() {
		$this->_default_countdown_labels = [
			'label_months' => __( 'Months', 'justshoppe-features' ),
			'label_weeks' => __( 'Weeks', 'justshoppe-features' ),
			'label_days' => __( 'Days', 'justshoppe-features' ),
			'label_hours' => __( 'Hours', 'justshoppe-features' ),
			'label_minutes' => __( 'Minutes', 'justshoppe-features' ),
			'label_seconds' => __( 'Seconds', 'justshoppe-features' ),
		];
	}

	public function get_default_countdown_labels() {
		if ( ! $this->_default_countdown_labels ) {
			$this->_init_default_countdown_labels();
		}

		return $this->_default_countdown_labels;
	}

	private function render_countdown_description( $instance ) {
		$string = '';

		if ( $instance['description'] ) {
			$string = '<div class="bolvo-countdown-description">' . $instance['description'] . '</div>';
		}

		return $string;
	}

	private function render_countdown_item( $instance, $label, $part_class, $block_count ) {
    $string = $block_count > 0 ? '<div class="bolvo-countdown-item bolvo-countdown-delimiter-container"><div><div><span class="bolvo-countdown-digits">:</span></div></div></div>' : '';
		$string .= '<div class="bolvo-countdown-item"><div><div><span class="bolvo-countdown-digits ' . $part_class . '"></span>';

		if ( $instance['show_labels'] ) {
			$default_labels = $this->get_default_countdown_labels();
			$label = ( $instance['custom_labels'] ) ? $instance[ $label ] : $default_labels[ $label ];
			$string .= ' <span class="bolvo-countdown-label">' . $label . '</span>';
		}

		$string .= '</div></div></div>';

    return $string;
	}

	private function render_expired_mesage( $instance ) {
    $string = '';

    if ( $instance['hide_after_expiry'] ) {
      $string = '<div class="bolvo-countdown-expired bolvo-hidden">';
			$string .= '<span class="bolvo-countdown-label">' . $instance['after_expiry_text'] . '</span>';
      $string .= '</div>';
    }

    return $string;
	}

	protected function render() {
		$instance = $this->get_settings_for_display();
		$due_date = $instance['due_date'];
		$description_string = $this->render_countdown_description( $instance );
		$counter_string = $this->get_strftime( $instance );
		$expiry_string = $this->render_expired_mesage( $instance );

		// Handle timezone ( we need to set GMT time )
		$gmt = get_gmt_from_date( $due_date . ':00' );
		$due_date = strtotime( $gmt );
		?>
    <div class="bolvo-countdown-wrapper bolvo-countdown-header">
      <?php echo $description_string; ?>
      <?php echo $expiry_string; ?>
    </div>
		<div class="bolvo-countdown bolvo-countdown-wrapper" data-date="<?php echo $due_date; ?>" data-hide-after-expiry="<?php echo $instance['hide_after_expiry']; ?>">
			<?php echo $counter_string; ?>
		</div>
		<?php
	}
}
\Elementor\Plugin::instance()->widgets_manager->register(new Countdown());
