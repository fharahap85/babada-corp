<?php
namespace Bolvo_Builder\Widgets\Parallax;

use Elementor\Controls_Manager;
use Elementor\Element_Section;
use Elementor\Widget_Base;

/**
 * Class Parallax
 *
 * @package Bolvo_Builder\Widgets\Parallax
 */
class Parallax extends Widget_Base {

  public function __construct() {
    $this->add_actions();
  }

  public function get_name() {
    return 'bolvo-parallax';
  }

  public function show_in_panel() {
    return false;
  }

  /**
   * @param Controls_Parallax $element
   */
	public function register_custom_controls( Element_Section $element ) {
        $element->start_injection( [
            'of' => 'background_bg_width_mobile',
        ] );
        $element->add_control(
            'bolvo_enable_parallax_efects',
            [
                'label' => __( 'Parallax Effects', 'justshoppe-features' ),
                'type' => Controls_Manager::SWITCHER,
                'label_off' => __( 'Off', 'justshoppe-features' ),
                'label_on' => __( 'On', 'justshoppe-features' ),
                'render_type' => 'ui',
                'frontend_available' => true,
                'condition' => [
                  'background_background' => 'classic',
                  'bolvo_enable_parallax_efects' => 'yes'
                ],
            ]
        );
        /*
         * Vertical effect
         */
        $element->add_control(
            'bolvo_vertical_scroll_efects',
            [
                'label' => __( 'Vertical Scroll', 'justshoppe-features' ),
                'type' => Controls_Manager::POPOVER_TOGGLE,
                'condition' => [
                    'bolvo_enable_parallax_efects' => 'yes',
                    'background_background' => 'classic',
                ],
                'render_type' => 'none',
                'frontend_available' => true,
            ]
        );
        $element->add_control(
            'bolvo_vertical_scroll_efects-direction',
            [
                'label' => __( 'Vertical Scroll direction', 'justshoppe-features' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'up',
                'options' => [
                    'up' => __( 'Up', 'justshoppe-features' ),
                    'down' => __( 'Down', 'justshoppe-features' ),
                ],
                'condition' => [
                    'bolvo_enable_parallax_efects' => 'yes',
                    'bolvo_vertical_scroll_efects' => 'yes',
                    'background_background' => 'classic',
                ],
                'popover' => [
                    'start'=>true
                ],
                'render_type' => 'none',
                'frontend_available' => true,
            ]
        );
        $element->add_control(
            'bolvo_vertical_scroll_efects-speed',
            [
                'label' => __( 'Vertical Scroll Speed', 'justshoppe-features' ),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 4,
                ],
                'range' => [
                    'px' => [
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'condition' => [
                    'bolvo_enable_parallax_efects' => 'yes',
                    'bolvo_vertical_scroll_efects' => 'yes',
                    'background_background' => 'classic',
                ],
                'popover' => [
                    'end'=>true
                ],
                'render_type' => 'none',
                'frontend_available' => true,
            ]
        );

    /*
     * Horizontal effect
     */
    $element->add_control(
      'bolvo_horizontal_scroll_efects',
      [
        'label' => __( 'Horizontal Scroll', 'justshoppe-features' ),
        'type' => Controls_Manager::POPOVER_TOGGLE,
        'condition' => [
          'bolvo_enable_parallax_efects' => 'yes',
          'background_background' => 'classic',
        ],
        'render_type' => 'none',
        'frontend_available' => true,
      ]
    );
    $element->add_control(
      'bolvo_horizontal_scroll_efects-direction',
      [
        'label' => __( 'Horizontal Scroll direction', 'justshoppe-features' ),
        'type' => Controls_Manager::SELECT,
        'default' => 'left',
        'options' => [
          'left' => __( 'To Left', 'justshoppe-features' ),
          'right' => __( 'To Right', 'justshoppe-features' ),
        ],
        'condition' => [
          'bolvo_enable_parallax_efects' => 'yes',
          'bolvo_horizontal_scroll_efects' => 'yes',
          'background_background' => 'classic',
        ],
        'popover' => [
          'start' => true
        ],
        'render_type' => 'none',
        'frontend_available' => true,
      ]
    );
    $element->add_control(
      'bolvo_horizontal_scroll_efects-speed',
      [
        'label' => __( 'Horizontal Scroll Speed', 'justshoppe-features' ),
        'type' => Controls_Manager::SLIDER,
        'default' => [
          'size' => 4,
        ],
        'range' => [
          'px' => [
            'max' => 10,
            'step' => 0.1,
          ],
        ],
        'condition' => [
          'bolvo_enable_parallax_efects' => 'yes',
          'bolvo_horizontal_scroll_efects' => 'yes',
          'background_background' => 'classic',
        ],
        'popover' => [
          'end' => true
        ],
        'render_type' => 'none',
        'frontend_available' => true,
      ]
    );

    /*
     *  Transparency
     */
    $element->add_control(
      'bolvo_transparency_efects',
      [
        'label' => __( 'Transparency', 'justshoppe-features' ),
        'type' => Controls_Manager::POPOVER_TOGGLE,
        'condition' => [
          'bolvo_enable_parallax_efects' => 'yes',
          'background_background' => 'classic',
        ],
        'render_type' => 'none',
        'frontend_available' => true,
      ]
    );
    $element->add_control(
      'bolvo_transparency_efects-direction',
      [
        'label' => __( 'Transparency direction', 'justshoppe-features' ),
        'type' => Controls_Manager::SELECT,
        'default' => 'in',
        'options' => [
          'in' => __( 'Fade In', 'justshoppe-features' ),
          'out' => __( 'Fade Out', 'justshoppe-features' ),
        ],
        'condition' => [
          'bolvo_enable_parallax_efects' => 'yes',
          'bolvo_transparency_efects' => 'yes',
          'background_background' => 'classic',
        ],
        'popover' => [
          'start' => true
        ],
        'render_type' => 'none',
        'frontend_available' => true,
      ]
    );
    $element->add_control(
      'bolvo_transparency_efects-speed',
      [
        'label' => __( 'Transparency Speed', 'justshoppe-features' ),
        'type' => Controls_Manager::SLIDER,
        'default' => [
          'size' => 4,
        ],
        'range' => [
          'px' => [
            'max' => 10,
            'step' => 0.1,
          ],
        ],
        'condition' => [
          'bolvo_enable_parallax_efects' => 'yes',
          'bolvo_transparency_efects' => 'yes',
          'background_background' => 'classic',
        ],
        'popover' => [
          'end' => true
        ],
        'render_type' => 'none',
        'frontend_available' => true,
      ]
    );

    /*
     * Blur
     */
    $element->add_control(
      'bolvo_blur_efects',
      [
        'label' => __( 'Blur', 'justshoppe-features' ),
        'type' => Controls_Manager::POPOVER_TOGGLE,
        'condition' => [
          'bolvo_enable_parallax_efects' => 'yes',
          'background_background' => 'classic',
        ],
        'render_type' => 'none',
        'frontend_available' => true,
      ]
    );
    $element->add_control(
      'bolvo_blur_efects-direction',
      [
        'label' => __( 'Blur direction', 'justshoppe-features' ),
        'type' => Controls_Manager::SELECT,
        'default' => 'in',
        'options' => [
          'in' => __( 'Fade In', 'justshoppe-features' ),
          'out' => __( 'Fade Out', 'justshoppe-features' ),
        ],
        'condition' => [
          'bolvo_enable_parallax_efects' => 'yes',
          'bolvo_blur_efects' => 'yes',
          'background_background' => 'classic',
        ],
        'popover' => [
          'start' => true
        ],
        'render_type' => 'none',
        'frontend_available' => true,
      ]
    );
    $element->add_control(
      'bolvo_blur_efects-speed',
      [
        'label' => __( 'Blur Speed', 'justshoppe-features' ),
        'type' => Controls_Manager::SLIDER,
        'default' => [
          'size' => 4,
        ],
        'range' => [
          'px' => [
            'max' => 10,
            'step' => 0.1,
          ],
        ],
        'condition' => [
          'bolvo_enable_parallax_efects' => 'yes',
          'bolvo_blur_efects' => 'yes',
          'background_background' => 'classic',
        ],
        'popover' => [
          'end' => true
        ],
        'render_type' => 'none',
        'frontend_available' => true,
      ]
    );

    /*
     * Scale
     */
    $element->add_control(
      'bolvo_scale_efects',
      [
        'label' => __( 'Scale', 'justshoppe-features' ),
        'type' => Controls_Manager::POPOVER_TOGGLE,
        'condition' => [
          'bolvo_enable_parallax_efects' => 'yes',
          'background_background' => 'classic',
        ],
        'render_type' => 'none',
        'frontend_available' => true,
      ]
    );
    $element->add_control(
      'bolvo_scale_efects-direction',
      [
        'label' => __( 'Scale direction', 'justshoppe-features' ),
        'type' => Controls_Manager::SELECT,
        'default' => 'in',
        'options' => [
          'in' => __( 'Scale In', 'justshoppe-features' ),
          'out' => __( 'Scale Out', 'justshoppe-features' ),
        ],
        'condition' => [
          'bolvo_enable_parallax_efects' => 'yes',
          'bolvo_scale_efects' => 'yes',
          'background_background' => 'classic',
        ],
        'popover' => [
          'start' => true
        ],
        'render_type' => 'none',
        'frontend_available' => true,
      ]
    );
    $element->add_control(
      'bolvo_scale_efects-speed',
      [
        'label' => __( 'Scale Speed', 'justshoppe-features' ),
        'type' => Controls_Manager::SLIDER,
        'default' => [
          'size' => 4,
        ],
        'range' => [
          'px' => [
            'max' => 10,
            'step' => 0.1,
          ],
        ],
        'condition' => [
          'bolvo_enable_parallax_efects' => 'yes',
          'bolvo_scale_efects' => 'yes',
          'background_background' => 'classic',
        ],
        'popover' => [
          'end' => true
        ],
        'render_type' => 'none',
        'frontend_available' => true,
      ]
    );

    $element->add_control(
      'bolvo_parallax_on',
      [
        'label' => __( 'Apply Effects On', 'justshoppe-features' ),
        'type' => Controls_Manager::SELECT2,
        'multiple' => true,
        'label_block' => 'true',
        'default' => [ 'desktop', 'tablet', 'mobile' ],
        'options' => [
          'desktop' => __( 'Desktop', 'justshoppe-features' ),
          'tablet' => __( 'Tablet', 'justshoppe-features' ),
          'mobile' => __( 'Mobile', 'justshoppe-features' ),
        ],
        'condition' => [
          'bolvo_enable_parallax_efects' => 'yes',
          'background_background' => 'classic',
        ],
        'render_type' => 'none',
        'frontend_available' => true,
      ]
    );
    $element->end_injection();
  }

  private function add_actions() {
    add_action( 'elementor/element/section/section_advanced/before_section_end', [ $this, 'register_custom_controls' ], 10, 3 );
  }
}
\Elementor\Plugin::instance()->widgets_manager->register( new Parallax() );
