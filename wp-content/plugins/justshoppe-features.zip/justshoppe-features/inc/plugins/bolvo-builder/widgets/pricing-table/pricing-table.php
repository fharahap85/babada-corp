<?php
namespace Bolvo_Builder;

use Elementor\Controls_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Widget_Base;

if(!defined('ABSPATH')) exit; // Exit if accessed directly

class Pricing_Table extends Widget_Base {

  public function get_name(){
    return 'blvb-pricing-table';
  }

  public function get_title(){
    return __('Pricing Table', 'justshoppe-features');
  }

  public function get_icon(){
    return 'blvb-pricing-table blvb-widget-icon';
  }

  public function get_categories(){
    return ['bolvo-widgets'];
  }

  public function get_keywords() {
    return [ 'pricing', 'table', 'product', 'image', 'plan', 'button' ];
  }

  protected function register_controls(){
    $this->start_controls_section(
      'blvb_section_header',
      [
        'label' => __('Header', 'justshoppe-features'),
      ]
    );

    $this->add_control(
      'blvb_heading',
      [
        'label' => __('Title', 'justshoppe-features'),
        'type' => Controls_Manager::TEXT,
        'default' => __('Product title', 'justshoppe-features'),
      ]
    );

    $this->add_control(
      'blvb_sub_heading',
      [
        'label' => __('Description', 'justshoppe-features'),
        'type' => Controls_Manager::TEXT,
        'default' => __('Product description', 'justshoppe-features'),
      ]
    );

    $this->add_control(
      'blvb_heading_tag',
      [
        'label' => __( 'Title HTML Tag', 'justshoppe-features' ),
        'type' => Controls_Manager::SELECT,
        'options' => [
          'h2' => 'H2',
          'h3' => 'H3',
          'h4' => 'H4',
          'h5' => 'H5',
          'h6' => 'H6',
        ],
        'default' => 'h3',
      ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
      'blvb_section_pricing',
      [
        'label' => __('Pricing', 'justshoppe-features'),
      ]
    );


    $this->add_control(
      'blvb_currency_symbol',
      [
        'label' => __('Currency Symbol', 'justshoppe-features'),
        'type' => Controls_Manager::SELECT2,
        'options' => [
          'AED' => '&#1583;.&#1573; ' . _x('UAE Dirham', 'Currency Symbol', 'justshoppe-features') . ' (AED)', // ?
          'AFN' => '&#65;&#102; ' . _x('Afghani', 'Currency Symbol', 'justshoppe-features') . ' (AFN)',
          'ALL' => '&#76;&#101;&#107; ' . _x('Lek', 'Currency Symbol', 'justshoppe-features') . ' (ALL)',
          'AMD' => 'Դ ' . _x('Armenian Dram', 'Currency Symbol', 'justshoppe-features') . ' (AMD)',
          'ANG' => '&#402; ' . _x('Netherlands Antillean guilder', 'Currency Symbol', 'justshoppe-features') . ' (ANG)',
          'AOA' => '&#75;&#122; ' . _x('Kwanza', 'Currency Symbol', 'justshoppe-features') . ' (AOA)', // ?
          'ARS' => '&#36; ' . _x('Argentine Peso', 'Currency Symbol', 'justshoppe-features') . ' (ARS)',
          'AUD' => '&#36; ' . _x('Australian Dollar', 'Currency Symbol', 'justshoppe-features') . ' (AUD)',
          'AWG' => '&#402; ' . _x('Aruban Guilder/Florin', 'Currency Symbol', 'justshoppe-features') . ' (AWG)',
          'AZN' => '&#1084;&#1072;&#1085; ' . _x('Azerbaijanian Manat', 'Currency Symbol', 'justshoppe-features') . ' (AZN)',
          'BAM' => '&#75;&#77; ' . _x('Konvertibilna Marka', 'Currency Symbol', 'justshoppe-features') . ' (BAM)',
          'BBD' => '&#36; ' . _x('Barbados Dollar', 'Currency Symbol', 'justshoppe-features') . ' (BBD)',
          'BDT' => '&#2547; ' . _x('Taka', 'Currency Symbol', 'justshoppe-features') . ' (BDT)', // ?
          'BGN' => '&#1083;&#1074; ' . _x('Bulgarian Lev', 'Currency Symbol', 'justshoppe-features') . ' (BGN)',
          'BHD' => '.&#1583;.&#1576; ' . _x('Bahraini Dinar', 'Currency Symbol', 'justshoppe-features') . ' (BHD)', // ?
          'BIF' => '&#70;&#66;&#117; ' . _x('Burundi Franc', 'Currency Symbol', 'justshoppe-features') . ' (BIF)', // ?
          'BMD' => '&#36; ' . _x('Bermudian Dollar', 'Currency Symbol', 'justshoppe-features') . ' (BMD)',
          'BND' => '&#36; ' . _x('Brunei Dollar', 'Currency Symbol', 'justshoppe-features') . ' (BND)',
          'BOB' => '&#36;&#98; ' . _x('Boliviano', 'Currency Symbol', 'justshoppe-features') . ' (BOB)',
          'BRL' => '&#82;&#36; ' . _x('Brazilian Real', 'Currency Symbol', 'justshoppe-features') . ' (BRL)',
          'BSD' => '&#36; ' . _x('Bahamian Dollar', 'Currency Symbol', 'justshoppe-features') . ' (BSD)',
          'BTN' => '&#78;&#117;&#46; ' . _x('Ngultrum', 'Currency Symbol', 'justshoppe-features') . ' (BTN)', // ?
          'BWP' => '&#80; ' . _x('Pula', 'Currency Symbol', 'justshoppe-features') . ' (BWP)',
          'BYR' => '&#112;&#46; ' . _x('Belarussian Ruble', 'Currency Symbol', 'justshoppe-features') . ' (BYR)',
          'BZD' => '&#66;&#90;&#36; ' . _x('Belize Dollar', 'Currency Symbol', 'justshoppe-features') . ' (BZD)',
          'CAD' => '&#36; ' . _x('Canadian Dollar', 'Currency Symbol', 'justshoppe-features') . ' (CAD)',
          'CDF' => '&#70;&#67; ' . _x('Congolese Franc', 'Currency Symbol', 'justshoppe-features') . ' (CDF)',
          'CHF' => '&#67;&#72;&#70; ' . _x('Swiss Franc', 'Currency Symbol', 'justshoppe-features') . ' (CHF)',
          'CLP' => '&#36; ' . _x('Chilean Peso', 'Currency Symbol', 'justshoppe-features') . ' (CLP)',
          'CNY' => '&#165; ' . _x('Yuan', 'Currency Symbol', 'justshoppe-features') . ' (CNY)',
          'COP' => '&#36; ' . _x('Colombian Peso', 'Currency Symbol', 'justshoppe-features') . ' (COP)',
          'CRC' => '&#8353; ' . _x('Costa Rican Colon', 'Currency Symbol', 'justshoppe-features') . ' (CRC)',
          'CUP' => '&#8396; ' . _x('Cuban Peso', 'Currency Symbol', 'justshoppe-features') . ' (CUP)',
          'CVE' => '&#36; ' . _x('Cape Verde Escudo', 'Currency Symbol', 'justshoppe-features') . ' (CVE)', // ?
          'CZK' => '&#75;&#269; ' . _x('Czech Koruna', 'Currency Symbol', 'justshoppe-features') . ' (CZK)',
          'DJF' => '&#70;&#100;&#106; ' . _x('Djibouti Franc', 'Currency Symbol', 'justshoppe-features') . ' (DJF)', // ?
          'DKK' => '&#107;&#114; ' . _x('Danish Krone', 'Currency Symbol', 'justshoppe-features') . ' (DKK)',
          'DOP' => '&#82;&#68;&#36; ' . _x('Dominican Peso', 'Currency Symbol', 'justshoppe-features') . ' (DOP)',
          'DZD' => '&#1583;&#1580; ' . _x('Algerian Dinar', 'Currency Symbol', 'justshoppe-features') . ' (DZD)', // ?
          'EGP' => '&#163; ' . _x('Egyptian Pound', 'Currency Symbol', 'justshoppe-features') . ' (EGP)',
          'ERN' => 'Nfk ' . _x('Nakfa', 'Currency Symbol', 'justshoppe-features') . ' (ERN)',
          'ETB' => '&#66;&#114; ' . _x('Ethiopian Birr', 'Currency Symbol', 'justshoppe-features') . ' (ETB)',
          'EUR' => '&#8364; ' . _x('Euro', 'Currency Symbol', 'justshoppe-features') . ' (EUR)',
          'FJD' => '&#36; ' . _x('Fiji Dollar', 'Currency Symbol', 'justshoppe-features') . ' (FJD)',
          'FKP' => '&#163; ' . _x('Falkland Islands Pound', 'Currency Symbol', 'justshoppe-features') . ' (FKP)',
          'GBP' => '&#163; ' . _x('Pound Sterling', 'Currency Symbol', 'justshoppe-features') . ' (GBP)',
          'GEL' => '&#4314; ' . _x('Lari', 'Currency Symbol', 'justshoppe-features') . ' (GEL)', // ?
          'GHS' => '&#162; ' . _x('Cedi', 'Currency Symbol', 'justshoppe-features') . ' (GHS)',
          'GIP' => '&#163; ' . _x('Gibraltar Pound', 'Currency Symbol', 'justshoppe-features') . ' (GIP)',
          'GMD' => '&#68; ' . _x('Dalasi', 'Currency Symbol', 'justshoppe-features') . ' (GMD)', // ?
          'GNF' => '&#70;&#71; ' . _x('Guinea Franc', 'Currency Symbol', 'justshoppe-features') . ' (GNF)', // ?
          'GTQ' => '&#81; ' . _x('Quetzal', 'Currency Symbol', 'justshoppe-features') . ' (GTQ)',
          'GYD' => '&#36; ' . _x('Guyana Dollar', 'Currency Symbol', 'justshoppe-features') . ' (GYD)',
          'HKD' => '&#36; ' . _x('Hong Kong Dollar', 'Currency Symbol', 'justshoppe-features') . ' (HKD)',
          'HNL' => '&#76; ' . _x('Lempira', 'Currency Symbol', 'justshoppe-features') . ' (HNL)',
          'HRK' => '&#107;&#110; ' . _x('Croatian Kuna', 'Currency Symbol', 'justshoppe-features') . ' (HRK)',
          'HTG' => '&#71; ' . _x('Gourde', 'Currency Symbol', 'justshoppe-features') . ' (HTG)', // ?
          'HUF' => '&#70;&#116; ' . _x('Forint', 'Currency Symbol', 'justshoppe-features') . ' (HUF)',
          'IDR' => '&#82;&#112; ' . _x('Rupiah', 'Currency Symbol', 'justshoppe-features') . ' (IDR)',
          'ILS' => '&#8362; ' . _x('New Israeli Shekel', 'Currency Symbol', 'justshoppe-features') . ' (ILS)',
          'INR' => '&#8377; ' . _x('Indian Rupee', 'Currency Symbol', 'justshoppe-features') . ' (INR)',
          'IQD' => '&#1593;.&#1583; ' . _x('Iraqi Dinar', 'Currency Symbol', 'justshoppe-features') . ' (IQD)', // ?
          'IRR' => '&#65020; ' . _x('Iranian Rial', 'Currency Symbol', 'justshoppe-features') . ' (IRR)',
          'ISK' => '&#107;&#114; ' . _x('Iceland Krona', 'Currency Symbol', 'justshoppe-features') . ' (ISK)',
          'JEP' => '&#163; ' . _x('Jersey Pound', 'Currency Symbol', 'justshoppe-features') . ' (JEP)',
          'JMD' => '&#74;&#36; ' . _x('Jamaican Dollar', 'Currency Symbol', 'justshoppe-features') . ' (JMD)',
          'JOD' => '&#74;&#68; ' . _x('Jordanian Dinar', 'Currency Symbol', 'justshoppe-features') . ' (JOD)', // ?
          'JPY' => '&#165; ' . _x('Yen', 'Currency Symbol', 'justshoppe-features') . ' (JPY)',
          'KES' => '&#75;&#83;&#104; ' . _x('Kenyan Shilling', 'Currency Symbol', 'justshoppe-features') . ' (KES)', // ?
          'KGS' => '&#1083;&#1074; ' . _x('Som', 'Currency Symbol', 'justshoppe-features') . ' (KGS)',
          'KHR' => '&#6107; ' . _x('Riel', 'Currency Symbol', 'justshoppe-features') . ' (KHR)',
          'KMF' => '&#67;&#70; ' . _x('Comoro franc', 'Currency Symbol', 'justshoppe-features') . ' (KMF)', // ?
          'KPW' => '&#8361; ' . _x('North Korean Won', 'Currency Symbol', 'justshoppe-features') . ' (KPW)',
          'KRW' => '&#8361; ' . _x('South Korean Won', 'Currency Symbol', 'justshoppe-features') . ' (KRW)',
          'KWD' => '&#1583;.&#1603; ' . _x('Kuwaiti Dinar', 'Currency Symbol', 'justshoppe-features') . ' (KWD)', // ?
          'KYD' => '&#36; ' . _x('Cayman Islands Dollar', 'Currency Symbol', 'justshoppe-features') . ' (KYD)',
          'KZT' => '&#1083;&#1074; ' . _x('Tenge', 'Currency Symbol', 'justshoppe-features') . ' (KZT)',
          'LAK' => '&#8365; ' . _x('Kip', 'Currency Symbol', 'justshoppe-features') . ' (LAK)',
          'LBP' => '&#163; ' . _x('Lebanese Pound', 'Currency Symbol', 'justshoppe-features') . ' (LBP)',
          'LKR' => '&#8360; ' . _x('Sri Lanka Rupee', 'Currency Symbol', 'justshoppe-features') . ' (LKR)',
          'LRD' => '&#36; ' . _x('Liberian Dollar', 'Currency Symbol', 'justshoppe-features') . ' (LRD)',
          'LSL' => '&#76; ' . _x('loti', 'Currency Symbol', 'justshoppe-features') . ' (LSL)', // ?
          'LTL' => '&#76;&#116; ' . _x('Lithuania Litas', 'Currency Symbol', 'justshoppe-features') . ' (LTL)',
          'LVL' => '&#76;&#115; ' . _x('Latvia Lat', 'Currency Symbol', 'justshoppe-features') . ' (LVL)',
          'LYD' => '&#1604;.&#1583; ' . _x('Libyan Dinar', 'Currency Symbol', 'justshoppe-features') . ' (LYD)', // ?
          'MAD' => '&#1583;.&#1605;. ' . _x('Moroccan Dirham', 'Currency Symbol', 'justshoppe-features') . ' (MAD)', //?
          'MDL' => '&#76; ' . _x('Moldavian Leu', 'Currency Symbol', 'justshoppe-features') . ' (MDL)',
          'MGA' => '&#65;&#114; ' . _x('Malagasy Ariary', 'Currency Symbol', 'justshoppe-features') . ' (MGA)', // ?
          'MKD' => '&#1076;&#1077;&#1085; ' . _x('Denar', 'Currency Symbol', 'justshoppe-features') . ' (MKD)',
          'MMK' => '&#75; ' . _x('Kyat', 'Currency Symbol', 'justshoppe-features') . ' (MMK)',
          'MNT' => '&#8366; ' . _x('Tugrik', 'Currency Symbol', 'justshoppe-features') . ' (MNT)',
          'MOP' => '&#77;&#79;&#80;&#36; ' . _x('Pataca', 'Currency Symbol', 'justshoppe-features') . ' (MOP)', // ?
          'MRO' => '&#85;&#77; ' . _x('Ouguiya', 'Currency Symbol', 'justshoppe-features') . ' (MRO)', // ?
          'MUR' => '&#8360; ' . _x('Mauritius Rupee', 'Currency Symbol', 'justshoppe-features') . ' (MUR)', // ?
          'MVR' => '.&#1923; ' . _x('Rufiyaa', 'Currency Symbol', 'justshoppe-features') . ' (MVR)', // ?
          'MWK' => '&#77;&#75; ' . _x('Kwacha', 'Currency Symbol', 'justshoppe-features') . ' (MWK)',
          'MXN' => '&#36; ' . _x('Mexican Peso', 'Currency Symbol', 'justshoppe-features') . ' (MXN)',
          'MYR' => '&#82;&#77; ' . _x('Malaysian Ringgit', 'Currency Symbol', 'justshoppe-features') . ' (MYR)',
          'MZN' => '&#77;&#84; ' . _x('Metical', 'Currency Symbol', 'justshoppe-features') . ' (MZN)',
          'NAD' => '&#36; ' . _x('Namibia Dollar', 'Currency Symbol', 'justshoppe-features') . ' (NAD)',
          'NGN' => '&#8358; ' . _x('Naira', 'Currency Symbol', 'justshoppe-features') . ' (NGN)',
          'NIO' => '&#67;&#36; ' . _x('Cordoba Oro', 'Currency Symbol', 'justshoppe-features') . ' (NIO)',
          'NOK' => '&#107;&#114; ' . _x('Norwegian Krone', 'Currency Symbol', 'justshoppe-features') . ' (NOK)',
          'NPR' => '&#8360; ' . _x('Nepalese Rupee', 'Currency Symbol', 'justshoppe-features') . ' (NPR)',
          'NZD' => '&#36; ' . _x('New Zealand Dollar', 'Currency Symbol', 'justshoppe-features') . ' (NZD)',
          'OMR' => '&#65020; ' . _x('Rial Omani', 'Currency Symbol', 'justshoppe-features') . ' (OMR)',
          'PAB' => '&#66;&#47;&#46; ' . _x('Balboa', 'Currency Symbol', 'justshoppe-features') . ' (PAB)',
          'PEN' => '&#83;&#47;&#46; ' . _x('Nuevo Sol', 'Currency Symbol', 'justshoppe-features') . ' (PEN)',
          'PGK' => '&#75; ' . _x('Kina', 'Currency Symbol', 'justshoppe-features') . ' (PGK)', // ?
          'PHP' => '&#8369; ' . _x('Philippine Peso', 'Currency Symbol', 'justshoppe-features') . ' (PHP)',
          'PKR' => '&#8360; ' . _x('Pakistan Rupee', 'Currency Symbol', 'justshoppe-features') . ' (PKR)',
          'PLN' => '&#122;&#322; ' . _x('PZloty', 'Currency Symbol', 'justshoppe-features') . ' (PLN)',
          'PYG' => '&#71;&#115; ' . _x('Guarani', 'Currency Symbol', 'justshoppe-features') . ' (PYG)',
          'QAR' => '&#65020; ' . _x('Qatari Rial', 'Currency Symbol', 'justshoppe-features') . ' (QAR)',
          'RON' => '&#108;&#101;&#105; ' . _x('Leu', 'Currency Symbol', 'justshoppe-features') . ' (RON)',
          'RSD' => '&#1044;&#1080;&#1085;&#46; ' . _x('Serbian Dinar', 'Currency Symbol', 'justshoppe-features') . ' (RSD)',
          'RUB' => '&#1088;&#1091;&#1073; ' . _x('Russian Ruble', 'Currency Symbol', 'justshoppe-features') . ' (RUB)',
          'RWF' => '&#1585;.&#1587; ' . _x('Rwanda Franc', 'Currency Symbol', 'justshoppe-features') . ' (RWF)',
          'SAR' => '&#65020; ' . _x('Saudi Riyal', 'Currency Symbol', 'justshoppe-features') . ' (SAR)',
          'SBD' => '&#36; ' . _x('Solomon Islands Dollar', 'Currency Symbol', 'justshoppe-features') . ' (SBD)',
          'SCR' => '&#8360; ' . _x('Seychelles Rupee', 'Currency Symbol', 'justshoppe-features') . ' (SCR)',
          'SDG' => '&#163; ' . _x('Sudanese Pound', 'Currency Symbol', 'justshoppe-features') . ' (SDG)', // ?
          'SEK' => '&#107;&#114; ' . _x('Swedish Krona', 'Currency Symbol', 'justshoppe-features') . ' (SEK)',
          'SGD' => '&#36; ' . _x('Singapore Dollar', 'Currency Symbol', 'justshoppe-features') . ' (SGD)',
          'SHP' => '&#163; ' . _x('Saint Helena Pound', 'Currency Symbol', 'justshoppe-features') . ' (SHP)',
          'SLL' => '&#76;&#101; ' . _x('Leone', 'Currency Symbol', 'justshoppe-features') . ' (SLL)', // ?
          'SOS' => '&#83; ' . _x('Somali Shilling', 'Currency Symbol', 'justshoppe-features') . ' (SOS)',
          'SRD' => '&#36; ' . _x('Suriname Dollar', 'Currency Symbol', 'justshoppe-features') . ' (SRD)',
          'STD' => '&#68;&#98; ' . _x('Dobra', 'Currency Symbol', 'justshoppe-features') . ' (STD)', // ?
          'SVC' => '&#36; ' . _x('El Salvador Colon', 'Currency Symbol', 'justshoppe-features') . ' (SVC)',
          'SYP' => '&#163; ' . _x('Syrian Pound', 'Currency Symbol', 'justshoppe-features') . ' (SYP)',
          'SZL' => '&#76; ' . _x('Lilangeni', 'Currency Symbol', 'justshoppe-features') . ' (SZL)', // ?
          'THB' => '&#3647; ' . _x('Baht', 'Currency Symbol', 'justshoppe-features') . ' (THB)',
          'TJS' => '&#84;&#74;&#83; ' . _x('Somoni', 'Currency Symbol', 'justshoppe-features') . ' (TJS)', // ? TJS (guess)
          'TMT' => '&#109; ' . _x('Manat', 'Currency Symbol', 'justshoppe-features') . ' (TMT)',
          'TND' => '&#1583;.&#1578; ' . _x('Tunisian Dinar', 'Currency Symbol', 'justshoppe-features') . ' (TND)',
          'TOP' => '&#84;&#36; ' . _x('Pa’anga', 'Currency Symbol', 'justshoppe-features') . ' (TOP)',
          'TRY' => '&#8356; ' . _x('Turkish Lira', 'Currency Symbol', 'justshoppe-features') . ' (TRY)', // New Turkey Lira (old symbol used)
          'TTD' => '&#36; ' . _x('Trinidad and Tobago Dollar', 'Currency Symbol', 'justshoppe-features') . ' (TTD)',
          'TWD' => '&#78;&#84;&#36; ' . _x('Taiwan Dollar', 'Currency Symbol', 'justshoppe-features') . ' (TWD)',
          'TZS' => 'Sh ' . _x('Tanzanian Shilling', 'Currency Symbol', 'justshoppe-features') . ' (TZS)',
          'UAH' => '&#8372; ' . _x('Hryvnia', 'Currency Symbol', 'justshoppe-features') . ' (UAH)',
          'UGX' => '&#85;&#83;&#104; ' . _x('Uganda Shilling', 'Currency Symbol', 'justshoppe-features') . ' (UGX)',
          'USD' => '&#36; ' . _x('US Dollar', 'Currency Symbol', 'justshoppe-features') . ' (USD)',
          'UYU' => '&#36;&#85; ' . _x('Peso Uruguayo', 'Currency Symbol', 'justshoppe-features') . ' (UYU)',
          'UZS' => '&#1083;&#1074; ' . _x('Uzbekistan Sum', 'Currency Symbol', 'justshoppe-features') . ' (UZS)',
          'VEF' => '&#66;&#115; ' . _x('Bolivar Fuerte', 'Currency Symbol', 'justshoppe-features') . ' (VEF)',
          'VND' => '&#8363; ' . _x('Dong', 'Currency Symbol', 'justshoppe-features') . ' (VND)',
          'VUV' => '&#86;&#84; ' . _x('Vatu', 'Currency Symbol', 'justshoppe-features') . ' (VUV)',
          'WST' => '&#87;&#83;&#36; ' . _x('Tala', 'Currency Symbol', 'justshoppe-features') . ' (WST)',
          'XAF' => '&#70;&#67;&#70;&#65; ' . _x('CFA Franc BCEAO', 'Currency Symbol', 'justshoppe-features') . ' (XAF)',
          'XCD' => '&#36; ' . _x('East Caribbean Dollar', 'Currency Symbol', 'justshoppe-features') . ' (XCD)',
          'XPF' => '&#70; ' . _x('CFP Franc', 'Currency Symbol', 'justshoppe-features') . ' (XPF)',
          'YER' => '&#65020; ' . _x('Yemeni Rial', 'Currency Symbol', 'justshoppe-features') . ' (YER)',
          'ZAR' => '&#82; ' . _x('Rand', 'Currency Symbol', 'justshoppe-features') . ' (ZAR)',
          'ZWL' => '&#90;&#36; ' . _x('Zimbabwe Dollar', 'Currency Symbol', 'justshoppe-features') . ' (ZWL)',
        ],
        'default' => 'USD',
      ]
    );


    $this->add_control(
      'blvb_price',
      [
        'label' => __('Price', 'justshoppe-features'),
        'type' => Controls_Manager::TEXT,
        'default' => '39.99',
      ]
    );
    /* $this->add_control(
       'blvb_currency_symbol_custom',
       [
         'label' => __('Custom Symbol', 'justshoppe-features'),
         'type' => Controls_Manager::TEXT,
         'condition' => [
           'currency_symbol' => 'custom',
         ],
       ]
     );

     $this->add_control(
       'blvb_currency_format',
       [
         'label' => __('Currency Format', 'justshoppe-features'),
         'type' => Controls_Manager::SELECT,
         'options' => [
           '' => '1,234.56 (Default)',
           ',' => '1.234,56',
         ],
       ]
     );*/

    $this->add_control(
      'blvb_sale',
      [
        'label' => __('Sale', 'justshoppe-features'),
        'type' => Controls_Manager::SWITCHER,
        'label_on' => __('On', 'justshoppe-features'),
        'label_off' => __('Off', 'justshoppe-features'),
        'default' => '',
      ]
    );

    $this->add_control(
      'blvb_original_price',
      [
        'label' => __('Original Price', 'justshoppe-features'),
        'type' => Controls_Manager::NUMBER,
        'default' => '59',
        'condition' => [
          'blvb_sale' => 'yes',
        ]
      ]
    );

    $this->add_control(
      'blvb_period',
      [
        'label' => __('Period', 'justshoppe-features'),
        'type' => Controls_Manager::TEXT,
        'default' => __('Monthly', 'justshoppe-features'),
      ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
      'blvb_section_features',
      [
        'label' => __('Features', 'justshoppe-features'),
      ]
    );

    $repeater = new Repeater();

    $repeater->add_control(
      'blvb_item_text',
      [
        'label' => __('Text', 'justshoppe-features'),
        'type' => Controls_Manager::TEXT,
        'default' => __('List Item', 'justshoppe-features'),
      ]
    );

    $default_icon = [
      'value' => 'far fa-check-circle',
      'library' => 'fa-regular',
    ];

    $repeater->add_control(
      'blvb_selected_item_icon',
      [
        'label' => __('Icon', 'justshoppe-features'),
        'type' => Controls_Manager::ICONS,
        'fa4compatibility' => 'blvb_item_icon',
        'default' => $default_icon,
      ]
    );

    $repeater->add_control(
      'blvb_item_icon_color',
      [
        'label' => __('Icon Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} {{CURRENT_ITEM}} i' => 'color: {{VALUE}}',
          '{{WRAPPER}} {{CURRENT_ITEM}} svg' => 'fill: {{VALUE}}',
        ],
      ]
    );

    $this->add_control(
      'blvb_features_list',
      [
        'type' => Controls_Manager::REPEATER,
        'fields' => $repeater->get_controls(),
        'default' => [
          [
            'blvb_item_text' => __('Feature 1', 'justshoppe-features'),
            'selected_item_icon' => $default_icon,
          ],
          [
            'blvb_item_text' => __('Feature 2', 'justshoppe-features'),
            'selected_item_icon' => $default_icon,
          ],
          [
            'blvb_item_text' => __('Feature 3', 'justshoppe-features'),
            'selected_item_icon' => $default_icon,
          ],
        ],
        'title_field' => '{{{ blvb_item_text }}}',
      ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
      'blvb_section_footer',
      [
        'label' => __('Footer', 'justshoppe-features'),
      ]
    );

    $this->add_control(
      'blvb_button_text',
      [
        'label' => __('Button Text', 'justshoppe-features'),
        'type' => Controls_Manager::TEXT,
        'default' => __('Buy Now', 'justshoppe-features'),
      ]
    );

    $this->add_control(
      'blvb_link',
      [
        'label' => __('Link', 'justshoppe-features'),
        'type' => Controls_Manager::URL,
        'placeholder' => __('https://your-link.com', 'justshoppe-features'),
        'default' => [
          'url' => '#',
        ],
        'dynamic' => [
          'active' => true,
        ],
      ]
    );

    $this->add_control(
      'blvb_footer_additional_info',
      [
        'label' => __('Additional Info', 'justshoppe-features'),
        'type' => Controls_Manager::TEXTAREA,
        'default' => __('This is text element', 'justshoppe-features'),
        'rows' => 2,
      ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
      'blvb_section_ribbon',
      [
        'label' => __('Ribbon', 'justshoppe-features'),
      ]
    );

    $this->add_control(
      'blvb_show_ribbon',
      [
        'label' => __('Show', 'justshoppe-features'),
        'type' => Controls_Manager::SWITCHER,
        'default' => 'yes',
        'separator' => 'before',
      ]
    );

    $this->add_control(
      'blvb_ribbon_title',
      [
        'label' => __('Title', 'justshoppe-features'),
        'type' => Controls_Manager::TEXT,
        'default' => __('Popular', 'justshoppe-features'),
        'condition' => [
          'blvb_show_ribbon' => 'yes',
        ],
      ]
    );

    $this->add_control(
      'blvb_ribbon_horizontal_position',
      [
        'label' => __('Horizontal Position', 'justshoppe-features'),
        'type' => Controls_Manager::CHOOSE,
        'label_block' => false,
        'options' => [
          'left' => [
            'title' => __('Left', 'justshoppe-features'),
            'icon' => 'eicon-h-align-left',
          ],
          'right' => [
            'title' => __('Right', 'justshoppe-features'),
            'icon' => 'eicon-h-align-right',
          ],
        ],
        'default' => 'right',
        'condition' => [
          'blvb_show_ribbon' => 'yes',
        ],
      ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
      'blvb_section_header_style',
      [
        'label' => __('Header', 'justshoppe-features'),
        'tab' => Controls_Manager::TAB_STYLE,
        'show_label' => false,
      ]
    );

    $this->add_control(
      'blvb_header_bg_color',
      [
        'label' => __('Background Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'global' => [
          'default' => Global_Colors::COLOR_PRIMARY,
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__header' => 'background-color: {{VALUE}}',
        ],
      ]
    );

    $this->add_responsive_control(
      'blvb_header_padding',
      [
        'label' => __('Padding', 'justshoppe-features'),
        'type' => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%', 'em'],
        'default' => [
          'top' => '12',
          'right' => '20',
          'bottom' => '22',
          'left' => '20',
          'unit' => 'px',
          'isLinked' => false
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
      ]
    );

    $this->add_control(
      'blvb_heading_heading_style',
      [
        'label' => __('Title', 'justshoppe-features'),
        'type' => Controls_Manager::HEADING,
        'separator' => 'before',
      ]
    );

    $this->add_control(
      'blvb_heading_color',
      [
        'label' => __('Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__heading' => 'color: {{VALUE}}',
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'blvb_heading_typography',
        'fields_options' => [
          'font_size' => [
            'default' => ['unit' => 'px', 'size' => 32]
          ],
          'line_height' => [
            'default' => ['unit' => 'em', 'size' => 1.6]
          ],
          'font_weight' => [
            'default' => 800,//['unit' => 'px', 'size' => 0.5]
          ],
        ],
        'selector' => '{{WRAPPER}} .blvb-pricing-table__heading',
        'global' => [
          'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
        ],
      ]
    );

    $this->add_control(
      'blvb_heading_sub_heading_style',
      [
        'label' => __('Description', 'justshoppe-features'),
        'type' => Controls_Manager::HEADING,
        'separator' => 'before',
      ]
    );
    $this->add_control(
      'blvb_heading_sub_color',
      [
        'label' => __('Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__subheading' => 'color: {{VALUE}}',
        ],
      ]
    );

    /*    $this->add_control(
          'blvb_sub_heading_color',
          [
            'label' => __('Color', 'justshoppe-features'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
              '{{WRAPPER}} .blvb-pricing-table__subheading' => 'color: {{VALUE}}',
            ],
          ]
        );*/

    $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'blvb_sub_heading_typography',
        'fields_options' => [
          'font_size' => [
            'default' => ['unit' => 'px', 'size' => 16]
          ],
          'line_height' => [
            'default' => ['unit' => 'em', 'size' => 1]
          ],
          'letter_spacing' => [
            'default' => ['unit' => 'px', 'size' => 0.6]
          ],
          'font_weight' => [
            'default' => 300,
          ],
        ],
        'selector' => '{{WRAPPER}} .blvb-pricing-table__subheading',
        'global' => [
          'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
        ],
      ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
      'blvb_section_pricing_element_style',
      [
        'label' => __('Pricing', 'justshoppe-features'),
        'tab' => Controls_Manager::TAB_STYLE,
        'show_label' => false,
      ]
    );

    $this->add_control(
      'blvb_pricing_element_bg_color',
      [
        'label' => __( 'Background Color', 'justshoppe-features' ),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__price' => 'background-color: {{VALUE}}',
        ],
      ]
    );

    $this->add_responsive_control(
      'blvb_pricing_element_padding',
      [
        'label' => __('Padding', 'justshoppe-features'),
        'type' => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%', 'em'],
        'default' => [
          'top' => '40',
          'right' => '40',
          'bottom' => '6',
          'left' => '40',
          'unit' => 'px',
          'isLinked' => false
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
      ]
    );

    $this->add_control(
      'blvb_price_color',
      [
        'label' => __('Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'global' => [
          'default' => Global_Colors::COLOR_SECONDARY,
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__currency, {{WRAPPER}} .blvb-pricing-table__integer-part, {{WRAPPER}} .blvb-pricing-table__fractional-part' => 'color: {{VALUE}}',
        ],
        'separator' => 'before',
      ]
    );

    $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'blvb_price_typography',
        'fields_options' => [
          'font_size' => [
            'default' => ['unit' => 'px', 'size' => 64]
          ],
          'line_height' => [
            'default' => ['unit' => 'em', 'size' => 0.1]
          ],
          'font_weight' => [
            'default' => 800,//['unit' => 'px', 'size' => 0.5]
          ],
        ],
        'selector' => '{{WRAPPER}} .blvb-pricing-table__price',
        'global' => [
          'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
        ],
      ]
    );

    $this->add_control(
      'blvb_heading_currency_style',
      [
        'label' => __('Currency Symbol', 'justshoppe-features'),
        'type' => Controls_Manager::HEADING,
        'separator' => 'before',
        'condition' => [
          'blvb_currency_symbol!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_currency_size',
      [
        'label' => __('Size', 'justshoppe-features'),
        'type' => Controls_Manager::SLIDER,
        'range' => [
          'px' => [
            'min' => 0,
            'max' => 100,
          ],
        ],
        'default' => ['unit' => 'px', 'size' => 24],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__currency' => 'font-size: calc({{SIZE}}em/100)',
        ],
        'condition' => [
          'blvb_currency_symbol!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_currency_position',
      [
        'label' => __('Position', 'justshoppe-features'),
        'type' => Controls_Manager::CHOOSE,
        'label_block' => false,
        'default' => 'before',
        'options' => [
          'before' => [
            'title' => __('Before', 'justshoppe-features'),
            'icon' => 'eicon-h-align-left',
          ],
          'after' => [
            'title' => __('After', 'justshoppe-features'),
            'icon' => 'eicon-h-align-right',
          ],
        ],
      ]
    );

    $this->add_control(
      'blvb_currency_vertical_position',
      [
        'label' => __('Vertical Position', 'justshoppe-features'),
        'type' => Controls_Manager::CHOOSE,
        'label_block' => false,
        'options' => [
          'top' => [
            'title' => __('Top', 'justshoppe-features'),
            'icon' => 'eicon-v-align-top',
          ],
          'middle' => [
            'title' => __('Middle', 'justshoppe-features'),
            'icon' => 'eicon-v-align-middle',
          ],
          'bottom' => [
            'title' => __('Bottom', 'justshoppe-features'),
            'icon' => 'eicon-v-align-bottom',
          ],
        ],
//        'default' => 'top',
        'selectors_dictionary' => [
          'top' => 'flex-start',
          'middle' => 'center',
          'bottom' => 'flex-end',
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__currency' => 'align-self: {{VALUE}}',
        ],
        'condition' => [
          'blvb_currency_symbol!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_fractional_part_style',
      [
        'label' => __( 'Fractional Part', 'justshoppe-features' ),
        'type' => Controls_Manager::HEADING,
        'separator' => 'before',
      ]
    );

    $this->add_control(
      'blvb_fractional-part_size',
      [
        'label' => __( 'Size', 'justshoppe-features' ),
        'type' => Controls_Manager::SLIDER,
        'range' => [
          'px' => [
            'min' => 0,
            'max' => 100,
          ],
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__fractional-part' => 'font-size: calc({{SIZE}}em/100)',
        ],
      ]
    );

    $this->add_control(
      'blvb_fractional_part_vertical_position',
      [
        'label' => __( 'Vertical Position', 'justshoppe-features' ),
        'type' => Controls_Manager::CHOOSE,
        'options' => [
          'top' => [
            'title' => __( 'Top', 'justshoppe-features' ),
            'icon' => 'eicon-v-align-top',
          ],
          'middle' => [
            'title' => __( 'Middle', 'justshoppe-features' ),
            'icon' => 'eicon-v-align-middle',
          ],
          'bottom' => [
            'title' => __( 'Bottom', 'justshoppe-features' ),
            'icon' => 'eicon-v-align-bottom',
          ],
        ],
        'default' => 'top',
        'selectors_dictionary' => [
          'top' => 'flex-start',
          'middle' => 'center',
          'bottom' => 'flex-end',
        ],
        'condition' => ['blvb_period_position!' => 'beside'],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__after-price' => 'justify-content: {{VALUE}}',
        ],
      ]
    );

    $this->add_control(
      'blvb_heading_original_price_style',
      [
        'label' => __('Original Price', 'justshoppe-features'),
        'type' => Controls_Manager::HEADING,
        'separator' => 'before',
        'condition' => [
          'blvb_sale' => 'yes',
          'blvb_original_price!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_original_price_color',
      [
        'label' => __('Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'global' => [
          'default' => Global_Colors::COLOR_SECONDARY,
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__original-price' => 'color: {{VALUE}}',
        ],
        'condition' => [
          'blvb_sale' => 'yes',
          'blvb_original_price!' => '',
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'blvb_original_price_typography',
        'selector' => '{{WRAPPER}} .blvb-pricing-table__original-price',
        'global' => [
          'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
        ],
        'condition' => [
          'blvb_sale' => 'yes',
          'blvb_original_price!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_original_price_vertical_position',
      [
        'label' => __('Vertical Position', 'justshoppe-features'),
        'type' => Controls_Manager::CHOOSE,
        'label_block' => false,
        'options' => [
          'top' => [
            'title' => __('Top', 'justshoppe-features'),
            'icon' => 'eicon-v-align-top',
          ],
          'middle' => [
            'title' => __('Middle', 'justshoppe-features'),
            'icon' => 'eicon-v-align-middle',
          ],
          'bottom' => [
            'title' => __('Bottom', 'justshoppe-features'),
            'icon' => 'eicon-v-align-bottom',
          ],
        ],
        'selectors_dictionary' => [
          'top' => 'flex-start',
          'middle' => 'center',
          'bottom' => 'flex-end',
        ],
        'default' => 'bottom',
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__original-price' => 'align-self: {{VALUE}}',
        ],
        'condition' => [
          'blvb_sale' => 'yes',
          'blvb_original_price!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_heading_period_style',
      [
        'label' => __('Period', 'justshoppe-features'),
        'type' => Controls_Manager::HEADING,
        'separator' => 'before',
        'condition' => [
          'blvb_period!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_period_color',
      [
        'label' => __('Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'global' => [
          'default' => Global_Colors::COLOR_SECONDARY,
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__period' => 'color: {{VALUE}}',
        ],
        'condition' => [
          'blvb_period!' => '',
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'blvb_period_typography',
        'selector' => '{{WRAPPER}} .blvb-pricing-table__period',
        'fields_options' => [
          'line_height' => [
            'default' => ['unit' => 'em', 'size' => 2.5]
          ],
          'font_weight' => [
            'default' => 400,
          ],
          'letter_spacing' => [
            ['unit' => 'px', 'size' => 0]
          ]
        ],
        'global' => [
          'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
        ],
        'condition' => [
          'blvb_period!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_period_position',
      [
        'label' => __( 'Position', 'justshoppe-features' ),
        'type' => Controls_Manager::SELECT,
        'label_block' => false,
        'options' => [
          'below' => __( 'Below', 'justshoppe-features' ),
          'beside' => __( 'Beside', 'justshoppe-features' ),
        ],
        'default' => 'below',
        'condition' => [
          'blvb_period!' => '',
          'blvb_currency_position!' => 'after',
        ],
      ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
      'blvb_section_features_list_style',
      [
        'label' => __('Features', 'justshoppe-features'),
        'tab' => Controls_Manager::TAB_STYLE,
        'show_label' => false,
      ]
    );

    $this->add_control(
      'blvb_features_list_bg_color',
      [
        'label' => __( 'Background Color', 'justshoppe-features' ),
        'type' => Controls_Manager::COLOR,
        'separator' => 'before',
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__features-list' => 'background-color: {{VALUE}}',
        ],
      ]
    );

    $this->add_responsive_control(
      'blvb_features_list_padding',
      [
        'label' => __('Padding', 'justshoppe-features'),
        'type' => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%', 'em'],
        'default' => [
          'top' => '8',
          'right' => '8',
          'bottom' => '8',
          'left' => '8',
          'unit' => 'px',
          'isLinked' => true
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__features-list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
          '{{WRAPPER}} .blvb-pricing-table__features-list li' => 'padding: {{BOTTOM}}{{UNIT}} 0 0 0;',

          '{{WRAPPER}} .blvb-pricing-table__features-list li:before' => 'margin: 0 0 {{TOP}}{{UNIT}} 0;',
        ],
      ]
    );

    $this->add_control(
      'blvb_features_list_color',
      [
        'label' => __('Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'global' => [
          'default' => Global_Colors::COLOR_TEXT,
        ],
        'separator' => 'before',
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__features-list' => 'color: {{VALUE}}',
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'blvb_features_list_typography',
        'fields_options' => [
          'font_size' => [
            'default' => ['unit' => 'px', 'size' => 16]
          ],
          'font_weight' => [
            'default' => 500,
          ],
        ],
        'selector' => '{{WRAPPER}} .blvb-pricing-table__features-list li',
        'global' => [
          'default' => Global_Typography::TYPOGRAPHY_TEXT,
        ],
      ]
    );

    $this->add_control(
      'blvb_features_list_alignment',
      [
        'label' => __('Alignment', 'justshoppe-features'),
        'type' => Controls_Manager::CHOOSE,
        'label_block' => false,
        'default' => 'center',
        'options' => [
          'left' => [
            'title' => __('Left', 'justshoppe-features'),
            'icon' => 'fa fa-align-left',
          ],
          'center' => [
            'title' => __('Center', 'justshoppe-features'),
            'icon' => 'fa fa-align-center',
          ],
          'right' => [
            'title' => __('Right', 'justshoppe-features'),
            'icon' => 'fa fa-align-right',
          ],
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__features-list' => 'text-align: {{VALUE}}',
        ],
      ]
    );

    $this->add_responsive_control(
      'blvb_item_width',
      [
        'label' => __('Width', 'justshoppe-features'),
        'type' => Controls_Manager::SLIDER,
        'range' => [
          '%' => [
            'min' => 25,
            'max' => 100,
          ],
        ],
        'default' => ['unit' => '%', 'size' => 100],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__feature-inner' => 'margin-left: calc((100% - {{SIZE}}%)/2); margin-right: calc((100% - {{SIZE}}%)/2)',
        ],
      ]
    );

    $this->add_control(
      'blvb_list_divider',
      [
        'label' => __('Divider', 'justshoppe-features'),
        'type' => Controls_Manager::SWITCHER,
        'default' => 'no',
        'separator' => 'before',
      ]
    );

    $this->add_control(
      'blvb_divider_style',
      [
        'label' => __( 'Style', 'justshoppe-features' ),
        'type' => Controls_Manager::SELECT,
        'options' => [
          'solid' => __( 'Solid', 'justshoppe-features' ),
          'double' => __( 'Double', 'justshoppe-features' ),
          'dotted' => __( 'Dotted', 'justshoppe-features' ),
          'dashed' => __( 'Dashed', 'justshoppe-features' ),
        ],
        'default' => 'solid',
        'condition' => [
          'list_divider' => 'yes',
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__features-list li:before' => 'border-top-style: {{VALUE}};',
        ],
      ]
    );

    $this->add_control(
      'blvb_divider_color',
      [
        'label' => __('Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'default' => '#ddd',
        'global' => [
          'default' => Global_Colors::COLOR_TEXT,
        ],
        'condition' => [
          'blvb_list_divider' => 'yes',
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__features-list li:before' => 'border-top-color: {{VALUE}};',
        ],
      ]
    );

    $this->add_control(
      'blvb_divider_weight',
      [
        'label' => __('Weight', 'justshoppe-features'),
        'type' => Controls_Manager::SLIDER,
        'default' => [
          'size' => 2,
          'unit' => 'px',
        ],
        'range' => [
          'px' => [
            'min' => 1,
            'max' => 10,
          ],
        ],
        'condition' => [
          'blvb_list_divider' => 'yes',
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__features-list li:before' => 'border-top-width: {{SIZE}}{{UNIT}};',
        ],
      ]
    );

    $this->add_control(
      'blvb_divider_width',
      [
        'label' => __('Width', 'justshoppe-features'),
        'type' => Controls_Manager::SLIDER,
        'condition' => [
          'blvb_list_divider' => 'yes',
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__features-list li:before' => 'margin-left: calc((100% - {{SIZE}}%)/2); margin-right: calc((100% - {{SIZE}}%)/2)',
        ],
      ]
    );

    $this->add_control(
      'blvb_divider_gap',
      [
        'label' => __( 'Gap', 'justshoppe-features' ),
        'type' => Controls_Manager::SLIDER,
        'default' => [
          'size' => 15,
          'unit' => 'px',
        ],
        'range' => [
          'px' => [
            'min' => 1,
            'max' => 50,
          ],
        ],
        'condition' => [
          'list_divider' => 'yes',
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__features-list li:before' => 'margin-top: {{SIZE}}{{UNIT}}; margin-bottom: {{SIZE}}{{UNIT}}',
        ],
      ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
      'blvb_section_footer_style',
      [
        'label' => __('Footer', 'justshoppe-features'),
        'tab' => Controls_Manager::TAB_STYLE,
        'show_label' => false,
      ]
    );

    $this->add_control(
      'blvb_footer_bg_color',
      [
        'label' => __('Background Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__footer' => 'background-color: {{VALUE}}',
        ],
      ]
    );

    $this->add_responsive_control(
      'blvb_footer_padding',
      [
        'label' => __('Padding', 'justshoppe-features'),
        'type' => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%', 'em'],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
      ]
    );




    $this->add_control(
      'blvb_heading_footer_button',
      [
        'label' => __('Button', 'justshoppe-features'),
        'type' => Controls_Manager::HEADING,
        'separator' => 'before',
        'condition' => [
          'blvb_button_text!' => '',
        ],
      ]
    );



    $this->add_control(
      'blvb_button_size',
      [
        'label' => __('Size', 'justshoppe-features'),
        'type' => Controls_Manager::SELECT,
        'default' => 'sm',
        'options' => [
          'xs' => __('Extra Small', 'justshoppe-features'),
          'sm' => __('Small', 'justshoppe-features'),
          'md' => __('Medium', 'justshoppe-features'),
          'lg' => __('Large', 'justshoppe-features'),
          'xl' => __('Extra Large', 'justshoppe-features'),
        ],
        'condition' => [
          'blvb_button_text!' => '',
        ],
      ]
    );

    $this->start_controls_tabs('tabs_button_style');

    $this->start_controls_tab(
      'blvb_tab_button_normal',
      [
        'label' => __('Normal', 'justshoppe-features'),
        'condition' => [
          'blvb_button_text!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_button_text_color',
      [
        'label' => __('Text Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'default' => '',
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__button' => 'color: {{VALUE}};',
        ],
        'condition' => [
          'blvb_button_text!' => '',
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'blvb_button_typography',
        'global' => [
          'default' => Global_Typography::TYPOGRAPHY_ACCENT,
        ],
        'selector' => '{{WRAPPER}} .blvb-pricing-table__button',
        'condition' => [
          'blvb_button_text!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_button_background_color',
      [
        'label' => __('Background Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'global' => [
          'default' => Global_Colors::COLOR_ACCENT,
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__button' => 'background-color: {{VALUE}};',
        ],
        'condition' => [
          'blvb_button_text!' => '',
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Border::get_type(), [
        'name' => 'blvb_button_border',
        'placeholder' => '1px',
        'default' => '1px',
        'selector' => '{{WRAPPER}} .blvb-pricing-table__button',
        'condition' => [
          'blvb_button_text!' => '',
        ],
        'separator' => 'before',
      ]
    );

    $this->add_control(
      'blvb_button_border_radius',
      [
        'label' => __('Border Radius', 'justshoppe-features'),
        'type' => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%'],
        'default' => [
          'top' => '30',
          'right' => '30',
          'bottom' => '30',
          'left' => '30',
          'unit' => 'px',
          'isLinked' => true
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        'condition' => [
          'blvb_button_text!' => '',
        ],
      ]
    );

    $this->add_responsive_control(
      'blvb_button_text_padding',
      [
        'label' => __('Padding', 'justshoppe-features'),
        'type' => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', 'em', '%'],
        'default' => [
          'top' => '10',
          'right' => '80',
          'bottom' => '10',
          'left' => '80',
          'unit' => 'px',
          'isLinked' => false
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        'condition' => [
          'blvb_button_text!' => '',
        ],
      ]
    );

    $this->end_controls_tab();

    $this->start_controls_tab(
      'blvb_tab_button_hover',
      [
        'label' => __('Hover', 'justshoppe-features'),
        'condition' => [
          'blvb_button_text!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_button_hover_color',
      [
        'label' => __('Text Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__button:hover' => 'color: {{VALUE}};',
        ],
        'condition' => [
          'blvb_button_text!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_button_background_hover_color',
      [
        'label' => __('Background Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__button:hover' => 'background-color: {{VALUE}};',
        ],
        'condition' => [
          'blvb_button_text!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_button_hover_border_color',
      [
        'label' => __('Border Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__button:hover' => 'border-color: {{VALUE}};',
        ],
        'condition' => [
          'blvb_button_text!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_button_hover_animation',
      [
        'label' => __('Animation', 'justshoppe-features'),
        'type' => Controls_Manager::HOVER_ANIMATION,
        'condition' => [
          'blvb_button_text!' => '',
        ],
      ]
    );

    $this->end_controls_tab();

    $this->end_controls_tabs();

    $this->add_control(
      'blvb_heading_additional_info',
      [
        'label' => __('Additional Info', 'justshoppe-features'),
        'type' => Controls_Manager::HEADING,
        'separator' => 'before',
        'condition' => [
          'blvb_footer_additional_info!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_additional_info_color',
      [
        'label' => __('Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'global' => [
          'default' => Global_Colors::COLOR_TEXT,
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__additional_info' => 'color: {{VALUE}}',
        ],
        'condition' => [
          'blvb_footer_additional_info!' => '',
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'blvb_additional_info_typography',
        'fields_options' => [
          'font_size' => [
            'default' => ['unit' => 'px', 'size' => 16]
          ],
          'line_height' => [
            'default' => ['unit' => 'em', 'size' => 0.9]
          ],
          'font_weight' => [
            'default' => 500,
          ],
        ],
        'selector' => '{{WRAPPER}} .blvb-pricing-table__additional_info',
        'global' => [
          'default' => Global_Typography::TYPOGRAPHY_TEXT,
        ],
        'condition' => [
          'blvb_footer_additional_info!' => '',
        ],
      ]
    );

    $this->add_control(
      'blvb_additional_info_margin',
      [
        'label' => __('Margin', 'justshoppe-features'),
        'type' => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%', 'em'],
        'default' => [
          'top' => 20,
          'right' => 10,
          'bottom' => 30,
          'left' => 10,
          'unit' => 'px',
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__additional_info' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
        ],
        'condition' => [
          'blvb_footer_additional_info!' => '',
        ],
      ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
      'blvb_section_ribbon_style',
      [
        'label' => __('Ribbon', 'justshoppe-features'),
        'tab' => Controls_Manager::TAB_STYLE,
        'show_label' => false,
        'condition' => [
          'blvb_show_ribbon' => 'yes',
        ],
      ]
    );

    $this->add_control(
      'blvb_ribbon_bg_color',
      [
        'label' => __('Background Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'global' => [
          'default' => Global_Colors::COLOR_ACCENT,
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__ribbon-inner' => 'background-color: {{VALUE}}',
        ],
      ]
    );

    $ribbon_distance_transform = is_rtl() ? 'translateY(-50%) translateX({{SIZE}}{{UNIT}}) rotate(-45deg)' : 'translateY(-50%) translateX(-50%) translateX({{SIZE}}{{UNIT}}) rotate(-45deg)';

    $this->add_responsive_control(
      'blvb_ribbon_distance',
      [
        'label' => __('Distance', 'justshoppe-features'),
        'type' => Controls_Manager::SLIDER,
        'range' => [
          'px' => [
            'min' => 0,
            'max' => 50,
          ],
        ],
        'default' => ['unit' => 'px', 'size' => 40],
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__ribbon-inner' => 'margin-top: {{SIZE}}{{UNIT}}; transform: ' . $ribbon_distance_transform,
        ],
      ]
    );

    $this->add_control(
      'blvb_ribbon_text_color',
      [
        'label' => __('Text Color', 'justshoppe-features'),
        'type' => Controls_Manager::COLOR,
        'default' => '#ffffff',
        'separator' => 'before',
        'selectors' => [
          '{{WRAPPER}} .blvb-pricing-table__ribbon-inner' => 'color: {{VALUE}}',
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'blvb_ribbon_typography',
        'fields_options' => [
          'font_size' => [
            'default' => ['unit' => 'px', 'size' => 16]
          ],
        ],
        'selector' => '{{WRAPPER}} .blvb-pricing-table__ribbon-inner',
        'global' => [
          'default' => Global_Typography::TYPOGRAPHY_ACCENT,
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Box_Shadow::get_type(),
      [
        'name' => 'blvb_box_shadow',
        'selector' => '{{WRAPPER}} .blvb-pricing-table__ribbon-inner',
      ]
    );

    $this->end_controls_section();
  }

  private function render_currency_symbol($symbol, $location){
    $currency_position = $this->get_settings('blvb_currency_position');
    $location_setting = !empty($currency_position) ? $currency_position : 'before';
    if(!empty($symbol) && $location === $location_setting) {
      echo '<span class="blvb-pricing-table__currency blvb-currency--' . $location . '">' . $symbol . '</span>';
    }
  }

  private function get_currency_symbol($symbol_name){
    $symbols = [
      'AED' => '&#1583;.&#1573;', // ?
      'AFN' => '&#65;&#102;',
      'ALL' => '&#76;&#101;&#107;',
      'AMD' => 'Դ',
      'ANG' => '&#402;',
      'AOA' => '&#75;&#122;', // ?
      'ARS' => '&#36;',
      'AUD' => '&#36;',
      'AWG' => '&#402;',
      'AZN' => '&#1084;&#1072;&#1085;',
      'BAM' => '&#75;&#77;',
      'BBD' => '&#36;',
      'BDT' => '&#2547;', // ?
      'BGN' => '&#1083;&#1074;',
      'BHD' => '.&#1583;.&#1576;', // ?
      'BIF' => '&#70;&#66;&#117;', // ?
      'BMD' => '&#36;',
      'BND' => '&#36;',
      'BOB' => '&#36;&#98;',
      'BRL' => '&#82;&#36;',
      'BSD' => '&#36;',
      'BTN' => '&#78;&#117;&#46;', // ?
      'BWP' => '&#80;',
      'BYR' => '&#112;&#46;',
      'BZD' => '&#66;&#90;&#36;',
      'CAD' => '&#36;',
      'CDF' => '&#70;&#67;',
      'CHF' => '&#67;&#72;&#70;',
      'CLP' => '&#36;',
      'CNY' => '&#165;',
      'COP' => '&#36;',
      'CRC' => '&#8353;',
      'CUP' => '&#8396;',
      'CVE' => '&#36;', // ?
      'CZK' => '&#75;&#269;',
      'DJF' => '&#70;&#100;&#106;', // ?
      'DKK' => '&#107;&#114;',
      'DOP' => '&#82;&#68;&#36;',
      'DZD' => '&#1583;&#1580;', // ?
      'EGP' => '&#163;',
      'ETB' => '&#66;&#114;',
      'EUR' => '&#8364;',
      'FJD' => '&#36;',
      'FKP' => '&#163;',
      'GBP' => '&#163;',
      'GEL' => '&#4314;', // ?
      'GHS' => '&#162;',
      'GIP' => '&#163;',
      'GMD' => '&#68;', // ?
      'GNF' => '&#70;&#71;', // ?
      'GTQ' => '&#81;',
      'GYD' => '&#36;',
      'HKD' => '&#36;',
      'HNL' => '&#76;',
      'HRK' => '&#107;&#110;',
      'HTG' => '&#71;', // ?
      'HUF' => '&#70;&#116;',
      'IDR' => '&#82;&#112;',
      'ILS' => '&#8362;',
      'INR' => '&#8377;',
      'IQD' => '&#1593;.&#1583;', // ?
      'IRR' => '&#65020;',
      'ISK' => '&#107;&#114;',
      'JEP' => '&#163;',
      'JMD' => '&#74;&#36;',
      'JOD' => '&#74;&#68;', // ?
      'JPY' => '&#165;',
      'KES' => '&#75;&#83;&#104;', // ?
      'KGS' => '&#1083;&#1074;',
      'KHR' => '&#6107;',
      'KMF' => '&#67;&#70;', // ?
      'KPW' => '&#8361;',
      'KRW' => '&#8361;',
      'KWD' => '&#1583;.&#1603;', // ?
      'KYD' => '&#36;',
      'KZT' => '&#1083;&#1074;',
      'LAK' => '&#8365;',
      'LBP' => '&#163;',
      'LKR' => '&#8360;',
      'LRD' => '&#36;',
      'LSL' => '&#76;', // ?
      'LTL' => '&#76;&#116;',
      'LVL' => '&#76;&#115;',
      'LYD' => '&#1604;.&#1583;', // ?
      'MAD' => '&#1583;.&#1605;.', //?
      'MDL' => '&#76;',
      'MGA' => '&#65;&#114;', // ?
      'MKD' => '&#1076;&#1077;&#1085;',
      'MMK' => '&#75;',
      'MNT' => '&#8366;',
      'MOP' => '&#77;&#79;&#80;&#36;', // ?
      'MRO' => '&#85;&#77;', // ?
      'MUR' => '&#8360;', // ?
      'MVR' => '.&#1923;', // ?
      'MWK' => '&#77;&#75;',
      'MXN' => '&#36;',
      'MYR' => '&#82;&#77;',
      'MZN' => '&#77;&#84;',
      'NAD' => '&#36;',
      'NGN' => '&#8358;',
      'NIO' => '&#67;&#36;',
      'NOK' => '&#107;&#114;',
      'NPR' => '&#8360;',
      'NZD' => '&#36;',
      'OMR' => '&#65020;',
      'PAB' => '&#66;&#47;&#46;',
      'PEN' => '&#83;&#47;&#46;',
      'PGK' => '&#75;', // ?
      'PHP' => '&#8369;',
      'PKR' => '&#8360;',
      'PLN' => '&#122;&#322;',
      'PYG' => '&#71;&#115;',
      'QAR' => '&#65020;',
      'RON' => '&#108;&#101;&#105;',
      'RSD' => '&#1044;&#1080;&#1085;&#46;',
      'RUB' => '&#1088;&#1091;&#1073;',
      'RWF' => '&#1585;.&#1587;',
      'SAR' => '&#65020;',
      'SBD' => '&#36;',
      'SCR' => '&#8360;',
      'SDG' => '&#163;', // ?
      'SEK' => '&#107;&#114;',
      'SGD' => '&#36;',
      'SHP' => '&#163;',
      'SLL' => '&#76;&#101;', // ?
      'SOS' => '&#83;',
      'SRD' => '&#36;',
      'STD' => '&#68;&#98;', // ?
      'SVC' => '&#36;',
      'SYP' => '&#163;',
      'SZL' => '&#76;', // ?
      'THB' => '&#3647;',
      'TJS' => '&#84;&#74;&#83;', // ? TJS (guess)
      'TMT' => '&#109;',
      'TND' => '&#1583;.&#1578;',
      'TOP' => '&#84;&#36;',
      'TRY' => '&#8356;', // New Turkey Lira (old symbol used)
      'TTD' => '&#36;',
      'TWD' => '&#78;&#84;&#36;',
      'TZS' => 'Sh',
      'UAH' => '&#8372;',
      'UGX' => '&#85;&#83;&#104;',
      'USD' => '&#36;',
      'UYU' => '&#36;&#85;',
      'UZS' => '&#1083;&#1074;',
      'VEF' => '&#66;&#115;',
      'VND' => '&#8363;',
      'VUV' => '&#86;&#84;',
      'WST' => '&#87;&#83;&#36;',
      'XAF' => '&#70;&#67;&#70;&#65;',
      'XCD' => '&#36;',
      'XPF' => '&#70;',
      'YER' => '&#65020;',
      'ZAR' => '&#82;',
      'ZWL' => '&#90;&#36;',
    ];
    return isset($symbols[$symbol_name]) ? $symbols[$symbol_name] : '';
  }

  protected function render() {
    $settings = $this->get_settings_for_display();
    $symbol = '';

    if ( ! empty( $settings['blvb_currency_symbol'] ) ) {
      if ( 'custom' !== $settings['blvb_currency_symbol'] ) {
        $symbol = $this->get_currency_symbol( $settings['blvb_currency_symbol'] );
      } else {
        $symbol = $settings['blvb_currency_symbol_custom'];
      }
    }
    $currency_format = empty( $settings['blvb_currency_format'] ) ? '.' : $settings['blvb_currency_format'];
    $price = explode( $currency_format, $settings['blvb_price'] );
    $intpart = $price[0];
    $fraction = '';
    if ( 2 === count( $price ) ) {
      $fraction = $price[1];
    }

    $this->add_render_attribute( 'blvb_button_text', 'class', [
      'blvb-pricing-table__button',
      'elementor-button',
      'elementor-size-' . $settings['blvb_button_size'],
    ] );

    if ( ! empty( $settings['blvb_link']['url'] ) ) {
      $this->add_link_attributes( 'blvb_button_text', $settings['blvb_link'] );
    }

    if ( ! empty( $settings['blvb_button_hover_animation'] ) ) {
      $this->add_render_attribute( 'blvb_button_text', 'class', 'elementor-animation-' . $settings['button_hover_animation'] );
    }

    $this->add_render_attribute( 'blvb_heading', 'class', 'blvb-pricing-table__heading' );
    $this->add_render_attribute( 'blvb_sub_heading', 'class', 'blvb-pricing-table__subheading' );
    $this->add_render_attribute( 'blvb_period', 'class', [ 'blvb-pricing-table__period', 'elementor-typo-excluded' ] );
    $this->add_render_attribute( 'blvb_footer_additional_info', 'class', 'blvb-pricing-table__additional_info' );
    $this->add_render_attribute( 'blvb_ribbon_title', 'class', 'blvb-pricing-table__ribbon-inner' );

    $this->add_inline_editing_attributes( 'blvb_heading', 'none' );
    $this->add_inline_editing_attributes( 'blvb_sub_heading', 'none' );
    $this->add_inline_editing_attributes( 'blvb_period', 'none' );
    $this->add_inline_editing_attributes( 'blvb_footer_additional_info' );
    $this->add_inline_editing_attributes( 'blvb_button_text' );
    $this->add_inline_editing_attributes( 'blvb_ribbon_title' );

    $period_position = !empty($settings['blvb_period_position']) ? $settings['blvb_period_position'] : 'below';
    $period_element = '<span ' . $this->get_render_attribute_string( 'blvb_period' ) . '>' . $settings['blvb_period'] . '</span>';
    $heading_tag = $settings['blvb_heading_tag'];

    $migration_allowed = Icons_Manager::is_migration_allowed();
    ?>

    <div class="blvb-pricing-table">
      <?php if ( $settings['blvb_heading'] || $settings['blvb_sub_heading'] ) : ?>
        <div class="blvb-pricing-table__header">
          <?php if ( ! empty( $settings['blvb_heading'] ) ) : ?>
            <<?php echo $heading_tag . ' ' . $this->get_render_attribute_string( 'blvb_heading' ); ?>><?php echo $settings['blvb_heading'] . '</' . $heading_tag; ?>>
          <?php endif; ?>

          <?php if ( ! empty( $settings['blvb_sub_heading'] ) ) : ?>
            <span <?php echo $this->get_render_attribute_string( 'blvb_sub_heading' ); ?>><?php echo $settings['blvb_sub_heading']; ?></span>
          <?php endif; ?>
        </div>
      <?php endif; ?>

      <div class="blvb-pricing-table__price">
        <?php if ( 'yes' === $settings['blvb_sale'] && ! empty( $settings['blvb_original_price'] ) ) : ?>
          <div class="blvb-pricing-table__original-price elementor-typo-excluded">
	          <?php
	          $location_setting = !empty( $settings['blvb_currency_position']) ? $settings['blvb_currency_position'] : 'before';
              if ( $location_setting == 'after' ) {
	              echo $settings['blvb_original_price'] . $symbol;
	          } else {
		          echo $symbol . $settings['blvb_original_price'];
	          }?>
          </div>
        <?php endif; ?>
        <?php $this->render_currency_symbol( $symbol, 'before' ); ?>
        <?php if ( ! empty( $intpart ) || 0 <= $intpart ) : ?>
          <span class="blvb-pricing-table__integer-part"><?php echo $intpart; ?></span>
        <?php endif; ?>

        <?php if ( '' !== $fraction || ( ! empty( $settings['blvb_period'] ) && 'beside' === $period_position ) ) : ?>
          <div class="blvb-pricing-table__after-price">
            <span class="blvb-pricing-table__fractional-part"><?php echo $fraction; ?></span>

            <?php if ( ! empty( $settings['blvb_period'] ) && 'beside' === $period_position ) : ?>
              <?php echo $period_element; ?>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <?php $this->render_currency_symbol( $symbol, 'after' ); ?>

        <?php if ( ! empty( $settings['blvb_period'] ) && 'below' === $period_position ) : ?>
          <?php echo $period_element; ?>
        <?php endif; ?>
      </div>

      <?php if ( ! empty( $settings['blvb_features_list'] ) ) : ?>
        <ul class="blvb-pricing-table__features-list">
          <?php
          foreach ( $settings['blvb_features_list'] as $index => $item ) :
            $repeater_setting_key = $this->get_repeater_setting_key( 'blvb_item_text', 'blvb_features_list', $index );
            $this->add_inline_editing_attributes( $repeater_setting_key );

            $migrated = isset( $item['__fa4_migrated']['blvb_selected_item_icon'] );
            // add old default
            if ( ! isset( $item['blvb_item_icon'] ) && ! $migration_allowed ) {
              $item['blvb_item_icon'] = 'fa fa-check-circle';
            }
            $is_new = ! isset( $item['blvb_item_icon'] ) && $migration_allowed;
            ?>
            <li class="elementor-repeater-item-<?php echo $item['_id']; ?>">
              <div class="blvb-pricing-table__feature-inner">
                <?php if ( ! empty( $item['blvb_item_icon'] ) || ! empty( $item['blvb_selected_item_icon'] ) ) :
                  if ( $is_new || $migrated ) :
                    Icons_Manager::render_icon( $item['blvb_selected_item_icon'], [ 'aria-hidden' => 'true' ] );
                  else : ?>
                    <i class="<?php echo esc_attr( $item['blvb_item_icon'] ); ?>" aria-hidden="true"></i>
                  <?php
                  endif;
                endif; ?>
                <?php if ( ! empty( $item['blvb_item_text'] ) ) : ?>
                  <span <?php echo $this->get_render_attribute_string( $repeater_setting_key ); ?>>
										<?php echo $item['blvb_item_text']; ?>
									</span>
                <?php
                else :
                  echo '&nbsp;';
                endif;
                ?>
              </div>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <?php if ( ! empty( $settings['blvb_button_text'] ) || ! empty( $settings['blvb_footer_additional_info'] ) ) : ?>
        <div class="blvb-pricing-table__footer">
          <?php if ( ! empty( $settings['blvb_button_text'] ) ) : ?>
            <a <?php echo $this->get_render_attribute_string( 'blvb_button_text' ); ?>><?php echo $settings['blvb_button_text']; ?></a>
          <?php endif; ?>

          <?php if ( ! empty( $settings['blvb_footer_additional_info'] ) ) : ?>
            <div <?php echo $this->get_render_attribute_string( 'blvb_footer_additional_info' ); ?>><?php echo $settings['blvb_footer_additional_info']; ?></div>
          <?php endif; ?>
        </div>
      <?php endif; ?>
    </div>

    <?php
    if ( 'yes' === $settings['blvb_show_ribbon'] && ! empty( $settings['blvb_ribbon_title'] ) ) :
      $this->add_render_attribute( 'blvb_ribbon-wrapper', 'class', 'blvb-pricing-table__ribbon' );

      if ( ! empty( $settings['blvb_ribbon_horizontal_position'] ) ) :
        $this->add_render_attribute( 'blvb_ribbon-wrapper', 'class', 'blvb-ribbon-' . $settings['blvb_ribbon_horizontal_position'] );
      endif;

      ?>
      <div <?php echo $this->get_render_attribute_string( 'blvb_ribbon-wrapper' ); ?>>
        <div <?php echo $this->get_render_attribute_string( 'blvb_ribbon_title' ); ?>><?php echo $settings['blvb_ribbon_title']; ?></div>
      </div>
    <?php
    endif;
  }
}

\Elementor\Plugin::instance()->widgets_manager->register(new Pricing_Table());
