<?php
namespace Bolvo_Builder;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color as Scheme_Color;
use Elementor\Core\Schemes\Typography as Scheme_Typography;
use Elementor\Widget_Base;
use Bolvo_Builder\DynamicTags\Module as TagsModule;

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

class Animated_Headline extends Widget_Base {

  public function get_name() {
    return Builder::$prefix . 'animated-headline';
  }

  public function get_title() {
    return __( 'Animated Headline', 'justshoppe-features' );
  }

  public function get_icon() {
    return 'blvb-animated-heading blvb-widget-icon';
  }

  public function get_categories() {
    return ['bolvo-widgets'];
  }

  public function get_keywords() {
    return [ 'headline', 'heading', 'animation', 'title', 'text' ];
  }

  protected function register_controls() {
    $this->start_controls_section(
      'text_elements',
      [
        'label' => __( 'Headline', 'justshoppe-features' ),
      ]
    );

    $this->add_control(
      'headline_style',
      [
        'label' => __( 'Style', 'justshoppe-features' ),
        'type' => Controls_Manager::SELECT,
        'default' => 'highlight',
        'options' => [
          'highlight' => __( 'Highlighted', 'justshoppe-features' ),
          'rotate' => __( 'Rotating', 'justshoppe-features' ),
        ],
        'prefix_class' => 'blvb-headline--style-',
        'render_type' => 'template',
        'frontend_available' => true,
      ]
    );

    $this->add_control(
      'animation_type',
      [
        'label' => __( 'Animation', 'justshoppe-features' ),
        'type' => Controls_Manager::SELECT,
        'options' => [
          'typing' => 'Typing',
          'clip' => 'Clip',
          'flip' => 'Flip',
          'swirl' => 'Swirl',
          'blinds' => 'Blinds',
          'drop-in' => 'Drop-in',
          'wave' => 'Wave',
          'slide' => 'Slide',
          'slide-down' => 'Slide Down',
        ],
        'default' => 'typing',
        'condition' => [
          'headline_style' => 'rotate',
        ],
        'frontend_available' => true,
      ]
    );

    $this->add_control(
      'marker',
      [
        'label' => __( 'Shape', 'justshoppe-features' ),
        'type' => Controls_Manager::SELECT,
        'default' => 'circle',
        'options' => [
          'circle' => _x( 'Circle', 'Shapes', 'justshoppe-features' ),
          'curly' => _x( 'Curly', 'Shapes', 'justshoppe-features' ),
          'underline' => _x( 'Underline', 'Shapes', 'justshoppe-features' ),
          'double' => _x( 'Double', 'Shapes', 'justshoppe-features' ),
          'double_underline' => _x( 'Double Underline', 'Shapes', 'justshoppe-features' ),
          'underline_zigzag' => _x( 'Underline Zigzag', 'Shapes', 'justshoppe-features' ),
          'diagonal' => _x( 'Diagonal', 'Shapes', 'justshoppe-features' ),
          'strikethrough' => _x( 'Strikethrough', 'Shapes', 'justshoppe-features' ),
          'x' => 'X',
        ],
        'render_type' => 'template',
        'condition' => [
          'headline_style' => 'highlight',
        ],
        'frontend_available' => true,
      ]
    );

    $this->add_control(
      'before_text',
      [
        'label' => __( 'Before Text', 'justshoppe-features' ),
        'type' => Controls_Manager::TEXT,
        'dynamic' => [
          'active' => true,
          'categories' => [
            TagsModule::TEXT_CATEGORY,
          ],
        ],
        'default' => __( 'This page is', 'justshoppe-features' ),
        'placeholder' => __( 'Enter your headline', 'justshoppe-features' ),
        'label_block' => true,
        'separator' => 'before',
      ]
    );

    $this->add_control(
      'highlighted_text',
      [
        'label' => __( 'Highlighted Text', 'justshoppe-features' ),
        'type' => Controls_Manager::TEXT,
        'default' => __( 'Amazing', 'justshoppe-features' ),
        'label_block' => true,
        'condition' => [
          'headline_style' => 'highlight',
        ],
        'separator' => 'none',
        'frontend_available' => true,
      ]
    );

    $this->add_control(
      'rotating_text',
      [
        'label' => __( 'Rotating Text', 'justshoppe-features' ),
        'type' => Controls_Manager::TEXTAREA,
        'placeholder' => __( 'Enter each word in a separate line', 'justshoppe-features' ),
        'separator' => 'none',
        'default' => "Better\nBigger\nFaster",
        'rows' => 5,
        'condition' => [
          'headline_style' => 'rotate',
        ],
        'frontend_available' => true,
      ]
    );

    $this->add_control(
      'after_text',
      [
        'label' => __( 'After Text', 'justshoppe-features' ),
        'type' => Controls_Manager::TEXT,
        'dynamic' => [
          'active' => true,
          'categories' => [
            TagsModule::TEXT_CATEGORY,
          ],
        ],
        'placeholder' => __( 'Enter your headline', 'justshoppe-features' ),
        'label_block' => true,
        'separator' => 'none',
      ]
    );

    $this->add_control(
      'link',
      [
        'label' => __( 'Link', 'justshoppe-features' ),
        'type' => Controls_Manager::URL,
        'dynamic' => [
          'active' => true,
        ],
        'separator' => 'before',
      ]
    );

    $this->add_responsive_control(
      'alignment',
      [
        'label' => __( 'Alignment', 'justshoppe-features' ),
        'type' => Controls_Manager::CHOOSE,
        'label_block' => false,
        'options' => [
          'left' => [
            'title' => __( 'Left', 'justshoppe-features' ),
            'icon' => 'fa fa-align-left',
          ],
          'center' => [
            'title' => __( 'Center', 'justshoppe-features' ),
            'icon' => 'fa fa-align-center',
          ],
          'right' => [
            'title' => __( 'Right', 'justshoppe-features' ),
            'icon' => 'fa fa-align-right',
          ],
        ],
        'default' => 'center',
        'selectors' => [
          '{{WRAPPER}} .blvb-headline' => 'text-align: {{VALUE}}',
        ],
      ]
    );

    $this->add_control(
      'tag',
      [
        'label' => __( 'HTML Tag', 'justshoppe-features' ),
        'type' => Controls_Manager::SELECT,
        'options' => [
          'h1' => 'H1',
          'h2' => 'H2',
          'h3' => 'H3',
          'h4' => 'H4',
          'h5' => 'H5',
          'h6' => 'H6',
          'div' => 'div',
          'span' => 'span',
          'p' => 'p',
        ],
        'default' => 'h3',
      ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
      'section_style_marker',
      [
        'label' => __( 'Shape', 'justshoppe-features' ),
        'tab' => Controls_Manager::TAB_STYLE,
        'condition' => [
          'headline_style' => 'highlight',
        ],
      ]
    );

    $this->add_control(
      'marker_color',
      [
        'label' => __( 'Color', 'justshoppe-features' ),
        'type' => Controls_Manager::COLOR,
        'scheme' => [
          'type' => Scheme_Color::get_type(),
          'value' => Scheme_Color::COLOR_4,
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-headline-dynamic-wrapper path' => 'stroke: {{VALUE}}',
        ],
      ]
    );

    $this->add_control(
      'stroke_width',
      [
        'label' => __( 'Width', 'justshoppe-features' ),
        'type' => Controls_Manager::SLIDER,
        'range' => [
          'px' => [
            'min' => 1,
            'max' => 20,
          ],
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-headline-dynamic-wrapper path' => 'stroke-width: {{SIZE}}{{UNIT}}',
        ],
      ]
    );

    $this->add_control(
      'above_content',
      [
        'label' => __( 'Bring to Front', 'justshoppe-features' ),
        'type' => Controls_Manager::SWITCHER,
        'selectors' => [
          '{{WRAPPER}} .blvb-headline-dynamic-wrapper svg' => 'z-index: 2',
          '{{WRAPPER}} .blvb-headline-dynamic-text' => 'z-index: auto',
        ],
      ]
    );

    $this->add_control(
      'rounded_edges',
      [
        'label' => __( 'Rounded Edges', 'justshoppe-features' ),
        'type' => Controls_Manager::SWITCHER,
        'selectors' => [
          '{{WRAPPER}} .blvb-headline-dynamic-wrapper path' => 'stroke-linecap: round; stroke-linejoin: round',
        ],
      ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
      'section_style_text',
      [
        'label' => __( 'Headline', 'justshoppe-features' ),
        'tab' => Controls_Manager::TAB_STYLE,
      ]
    );

    $this->add_control(
      'title_color',
      [
        'label' => __( 'Text Color', 'justshoppe-features' ),
        'type' => Controls_Manager::COLOR,
        'scheme' => [
          'type' => Scheme_Color::get_type(),
          'value' => Scheme_Color::COLOR_2,
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-headline-plain-text' => 'color: {{VALUE}}',

        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'title_typography',
        'scheme' => Scheme_Typography::TYPOGRAPHY_1,
        'selector' => '{{WRAPPER}} .blvb-headline',
      ]
    );

    $this->add_control(
      'heading_words_style',
      [
        'type' => Controls_Manager::HEADING,
        'label' => __( 'Animated Text', 'justshoppe-features' ),
        'separator' => 'before',
      ]
    );

    $this->add_control(
      'words_color',
      [
        'label' => __( 'Text Color', 'justshoppe-features' ),
        'type' => Controls_Manager::COLOR,
        'scheme' => [
          'type' => Scheme_Color::get_type(),
          'value' => Scheme_Color::COLOR_2,
        ],
        'selectors' => [
          '{{WRAPPER}} .blvb-headline-dynamic-text' => 'color: {{VALUE}}',
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'words_typography',
        'scheme' => Scheme_Typography::TYPOGRAPHY_1,
        'selector' => '{{WRAPPER}} .blvb-headline-dynamic-text',
        'exclude' => [ 'font_size' ],
      ]
    );

    $this->end_controls_section();
  }

  protected function render() {
    $settings = $this->get_settings_for_display();

    $tag = $settings['tag'];

    $this->add_render_attribute( 'headline', 'class', 'blvb-headline' );

    if ( 'rotate' === $settings['headline_style'] ) {
      $this->add_render_attribute( 'headline', 'class', 'blvb-headline-animation-type-' . $settings['animation_type'] );

      $is_letter_animation = in_array( $settings['animation_type'], [ 'typing', 'swirl', 'blinds', 'wave' ] );

      if ( $is_letter_animation ) {
        $this->add_render_attribute( 'headline', 'class', 'blvb-headline-letters' );
      }
    }

    if ( ! empty( $settings['link']['url'] ) ) {
      $this->add_render_attribute( 'url', 'href', $settings['link']['url'] );

      if ( $settings['link']['is_external'] ) {
        $this->add_render_attribute( 'url', 'target', '_blank' );
      }

      if ( ! empty( $settings['link']['nofollow'] ) ) {
        $this->add_render_attribute( 'url', 'rel', 'nofollow' );
      }

      echo '<a ' . $this->get_render_attribute_string( 'url' ).' >';
    }

    ?>
    <<?php echo $tag; ?> <?php echo $this->get_render_attribute_string( 'headline' ); ?>>
    <?php if ( ! empty( $settings['before_text'] ) ) : ?>
      <span class="blvb-headline-plain-text blvb-headline-text-wrapper"><?php echo $settings['before_text']; ?></span>
    <?php endif; ?>
    <span class="blvb-headline-dynamic-wrapper blvb-headline-text-wrapper"></span>
    <?php if ( ! empty( $settings['after_text'] ) ) : ?>
      <span class="blvb-headline-plain-text blvb-headline-text-wrapper"><?php echo $settings['after_text']; ?></span>
    <?php endif; ?>
    </<?php echo $tag; ?>>
    <?php

    if ( ! empty( $settings['link']['url'] ) ) {
      echo '</a>';
    }
  }

  protected function content_template() {
    ?>
    <#
    var headlineClasses = 'blvb-headline',
    tag = settings.tag;

    if ( 'rotate' === settings.headline_style ) {
    headlineClasses += ' blvb-headline-animation-type-' + settings.animation_type;

    var isLetterAnimation = -1 !== [ 'typing', 'swirl', 'blinds', 'wave' ].indexOf( settings.animation_type );

    if ( isLetterAnimation ) {
    headlineClasses += ' blvb-headline-letters';
    }
    }

    if ( settings.link.url ) { #>
    <a htef="#">
      <# } #>
      <{{{ tag }}} class="{{{ headlineClasses }}}">
      <# if ( settings.before_text ) { #>
      <span class="blvb-headline-plain-text blvb-headline-text-wrapper">{{{ settings.before_text }}}</span>
      <# } #>

      <# if ( settings.rotating_text ) { #>
      <span class="blvb-headline-dynamic-wrapper blvb-headline-text-wrapper"></span>
      <# } #>

      <# if ( settings.after_text ) { #>
      <span class="blvb-headline-plain-text blvb-headline-text-wrapper">{{{ settings.after_text }}}</span>
      <# } #>
    </{{{ tag }}}>
    <# if ( settings.link.url ) { #>
    <a htef="#">
      <# } #>
    <?php
  }
}

\Elementor\Plugin::instance()->widgets_manager->register(new Animated_Headline());

