<?php
namespace Bolvo_Builder\Widgets\Sticky;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Element_Section;
use Elementor\Widget_Base;

/**
 * Class Sticky
 *
 * @package Bolvo_Builder\Widgets\Sticky
 */
class Sticky extends Widget_Base  {

	public function __construct() {
		$this->add_actions();
	}
	public function get_name() {
		return 'bolvo-sticky';
	}
  public function show_in_panel() {
    return false;
  }

  /**
   * @param Controls_Stack $element
   */
	public function register_custom_controls( Element_Section $element ) {
    $element->start_controls_section(
			'bolvo_section_scrolling_effect',
			[
				'label' => __( 'Scrolling Effect', 'justshoppe-features' ),
				'tab' => Controls_Manager::TAB_ADVANCED,
			]
		);

    $element->add_control(
			'bolvo_sticky',
			[
				'label' => __( 'Sticky', 'justshoppe-features' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'' => __( 'None', 'justshoppe-features' ),
					'top' => __( 'Top', 'justshoppe-features' ),
					'bottom' => __( 'Bottom', 'justshoppe-features' ),
				],
				'render_type' => 'none',
				'frontend_available' => true,
			]
		);

    $element->add_control(
			'bolvo_sticky_on',
			[
				'label' => __( 'Sticky On', 'justshoppe-features' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'label_block' => 'true',
				'default' => [ 'desktop', 'tablet', 'mobile' ],
				'options' => [
					'desktop' => __( 'Desktop', 'justshoppe-features' ),
					'tablet' => __( 'Tablet', 'justshoppe-features' ),
					'mobile' => __( 'Mobile', 'justshoppe-features' ),
				],
				'condition' => [
					'bolvo_sticky!' => '',
				],
				'render_type' => 'none',
				'frontend_available' => true,
			]
		);

    $element->add_control(
			'bolvo_sticky_offset',
			[
				'label' => __( 'Offset', 'justshoppe-features' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 0,
				'min' => 0,
				'max' => 500,
				'required' => true,
				'condition' => [
					'bolvo_sticky!' => '',
				],
				'render_type' => 'none',
				'frontend_available' => true,
			]
		);

    $element->add_control(
			'bolvo_sticky_effects_offset',
			[
				'label' => __( 'Effects Offset', 'justshoppe-features' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 0,
				'min' => 0,
				'max' => 1000,
				'required' => true,
				'condition' => [
					'bolvo_sticky!' => '',
				],
				'render_type' => 'none',
				'frontend_available' => true,
			]
		);

		if ( $element instanceof Widget_Base ) {
      $element->add_control(
				'bolvo_sticky_parent',
				[
					'label' => __( 'Stay In Column', 'justshoppe-features' ),
					'type' => Controls_Manager::SWITCHER,
					'condition' => [
						'bolvo_sticky!' => '',
					],
					'render_type' => 'none',
					'frontend_available' => true,
				]
			);
		}

    $element->end_controls_section();
	}

	private function add_actions() {
		add_action( 'elementor/element/section/section_advanced/after_section_end', [ $this, 'register_custom_controls' ] );
	}
}
\Elementor\Plugin::instance()->widgets_manager->register( new Sticky() );
