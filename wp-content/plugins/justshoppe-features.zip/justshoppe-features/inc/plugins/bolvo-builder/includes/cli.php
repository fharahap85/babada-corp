<?php
namespace Bolvo_Builder;

class CLI {
  protected static $instance = null;

  public static function get_instance() {
    if ( self::$instance === null ) {
      self::$instance = new self();
    }
    return self::$instance;
  }

  public function __construct() {
    if ( class_exists('WP_CLI') ) {
      \WP_CLI::add_command('bolvo-import-template', [ $this, 'import_template' ]);
      \WP_CLI::add_command('bolvo-finalize-import', [ $this, 'finalize_import' ]);
    }
  }

  /**
   * @param $args
   * @param $assoc_args
   *
   * [--template_id=int]
   * : Predefined template id
   *
   * [--template_url=string]
   * : AI recreated template url
   *
   * @return void
   */
  public function import_template( $args, $assoc_args ) {
    require_once BLVB_DIR . "/templates/import/import.php";

    $import = new Import();
    $result = $import->import_site_data( $assoc_args );
    if ( !is_wp_error( $result ) ) {
      \WP_CLI::success( 'Template Install completed. Wait for the finalization.' );
    }
    else {
      \WP_CLI::error( $result->get_error_code() );
    }
  }

  public function finalize_import( $args, $assoc_args ) {
    require_once BLVB_DIR . "/templates/import/import.php";

    $import = new Import();
    //finalize_import
    $import->finalize_import( $assoc_args[ 'template_id' ] , 'bulk');
    \WP_CLI::success( 'Template Import Finalized' );
  }
}