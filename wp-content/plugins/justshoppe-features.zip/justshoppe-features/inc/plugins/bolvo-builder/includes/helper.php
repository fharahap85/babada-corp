<?php
/**
 * Created by PhpStorm.
 * User: mher
 * Date: 7/31/18
 * Time: 4:35 PM
 */

namespace Bolvo_Builder;


class Helper {

  public static function get_post_types($args = array()){
    $defaults = array(
      'exclude_from_search' => false,
    );

    $args = wp_parse_args($args, $defaults);

    $post_types = get_post_types($args, 'objects');
    return $post_types;
  }

  /**
   * Get request value.
   *
   * @param string $key
   * @param string $default_value
   * @param bool $esc_html
   *
   * @return string|array
   */
  public static function get($key, $default_value = '', $esc_html = true) {
    if (isset($_GET[$key])) {
      $value = $_GET[$key];
    }
    elseif (isset($_POST[$key])) {
      $value = $_POST[$key];
    }
    elseif (isset($_REQUEST[$key])) {
      $value = $_REQUEST[$key];
    }
    else {
      $value = $default_value;
    }
    if (is_array($value)) {
      array_walk_recursive($value, array('self', 'validate_data'), $esc_html);
    }
    else {
      self::validate_data($value, $esc_html);
    }
    return $value;
  }

  /**
   * Validate data.
   *
   * @param $value
   * @param $esc_html
   */
  private static function validate_data(&$value, $esc_html) {
    $value = stripslashes($value);
    if ($esc_html) {
      $value = esc_html($value);
    }
  }
}
