<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
define( 'BLVB_VERSION', '1.2.83' );
define( 'BLVB_PREFIX', 'blvb' );
define( 'BLVB_DIR', dirname( __FILE__ ) );
define( 'BLVB_URL', plugins_url( plugin_basename( dirname( __FILE__ ) ) ) );
define( 'BLVB_DEV', FALSE );
define( 'BLVB_DEBUG', FALSE );
define( 'BLVB_ELEMENTOR_MIN_VERSION', '3.5.0' );
if ( class_exists( '\Bolvo_Manager\Helper' ) && method_exists( '\Bolvo_Manager\Helper', 'get_company_name' ) && strtolower( \Bolvo_Manager\Helper::get_company_name() ) !== 'bolvo' ) {
	define( 'BOLVO_WHITE_LABEL', TRUE );
} else {
	define( 'BOLVO_WHITE_LABEL', FALSE );
}
add_action( 'plugins_loaded', 'blvb_define_s3_bucket', 1 );
function blvb_define_s3_bucket() {
	if ( defined( 'BOLVO_S3_BUCKET' ) && 'bolvo-products-testing' === BOLVO_S3_BUCKET ) {
		define( 'BLVB_S3_BUCKET', 'bolvotemplates-testing' );
		define( 'BLVB_DASHBOARD_URL', 'https://testmy.bolvo.com/' );
	} else if ( defined( 'BOLVO_S3_BUCKET' ) && 'bolvo-products-staging' === BOLVO_S3_BUCKET ) {
		define( 'BLVB_S3_BUCKET', 'bolvotemplates-testing' );
		define( 'BLVB_DASHBOARD_URL', 'https://devmy.bolvo.com/' );
	} else {
		define( 'BLVB_S3_BUCKET', 'bolvotemplates-production' );
		define( 'BLVB_DASHBOARD_URL', 'https://my.bolvo.com/' );
	}
}
