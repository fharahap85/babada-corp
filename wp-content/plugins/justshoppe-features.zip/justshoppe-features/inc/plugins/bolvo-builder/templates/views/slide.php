<?php
\Bolvo_Builder\SlideTemplate::print_blvb_template(\Bolvo_Builder\Templates::get_instance()->get_page_template_id());
