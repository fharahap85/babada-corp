<?php

namespace Bolvo_Builder;

class TemplatesRestApi {
  protected static $instance = null;

  public function __construct(){
    self::register_routes();
  }

  private static function register_routes(){

    register_rest_route('bolvoBuilder/templates', '/list',
                        [
                          'methods' => 'GET',
                          'callback' => ['self', 'get_templates'],
                          'permission_callback' => '__return_true',
                        ]
    );

  }

  /**
   * @param $request \WP_REST_Request
   * */
  public static function get_templates(){
    //$post_id = intval($request->get_param('post_id'));

    $templates_slugs = Templates::get_instance()->get_templates_slugs();

    $args = [
      'numberposts' => -1,
      'post_type' => 'elementor_library',
      'post_status' => 'publish',
      'meta_key' => '_elementor_template_type'
    ];

    $templates_list = [];
    $applied_templates = [];

    foreach($templates_slugs as $slug) {
      $args['meta_value'] = $slug;
      $posts = get_posts($args);

      $templates_list[$slug] = $posts;
    }
    return $templates_list;
  }

  public static function get_instance(){
    if(self::$instance === null) {
      self::$instance = new self();
    }
    return self::$instance;
  }
}