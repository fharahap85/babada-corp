<?php
get_header();
do_action('blvb_before_single');
\Bolvo_Builder\SingleTemplate::print_blvb_template(\Bolvo_Builder\Templates::get_instance()->get_page_template_id());
do_action('blvb_after_single');
get_footer();