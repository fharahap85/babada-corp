<?php
namespace Bolvo_Builder;

class Import {

  private $builder_upload_dir;
  private $builder_upload_url;
  private $import_data;

  public function __construct() {

    $wp_upload_dir = wp_upload_dir();
    $this->builder_upload_dir = $wp_upload_dir['basedir'] . '/bolvo-builder/';
    $this->builder_upload_url = $wp_upload_dir['baseurl'] . '/bolvo-builder/';
    include_once ABSPATH . '/wp-admin/includes/image.php';
    // Don't know why user is not logged in, but have to log in again.
    \Bolvo_Manager\User::login_bolvo_user();
  }

  /**
   * @param $template_id
   *
   * @return array|bool|mixed|object|void
   */
  public function get_import_data( $template_id ) {
    if ( !$this->import_data ) {
      $this->import_data = get_option( 'bolvo_template_import_data' );
    }
    if ( FALSE !== $this->import_data ) {
      $data = json_decode($this->import_data, TRUE);
    }
    if ( !empty( $data ) ) {
      return $data;
    }

    return FALSE;
  }

  /**
   * @param array $args
   *
   * @return array|bool|\WP_Error
   */
  public function start_import( $args = [] ) {
    add_option('bolvo_import_in_progress', 1);
    if ( is_array($args) ) {
      $template_id  = !empty($args['template_id']) ? $args['template_id'] : FALSE;
      $template_url = !empty($args['template_url']) ? $args['template_url'] : FALSE;
    } else {
      $template_id  = $args;
      $template_url = FALSE;
    }
    delete_option('bolvo_template_import_data');
    if ( $template_id ) {
      $template = $this->check_template_id($template_id);
      if ( is_wp_error($template) ) {
        return $template;
      }
      $amazon = $this->check_amazon_authorization($template_id);
      if ( is_wp_error($amazon) ) {
        return $amazon;
      }
      $data = $this->prepare_files_for_import( $amazon['url'], $amazon['headers'], $template );
    } else {
      if ( $template_url ) {
        $data = $this->prepare_files_for_import($template_url, ['timeout' => 30], ['slug' => '']);
      }
      else {
        $data = new \WP_Error('invalid_parameters', 'Invalid parameters.' );
      }
    }
    if ( is_wp_error($data) ) {
      return $data;
    }
    // Disable deleting imported data for testing environment .
    if ( !defined( 'BOLVO_S3_BUCKET' ) || 'bolvo-products-testing' !== BOLVO_S3_BUCKET ) {
      $this->delete_last_imported_site_data();
    }
    $this->copy_images_to_upload_folder($data['dir']);
    add_option('bolvo_template_import_data', json_encode($data));

    return TRUE;
  }

  /**
   * @param $template_id
   * @return bool|\WP_Error
   */
  public function import_plugins( $template_id ) {
    $data = $this->get_import_data($template_id);
    if ( FALSE !== $data ) {
      include_once "import-site.php";
      $import = new \Bolvo_Builder\ImportSite();
      $import->set_template_dir($data['dir'], $data['url']);
      $data['plugins_data'] = $import->import_plugins();
      update_option('bolvo_template_import_data', json_encode($data));

      return TRUE;
    }

    return new \WP_Error('invalid_plugins_data', 'Plugins data is invalid.' );
  }

  /**
   * @param $template_id
   * @param array $args
   * @return bool|\WP_Error
   */
  public function import_attachments( $template_id, $args = array() ) {
    $data = $this->get_import_data($template_id);
    if ( FALSE !== $data ) {
      //Add filter to avoid resizing gif images and
      add_filter( 'file_is_displayable_image', function( $result, $path ) use ( $args ) {
        if ( $result === false || ( isset( $args[ 'no_resize' ] ) && 1 == $args[ 'no_resize' ] ) ) {
          return false;
        }
        // this part is copied from file_is_displayable_image()
        $info = @getimagesize($path);
        if ( defined('IMAGETYPE_GIF') && $info[2] === IMAGETYPE_GIF ) {
          return false;
        }
        return $result;
      }, 2, 10 );

      include_once "import-site.php";
      $import = new \Bolvo_Builder\ImportSite();
      $import->set_template_dir($data['dir'], $data['url']);
      $data['attachments'] = $import->import_attachment();
      update_option('bolvo_template_import_data', json_encode($data));

      return TRUE;
    }

    return new \WP_Error('import_attachment_failed', 'Failed to import attachments.' );
  }

  /**
   * @param $template_id
   * @return bool|\WP_Error
   */
  public function import_site( $template_id ) {
    $data = $this->get_import_data($template_id);
    if ( FALSE !== $data ) {
      include_once "import-site.php";
      $import = new \Bolvo_Builder\ImportSite();
      $import->set_template_dir($data['dir'], $data['url']);
      return $import->import( $data['plugins_data'], !isset( $data['attachments'] ) );
    }

    return new \WP_Error('import_data_failed', 'Failed to import site data.' );
  }

  /**
   * @param $template_id
   *
   * @return bool
   */
  public function finalize_import( $template_id, $generate_metadata_mode = '' ) {
    $data = $this->get_import_data($template_id);
    if ( FALSE !== $data ) {

      if ( 'bulk' == $generate_metadata_mode ) {
        include_once "import-site.php";
        $import = new \Bolvo_Builder\ImportSite();
        $import->generate_attachment_meta();
      }

      if ( is_dir( $data['dir'] ) ) {
        flush_rewrite_rules();
        // Regenerate Elementor generated css files.
        \Elementor\Plugin::instance()->files_manager->clear_cache();
        $this->delete_dir( $data['dir'] );
        delete_option('bolvo_import_in_progress');
        // Temporarily changed to direct call to fix non user logged in issue.
        // do_action( 'two_clear_cache' );
        if ( class_exists( '\TenWebOptimizer\OptimizerAdmin' ) ) {
          \TenWebOptimizer\OptimizerAdmin::get_instance();
          \TenWebOptimizer\OptimizerAdmin::clear_cache();
        }
      }

      return TRUE;
    }

    return FALSE;
  }

  /**
   * Deprecated
   *
   * @param $args
   *
   * @return array|bool|\WP_Error
   */
  public function import_site_data( $args = [] ) {
    if ( is_array( $args ) ) {
      $template_id = !empty( $args[ 'template_id' ] ) ? $args[ 'template_id' ] : FALSE;
    }
    else {
      $template_id = $args;
    }
    $result = $this->start_import( $args );
    if ( is_wp_error( $result ) ) {
      return $result;
    }
    $result = $this->import_plugins( $template_id );
    if ( is_wp_error( $result ) ) {
      return $result;
    }
    $result = $this->import_attachments( $template_id );
    if ( is_wp_error( $result ) ) {
      return $result;
    }
    $result = $this->import_site( $template_id );
    if ( is_wp_error( $result ) ) {
      return $result;
    }
    return TRUE;
  }

  /**
   * @param $template_id
   *
   * @return array|int|\WP_Error
   */
  public function import_single_template( $template_id ) {

    $template = $this->check_template_id($template_id);

    if (is_wp_error($template)) {
      return $template;
    }
    $amazon = $this->check_amazon_authorization($template_id);
    if (is_wp_error($amazon)) {
      return $amazon;
    }
    $data = $this->prepare_files_for_import($amazon['url'], $amazon['headers'], $template);
    if (is_wp_error($data)) {
      return $data;
    }
    include_once 'import-template.php';
    $import = new \Bolvo_Builder\ImportTemplate();
    $import->set_template_dir($data['dir'], $data['url']);
    $import_res = $import->import();
    $this->delete_dir($data['dir']);

    return $import_res;
  }

  /**
   * @param array $matches
   *
   * @return string
   * @throws \Exception
   */
	function _json_replace( $matches = [] ) {
		return $matches[1] . '"' . $this->_str_rand(8) . '"';
	}

  /**
   * @param int $length
   *
   * @return string
   * @throws \Exception
   */
	function _str_rand( $length = 64 ) {
		$length = ($length < 8) ? 8 : $length;
		return bin2hex(random_bytes(($length-($length%2))/2));
	}

	/**
   * @param array $args
   *
   * @return array|\WP_Error|null
   */
  public function insert_single_template( $args=[] ) {
    $type = $args['type'];
    $template_id = $args['template_id'];
    $template = $this->check_template_id($template_id, $type);
    if ( is_wp_error($template) ) {
      return $template;
    }
    $amazon = $this->check_amazon_authorization($template_id);
    if ( is_wp_error($amazon) ) {
      return $amazon;
    }
    $data = $this->prepare_files_for_import($amazon['url'], $amazon['headers'], $template);
    if ( is_wp_error($data) ) {
      return $data;
    }
    $template_file = $data['dir'] . 'template.json';
    if ( file_exists($template_file) ) {
      $template_content = file_get_contents($template_file);
      if ( !empty($template_content) ) {
        $template_json = json_decode($template_content, TRUE);
        $template_json_encode = json_encode($template_json['content']);
        $template_optput = preg_replace_callback('|("id":)"[a-z0-9]{8}"|', array(
          &$this,
          '_json_replace',
        ), $template_json_encode);
      }
    }
    $this->delete_dir($data['dir']);
    $success = FALSE;
    $content = [];
    if ( !empty($template_json) && !empty($template_optput) ) {
      $success = TRUE;
      $content = json_decode($template_optput);
    }
    $data = [
      'code' => 200,
      'success' => $success,
      'data' => [ 'content' => $content ],
    ];

    return $data;
  }

  /**
   * @param $file_url string
   *
   * @return array|\WP_Error
   * */
  protected function prepare_files_for_import( $file_url, $headers = [], $template = [] ) {
    $uniqid = uniqid('import-');
    $dir = $this->builder_upload_dir . $uniqid . '/';
    $url = $this->builder_upload_url . $uniqid . '/';
    if ( pathinfo($file_url, PATHINFO_EXTENSION) !== 'zip' ) {
      return new \WP_Error('invalid_file', 'Invalid file ' . $file_url);
    }
    $create_dir = $this->create_directory($dir);
    if ( is_wp_error($create_dir) ) {
      return $create_dir;
    }
    $zip_file = $this->download_file($dir, $file_url, $headers);
    if ( is_wp_error($zip_file) ) {
      return $zip_file;
    }
    $unzip = $this->unzip_file($zip_file, $dir);
    if ( is_wp_error($unzip) ) {
      return $unzip;
    }
    $dir .= $template['slug'] . '/';
    $url .= $template['slug'] . '/';

    return [ "dir" => $dir, "url" => $url, "uniqid" => $uniqid ];
  }

  /**
   * @param $dir
   */
  protected function copy_images_to_upload_folder( $dir ) {
    $attachments_dir = $dir . 'attachments/';
    $wp_upload_dir = wp_upload_dir();
    $files = scandir($attachments_dir);
    foreach ( $files as $file ) {

      if ( $file === '.' || $file === '..' ) {
        continue;
      }
      copy($attachments_dir . $file, $wp_upload_dir['path'] . '/' . $file);
    }
  }

  /**
   * @param $template_id
   *
   * @return array|\WP_Error|null
   */
  private function check_template_id( $template_id, $type = 'site' ) {
    $template = RemoteTemplates::get_instance()->get_templates( $template_id, $type );
    if ( $template === NULL ) {
      return new \WP_Error('invalid_template_id', 'Invalid template id ' . $template_id . '.');
    }

    return $template;
  }

  /**
   * @param $template_id
   *
   * @return array|\WP_Error|null
   */
  private function check_amazon_authorization( $template_id ) {
    $amazon = $this->get_amazon_tokens($template_id);
    if ( $amazon === NULL ) {
      return new \WP_Error('amazon_token_error', 'Amazon token error.');
    }

    return $amazon;
  }

  /**
   * @param $template_id
   *
   * @return array|null
   */
  private function get_amazon_tokens( $template_id ) {
    include_once BOLVO_INCLUDES_DIR . '/class-api.php';
    $url = BOLVO_API_URL .'/templates/' . $template_id . '/request';
    $args = array(
      'method' => 'GET',
    );
    $response = \Bolvo_Manager\Api::get_instance()->request($url, $args);
    if ( $response !== null && !isset($response['error']) ) {
      include_once BOLVO_INCLUDES_DIR . '/class-amazon.php';
      $file = ltrim($response['path'], BLVB_S3_BUCKET);
      $amazon = new \Bolvo_Manager\Amazon($response['key'], $response['secret'], $response['token'], $file, BLVB_S3_BUCKET);

      return $amazon->getRequestData();
    }
    else {
      return NULL;
    }
  }

  /**
   * @param $dir
   * @param $file_url
   * @param $headers
   *
   * @return string|\WP_Error
   */
  private function download_file( $dir, $file_url, $headers ) {
    $file_content = FALSE;
    $response = wp_remote_get( $file_url, array( 'headers' => $headers, 'timeout' => 30 ) );
    if ( is_array($response) ) {
      $file_content = $response['body']; // use the content
    }
    if ( $file_content === FALSE ) {
      return new \WP_Error('failed_to_download', 'Failed to download ' . $file_url . ' file.');
    }
    $ext = pathinfo($file_url, PATHINFO_EXTENSION);
    $file_name = $dir . uniqid() . '.' . $ext;
    $result = file_put_contents($file_name, $file_content);
    if ( $result === FALSE ) {
      return new \WP_Error('failed_to_create_file', 'Failed to create ' . $file_name . ' file.');
    }

    return $file_name;
  }

  /**
   * @param $zip_file
   * @param $dir
   *
   * @return bool|\WP_Error
   */
  private function unzip_file( $zip_file, $dir ) {

    if ( class_exists('ZipArchive') ) {
        $zip = new \ZipArchive();
        $res = $zip->open($zip_file);
    } else {
        if ( !class_exists('\PhpZip\ZipFile') ) {
          include_once BLVB_DIR . '/library/vendor/autoload.php';
        }
        $zip = new \PhpZip\ZipFile();
        $res = $zip->openFile($zip_file);
    }

    if ( $res === FALSE ) {
      return new \WP_Error('failed_to_unzip', 'Failed to unzip.');
    }
    $extract = $zip->extractTo($dir);
    if ( $extract === FALSE ) {
      return new \WP_Error('failed_to_extract', 'Failed to extract.');
    }
    $zip->close();

    return TRUE;
  }

  /**
   * @param $dir
   *
   * @return bool|\WP_Error
   */
  private function create_directory( $dir ) {

    if ( !is_dir($dir) && mkdir($dir, 0777, TRUE) === FALSE ) {
      return new \WP_Error('dir_not_created', $dir . ' not created');
    }
    else {
      return TRUE;
    }
  }

  /**
   * @param $dir
   */
  protected function delete_dir( $dir ) {

    if ( !is_dir($dir) ) {
      return;
    }
    if ( substr($dir, strlen($dir) - 1, 1) != '/' ) {
      $dir .= '/';
    }
    $files = glob($dir . '*', GLOB_MARK);
    foreach ( $files as $file ) {
      if ( is_dir($file) ) {
        $this->delete_dir($file);
      }
      else {
        unlink($file);
      }
    }
    rmdir($dir);

    return;
  }

  /**
   * @param array $args empty/trash/delete
   */
  public static function delete_last_imported_site_data( $args = array() ) {

    $wp_error = array();

    $defaults = array(
      'posts' => 'trash',
      'attachments' => '1',
      'terms' => '1',
      'menus' => '1',
      'options' => '1',
    );

    $args = wp_parse_args($args, $defaults);
    $data = get_option('blvb_imported_site_data');
    $options_for_reset = [
      "blogname",
      "blogdescription",
      "show_on_front",
      "page_on_front",
      "page_for_posts",
    ];

    if ( !$data && 'delete' === $args['posts']) {
      $wp_error["status"] = "info";
      $wp_error["message"][] = __("There is no imported website template", 'justshoppe-features');
      echo json_encode($wp_error);
      die();
    } else if ( !$data ) {
      $wp_error["message"] = __("There is no imported website template", 'justshoppe-features');
      return json_encode($wp_error);
    }


    if ( '' != $args['posts'] ) {
      if ( !empty($data['posts']) ) {
        foreach ( $data['posts'] as $post_id ) {
          if ( 'delete' === $args['posts'] ) {
            $delete_post = wp_delete_post($post_id, TRUE);
            if( $delete_post == false || $delete_post == 'null' ) {
              $wp_error['message'][] = sprintf(__('Could not delete id: %s post.', 'justshoppe-features'), $post_id);
            }
          }
          else {
            $post = array(
              'ID' => $post_id,
              'post_status' => 'trash',
            );
            wp_update_post($post);
          }
        }
      }
    }
    if ( '' != $args['attachments'] ) {
      if ( !empty($data['attachments']) ) {
        foreach ( $data['attachments'] as $post_id ) {
          $attachment = wp_delete_attachment($post_id, TRUE);
          if( $attachment == false || $attachment == 'null' ) {
            $wp_error['message'][] = sprintf(__('Could not delete image id: %s .', 'justshoppe-features'), $post_id);
          }

        }
      }
    }
    if ( '' != $args['terms'] ) {
      if ( !empty($data['terms']) ) {
        foreach ( $data['terms'] as $term_data ) {
          $term = wp_delete_term($term_data['term_id'], $term_data['taxonomy']);
          if ( $term === false ) {
            $wp_error['message'][] = sprintf(__('Term with id: %s does not exist.', 'justshoppe-features'), $term_data['term_id']);
          } else if ( $term === 0 ) {
            $wp_error['message'][] = sprintf(__('Could not delete id: %s term.', 'justshoppe-features'), $term_data['term_id']);
          }else if ( is_wp_error( $term ) ) {
            $wp_error['message'][] = sprintf(__('Term: %s', 'justshoppe-features'), $term->get_error_message());
          }

        }
      }
    }
    if ( '' != $args['menus'] ) {

      if ( !empty($data['menus']) ) {
        foreach ( $data['menus'] as $menu_id ) {
          $nav_menu = wp_delete_nav_menu($menu_id);
          if ( $nav_menu === false ) {
            $wp_error['message'][] = sprintf(__('Could not delete menu by id: %s .', 'justshoppe-features'), $menu_id);
          } else if ( is_wp_error( $nav_menu ) ) {
            $wp_error['message'][] = sprintf(__('Menu: %s', 'justshoppe-features'), $nav_menu->get_error_message());
          }
        }
      }
      if ( !empty($data['options']['nav_menu_locations']) ) {
        set_theme_mod('nav_menu_locations', $data['options']['nav_menu_locations']);
      }
      $options_for_reset[] = 'nav_menu_options';
    }
    if ( '' != $args['options'] ) {
      if ( !empty($data['options']['custom_logo']) ) {
        set_theme_mod('custom_logo', $data['options']['custom_logo']);
        update_option('custom_logo', $data['options']['custom_logo']);
      }
      foreach ( $options_for_reset as $opt_name ) {
        if ( isset($data['options'][$opt_name]) && $data['options'][$opt_name] != get_option($opt_name) ) {
          $option = update_option($opt_name, $data['options'][$opt_name]);
          if( !$option ) {
            $wp_error['message'][] = sprintf(__('Could not delete option "%s" .', 'justshoppe-features'), $opt_name);
          }
        }
      }
    }
    delete_option('blvb_imported_site_data');

    if( !empty($wp_error) ) {
      $wp_error['status'] = 'warning';
    } else {
      $wp_error['status'] = 'success';
      $wp_error['message'] = __('Site template successfully deleted', 'justshoppe-features');
    }

    if ( 'delete' === $args['posts']) {
      echo json_encode($wp_error);
      die();
    } else {
      return json_encode($wp_error);
    }
  }
}
