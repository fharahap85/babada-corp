<?php
namespace Bolvo_Builder;


class AdminCondition extends Condition {

  public function admin_condition_popup($post_id){
    wp_register_script(
      'jquery-elementor-select2',
      ELEMENTOR_ASSETS_URL . 'lib/e-select2/js/e-select2.full.min.js',
      [
        'jquery',
      ],
      '4.0.6-rc.1',
      true
    );

    wp_register_style(
      'elementor-select2',
      ELEMENTOR_ASSETS_URL . 'lib/e-select2/css/e-select2.min.css',
      [],
      '4.0.6-rc.1'
    );

    wp_register_script('blvb-condition-js', BLVB_URL . '/assets/editor/js/condition.js', ['jquery'],BLVB_VERSION);
    wp_register_style('blvb-condition', BLVB_URL . '/assets/editor/css/condition.css', array(), BLVB_VERSION);
    $rest_route = add_query_arg(array('rest_route' => '/'), get_home_url() . "/");

    wp_localize_script('blvb-condition-js', 'blvb_editor', array(
      'admin_condition_class' => 'display-conditions-admin',
      'texts' => array(
        'include' => __('Include', 'justshoppe-features'),
        'exclude' => __('Exclude', 'justshoppe-features'),
        'general' => __('Entire Site', 'justshoppe-features'),
        'archive' => __('Archive', 'justshoppe-features'),
        'singular' => __('Singular', 'justshoppe-features'),
        'are_your_sure' => __('Are you sure?', 'justshoppe-features'),
        'condition_removed' => __('A condition has been removed.', 'justshoppe-features'),
        'content_missing' => __('<b>Warning:</b> There are no content widgets in this Single template. Please make sure to add some.', 'justshoppe-features'),
        'publish' => __('Publish', 'justshoppe-features'),
        'continue' => __('Continue', 'justshoppe-features'),
      ),
      'ajax_url' => admin_url('admin-ajax.php'),
      'rest_route' => $rest_route,
      'rest_nonce' => wp_create_nonce('wp_rest'),
      'post_id' => $post_id,
      'conditions' => parent::get_template_condition($post_id, 'all', true),
      'blvb_template_type' => Templates::get_instance()->is_blvb_template()
    ));

    wp_print_scripts('jquery-elementor-select2');
    wp_print_styles('elementor-select2');
    wp_print_scripts('blvb-condition-js');
    wp_print_styles('blvb-condition');
    parent::condition_popup();
  }

}
