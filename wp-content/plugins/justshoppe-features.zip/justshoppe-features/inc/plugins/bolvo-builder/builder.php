<?php

namespace Bolvo_Builder;
class Builder {
	public static $prefix = '';
	public static $version = '';
	protected static $instance = NULL;
	private $widgets_list = array();
	private $group_widgets_list = array();
	private $custom_options = array();
	private $tags_list = array();

	private function __construct() {
		self::$prefix             = BLVB_PREFIX;
		self::$version            = BLVB_VERSION;
		$this->widgets_list       = blvb_get_widgets();
		$this->group_widgets_list = blvb_get_group_widgets();
		$this->custom_options     = get_custom_options();
		$this->tags_list          = blvb_get_tags();
		if ( get_option( 'blvb_version' ) !== BLVB_VERSION ) {
			self::install();
		}
		load_plugin_textdomain( 'justshoppe-features', FALSE, basename( dirname( __FILE__ ) ) . '/languages' );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
		if ( ! $this->check_elementor_compatibility() ) {
			add_action( 'admin_notices', array( $this, 'elementor_compatibility_notice' ) );
		} else {
			if ( defined( 'ELEMENTOR_PATH' ) ) {
				include_once 'templates/templates.php';
				Templates::get_instance();
				$this->register_hooks();
				if ( ! defined( 'ELEMENTOR_PRO_VERSION' ) ) {
					$this->remove_elementor_upsell();
				}
				include_once BLVB_DIR . '/classes/woocommerce.php';
				\Bolvo_Builder\Classes\Woocommerce\Woocommerce::get_instance();
			}
		}
	}

	public static function install() {
		$version = get_option( 'blvb_version' );
		if ( $version === FALSE ) {
			$version = '0.0.0';
		}
		if ( version_compare( $version, BLVB_VERSION, '<=' ) ) {
			//todo
		}
		update_option( 'blvb_version', BLVB_VERSION );
	}

	private function check_elementor_compatibility() {
		if ( ! defined( 'ELEMENTOR_VERSION' ) || version_compare( ELEMENTOR_VERSION, BLVB_ELEMENTOR_MIN_VERSION, '<' ) || ! did_action( 'elementor/loaded' ) ) {
			return FALSE;
		}

		return TRUE;
	}

	// @TODO Temporary solution.
	private function register_hooks() {
		$this->register_controls();
		add_action( 'wp_ajax_blvb_widgets', array( $this, 'widgets_ajax' ) );
		add_action( 'wp_ajax_nopriv_blvb_widgets', array( $this, 'widgets_ajax' ) );
		add_action( 'elementor/elements/categories_registered', array( $this, 'register_widget_category' ), 9 );
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ), 10 );
		add_action( 'elementor/controls/controls_registered', array( $this, 'register_custom_options' ), 10 );
		/* @TODO SCRIPTS AND STYLES */
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'enqueue_frontend_styles' ] );
		/* wp_footer action's third parameter need to be elementor's 'wp_footer' actions third parameter +1 */
		add_action( 'wp_footer', [ $this, 'enqueue_frontend_scripts' ], 12 );
		/* @TODO FIRES AFTER ELEMENTOR EDITOR STYLES AND SCRIPTS ARE ENQUEUED. */
		//fires after elementor editor styles and scripts are enqueued.
		add_filter( 'tw_get_elementor_assets', array( $this, 'register_elementor_assets' ) );
		add_action( 'elementor/editor/after_enqueue_styles', [ $this, 'enqueue_editor_styles' ] );
		add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'enqueue_editor_scripts' ] );
		add_action( 'admin_bar_menu', [ $this, 'add_toolbar_items' ], 500 );
		add_action( 'wp_ajax_popup_template_ajax', array( $this, 'popup_template_ajax_action' ) );
		add_action( 'wp_ajax_remove_template_ajax', array( $this, 'remove_template_ajax_action' ) );
		add_action( 'wp_ajax_trigger_conditions', array( $this, 'trigger_conditions_admin_ajax' ) );
		add_action( 'elementor/init', array( $this, 'elementor_init' ) );
		add_filter( 'elementor/widget/render_content', [ $this, 'remove_powered_by' ], 10, 3 );
		//$this->add_front_banners();

        include_once 'includes/cli.php';
        CLI::get_instance();
	}

	public function register_controls() {
		include_once 'controls/select-ajax/controller.php';
		SelectAjaxController::get_instance();
		if ( defined( 'ELEMENTOR_PATH' ) && class_exists( 'Elementor\Group_Control_Base' ) ) {
			include_once 'controls/query-control/controller.php';
			include_once 'controls/query-control/controls/group-control-posts.php';
			\Bolvo_Builder\Controls\QueryControl\QueryController::get_instance();
		}
	}

	public function add_front_banners() {
		include 'banners/banners.php';
		$banners = new Banners;
	}

	private function remove_elementor_upsell() {
		include_once 'includes/remove-upsell.php';
		RemoveUpsell::get_instance();
	}

	/* Remove last imported template*/
	public static function get_instance() {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function trigger_conditions_admin_ajax() {
		$post_id = Helper::get( 'post_id' );
		include_once 'templates/condition/admin-condition.php';
		$admincondition = new AdminCondition();
		$admincondition->admin_condition_popup( $post_id );
	}

	public function remove_powered_by( $content ) {
		$re = '/(Powered by Bolvo)|(<a ?.*>Powered by Bolvo<\/a>)/mi';
		preg_match( $re, $content, $matches, PREG_OFFSET_CAPTURE, 0 );
		if ( ! empty( $matches ) ) {
			$content = '';
		}

		return $content;
	}

	public function elementor_init() {
		require_once BLVB_DIR . '/dynamic-tags/module.php';
		new DynamicTags\Module();
		require_once BLVB_DIR . '/pro-features/ElementorPro.php';
		ElementorPro\ElementorPro::get_instance();
		if ( defined( 'ELEMENTOR_PATH' ) && class_exists( 'Elementor\Widget_Base' ) ) {
			if ( ! empty( $this->widgets_list ) ) {
				$widgets = array_merge( $this->widgets_list, $this->custom_options );
				foreach ( $widgets as $widget_name => $widget_data ) {
					if ( isset( $widget_data[ 'oninit' ] ) && $widget_data[ 'oninit' ] ) {
						$file = BLVB_DIR . '/widgets/' . $widget_name . '/' . $widget_name . '.php';
						if ( is_file( $file ) ) {
							require_once $file;
						}
					}
				}
			}
			if ( ! empty( $this->group_widgets_list ) ) {
				foreach ( $this->group_widgets_list as $module_name => $widget_data ) {
					$file = BLVB_DIR . '/widgets/' . $module_name . '/module.php';
					if ( is_file( $file ) ) {
						require_once $file;
					}
				}
			}
		}
	}

	public function remove_template_ajax_action() {
		if ( ! isset( $_GET[ 'blvb_nonce' ] ) || ( isset( $_GET[ 'blvb_nonce' ] ) && ! wp_verify_nonce( $_GET[ 'blvb_nonce' ], 'blvb_remove_template_ajax' ) ) ) {
			$wp_error[ "message" ] = __( "You have no permission for the action", 'justshoppe-features' );
			$wp_error[ "status" ]  = "error";
			echo json_encode( $wp_error );
			die();
		}
		include_once 'templates/import/import.php';
		$args = array(
			'posts'       => 'delete',
			'attachments' => '1',
			'terms'       => '1',
			'menus'       => '1',
			'options'     => '1',
		);
		Import::delete_last_imported_site_data( $args );
	}

	public function popup_template_ajax_action() {
		include_once 'templates/popupTemplates.php';
		$task = Helper::get( 'task' );
		switch ( $task ) {
			case 'save_lacaly':
				PopupTemplates::get_instance()->blvb_dublicate_teplate_post();
				break;
			case 'save_popup':
				if ( Helper::get( 'header_template' ) === '0' || Helper::get( 'footer_template' ) === '0' || Helper::get( 'single_template' ) === '0' || Helper::get( 'archive_template' ) === '0' ) {
					$param = "exclude";
				} else {
					$param = "include";
				}
				PopupTemplates::get_instance()->blvb_save_templates( $param );
		}
	}

	public function add_toolbar_items( \WP_Admin_Bar $admin_bar ) {
		if ( ! is_admin() ) {
			$edit_url       = $this->get_edit_url();
			$editor_section = 'Edit any section with Website Builder based on Elementor.';
			$topbar_button  = 'Edit With Website Builder';
			if ( ! BOLVO_WHITE_LABEL ) {
				$admin_bar->remove_menu( 'elementor_edit_page' );
				if ( is_singular() ) {
					$document = \Elementor\Plugin::instance()->documents->get_doc_for_frontend( get_the_ID() );
					if ( $document && $document->is_editable_by_current_user() ) {
						$admin_bar->add_menu( array(
							                      'id'    => 'blvb_builder',
							                      'class' => 'admin_bar-blvb_builder',
							                      'title' => __( 'Edit with Elementor', 'justshoppe-features' ),
							                      'href'  => $edit_url,
						                      ) );
					}
					if ( is_singular( array( 'product' ) ) ) {
						$loaded_templates = Templates::get_instance()->get_loaded_templates();
						if ( array_key_exists( 'blvb_single', $loaded_templates ) && ! empty( $loaded_templates[ 'blvb_single' ] ) ) {
							$template_id = $loaded_templates[ 'blvb_single' ];
							$document    = \Elementor\Plugin::instance()->documents->get_doc_for_frontend( $template_id );
							if ( $document && $document->is_editable_by_current_user() ) {
								$admin_bar->add_menu( array(
									                      'id'    => 'blvb_builder',
									                      'class' => 'admin_bar-blvb_builder',
									                      'title' => __( 'Edit Product template with Bolvo Builder', 'justshoppe-features' ),
									                      'href'  => $edit_url,
									                      'meta'  => array( 'target' => '_blank' ),
								                      ) );
							}
						}
					}
				} else {
					$loaded_templates = Templates::get_instance()->get_loaded_templates();
					if ( array_key_exists( 'blvb_archive', $loaded_templates ) && ! empty( $loaded_templates[ 'blvb_archive' ] ) ) {
						$archive_id = $loaded_templates[ 'blvb_archive' ];
						$document   = \Elementor\Plugin::instance()->documents->get_doc_for_frontend( $archive_id );
						if ( $document && $document->is_editable_by_current_user() ) {
							$admin_bar->add_menu( array(
								                      'id'    => 'blvb_builder',
								                      'class' => 'admin_bar-blvb_builder',
								                      'title' => __( 'Edit Archive template with Bolvo Builder', 'justshoppe-features' ),
								                      'href'  => $edit_url,
								                      'meta'  => array( 'target' => '_blank' ),
							                      ) );
						}
					}
				}
				$editor_section = 'Edit any section with Bolvo Editor based on Elementor.';
				$topbar_button  = 'Edit With BOLVO Builder';
			}
			if ( $edit_url && 1 == get_post_meta( get_the_ID(), 'blvb_ai_created', TRUE ) ) {
				add_action( 'wp_after_admin_bar_render', function() use ( $topbar_button, $editor_section, $edit_url ) {
					?>
                  <style>
                    html.blvb {
                      margin-top: 0 !important;
                    }

                    #wpadminbar {
                      display: none;
                    }

                    .blvb-ai-biulder-topbar, .blvb-ai-biulder-topbar * {
                      box-sizing: border-box;
                    }

                    .blvb-ai-biulder-topbar {
                      height: 100px;
                      position: fixed;
                      left: calc(50% - 950px / 2);
                      margin: 0 auto;
                      width: 950px;
                      z-index: 999999999;
                      background: #FFFFFF 0 0 no-repeat padding-box;
                      padding: 22px 25px;
                      text-align: left;
                      display: flex;
                      justify-content: space-between;
                      border-radius: 10px;
                      bottom: 10px;
                      opacity: 1;
                      box-shadow: 0 3px 6px #00000029;
                      -webkit-box-shadow: 0 3px 6px #00000029;
                      -moz-box-shadow: 0 3px 6px #00000029;
                      align-items: center;
                      font-family: 'Open Sans', sans-serif;
                    }

                    .blvb-ai-builder-topbar-p {
                      display: flex;
                      flex-direction: column;
                      justify-content: center;
                      align-items: flex-start;
                    }

                    .blvb-ai-biulder-topbar-button {
                      display: flex;
                      align-items: center;
                      justify-content: center;
                      width: 300px;
                      height: 50px;
                      background: #2160B5 0 0 no-repeat padding-box;
                      border-radius: 25px;
                      color: #FFFFFF;
                      font-size: 16px;
                      font-weight: 600;
                      line-height: 22px;
                      text-shadow: 0 5px 20px #E5E6E866;
                      box-sizing: border-box;
                      text-align: center;
                      text-decoration: none;
                      text-transform: uppercase;
                      opacity: 1;
                    }

                    .recreate-with-ai {
                      font-size: 20px;
                      font-weight: 700;
                      letter-spacing: 0.17px;
                      line-height: 27px;
                      margin-bottom: 5px;
                    }


                    .editor-section {
                      font-size: 18px;
                      letter-spacing: 0.15px;
                      line-height: 24px;
                      color: #323A45;
                      font-weight: 400;
                    }

                    .blvb-ai-biulder-topbar-button:hover {
                      text-decoration: none;
                    }

                    @media (max-width: 1023px) {
                      .blvb-ai-biulder-topbar {
                        width: 718px;
                        height: 90px;
                        left: calc(50% - 718px / 2);
                        padding: 19px 15px;
                      }

                      .blvb-ai-biulder-topbar-button {
                        width: 250px;
                        height: 50px;
                        font-size: 14px;
                        line-height: 19px;
                        letter-spacing: 0.12px;
                        text-shadow: 0 3px 6px #00000019;
                      }

                      .recreate-with-ai {
                        font-size: 18px;
                        letter-spacing: 0.15px;
                        line-height: 24px
                      }

                      .editor-section {
                        font-size: 16px;
                        letter-spacing: 0.13px;
                        line-height: 22px
                      }
                    }

                    @media (max-width: 767px) {
                      .blvb-ai-biulder-topbar {
                        width: 300px;
                        height: 56px;
                        left: calc(50% - 300px / 2);
                        padding: 8px 25px;
                      }

                      .blvb-ai-biulder-topbar-button {
                        width: 250px;
                        height: 40px;
                        font-size: 14px;
                        line-height: 19px;
                        letter-spacing: 0.12px;
                        text-shadow: 0 3px 6px #00000019;
                      }

                      .blvb-ai-builder-topbar-p {
                        display: none;
                      }
                    }
                  </style>
                  <div class="blvb-ai-biulder-topbar">
                    <div class="blvb-ai-builder-topbar-p">
                      <div
                        class="recreate-with-ai"><?php _e( 'Your Website Recreated With AI.', 'justshoppe-features' ); ?></div>
                      <div class="editor-section"><?php _e( $editor_section, 'justshoppe-features' ); ?></div>
                    </div>
                    <a href="<?php echo $edit_url; ?>"
                       class="blvb-ai-biulder-topbar-button"><?php _e( $topbar_button, 'justshoppe-features' ); ?></a>
                  </div>
					<?php
				} );
				delete_post_meta( get_the_ID(), 'blvb_ai_created' );
			}
		}
	}

	public function get_edit_url() {
		if ( ! is_admin() ) {
			$edit_url = FALSE;
			if ( is_singular() ) {
				$document = \Elementor\Plugin::instance()->documents->get_doc_for_frontend( get_the_ID() );
				if ( $document && $document->is_editable_by_current_user() ) {
					$edit_url = $document->get_edit_url();
				}
				if ( is_singular( array( 'product' ) ) ) {
					$loaded_templates = Templates::get_instance()->get_loaded_templates();
					if ( array_key_exists( 'blvb_single', $loaded_templates ) && ! empty( $loaded_templates[ 'blvb_single' ] ) ) {
						$template_id = $loaded_templates[ 'blvb_single' ];
						$document    = \Elementor\Plugin::instance()->documents->get_doc_for_frontend( $template_id );
						if ( $document && $document->is_editable_by_current_user() ) {
							$edit_url = admin_url( 'post.php?post=' . $template_id . '&action=elementor' );
						}
					}
				}
			} else {
				$loaded_templates = Templates::get_instance()->get_loaded_templates();
				if ( array_key_exists( 'blvb_archive', $loaded_templates ) && ! empty( $loaded_templates[ 'blvb_archive' ] ) ) {
					$archive_id = $loaded_templates[ 'blvb_archive' ];
					$document   = \Elementor\Plugin::instance()->documents->get_doc_for_frontend( $archive_id );
					if ( $document && $document->is_editable_by_current_user() ) {
						$edit_url = admin_url( 'post.php?post=' . $archive_id . '&action=elementor' );
					}
				}
			}

			return $edit_url;
		}
	}

	public function register_widgets() {
		if ( defined( 'ELEMENTOR_PATH' ) && class_exists( 'Elementor\Widget_Base' ) ) {
			if ( ! empty( $this->widgets_list ) ) {
				$isExternal = FALSE;
				foreach ( $this->widgets_list as $widget_name => $widget_data ) {
					if ( ! isset( $widget_data[ 'oninit' ] ) || ! $widget_data[ 'oninit' ] ) {
						if ( isset( $widget_data[ 'external' ] ) && $widget_data[ 'external' ] ) {
							if ( isset( $widget_data[ 'class_name' ] ) && ! class_exists( $widget_data[ 'class_name' ] ) ) {
								$isExternal = TRUE;
								require_once BLVB_DIR . '/widgets/external/external.php';
								$external_widget = new External();
								$external_widget->set( $widget_data );
								\Elementor\Plugin::instance()->widgets_manager->register( $external_widget );
							}
						} else {
							$file = BLVB_DIR . '/widgets/' . $widget_name . '/' . $widget_name . '.php';
							if ( is_file( $file ) ) {
								require_once $file;
							}
						}
					}
				}
				if ( $isExternal && class_exists( '\Bolvo_Manager\Manager' ) && is_admin() ) {
					wp_enqueue_script( 'blvb-control-external-ajax', BLVB_URL . '/assets/editor/js/external-ajax.js', [ 'jquery' ], BLVB_VERSION );
					$rest_route = add_query_arg( array(
						                             'rest_route' => '/' . BOLVO_REST_NAMESPACE . '/action',
					                             ), get_home_url() . "/" );
					wp_localize_script( 'blvb-control-external-ajax', 'blvb', array(
						'ajaxurl'          => admin_url( 'admin-ajax.php' ),
						'ajaxnonce'        => wp_create_nonce( 'wp_rest' ),
						'plugin_url'       => BOLVO_URL,
						'action_endpoint'  => $rest_route,
						'install_success'  => __( 'The plugin was successfully installed and activated. Please save your changes and reload the page for using the widget', 'justshoppe-features' ),
						'activate_success' => __( 'The plugin was successfully activated. Please save your changes and reload the page for using the widget', 'justshoppe-features' ),
						'update_success'   => __( 'The plugin was successfully updated. Please save your changes and reload the page for using the widget', 'justshoppe-features' ),
						'reload_msg'       => __( 'Please save your changes and reload the page for using the widget', 'justshoppe-features' ),
						'inprogress_msg'   => __( 'Some plugin is in the process of being activated or installed.', 'justshoppe-features' ),
					) );
				}
			}
		}
	}

	public function register_custom_options() {
		if ( defined( 'ELEMENTOR_PATH' ) && class_exists( 'Elementor\Widget_Base' ) ) {
			if ( ! empty( $this->custom_options ) ) {
				foreach ( $this->custom_options as $widget_name => $widget_data ) {
					if ( ! isset( $widget_data[ 'oninit' ] ) || ! $widget_data[ 'oninit' ] ) {
						$file = BLVB_DIR . '/widgets/' . $widget_name . '/' . $widget_name . '.php';
						if ( is_file( $file ) ) {
							require_once $file;
						}
					}
				}
			}
		}
	}

	public function widgets_ajax() {
		if ( ! check_ajax_referer( 'blvb', 'nonce' ) || ! isset( $_REQUEST[ 'widget_name' ] ) ) {
			wp_send_json_error();
		}
		$widget = blvb_get_widgets( $_REQUEST[ 'widget_name' ] );
		if ( ! isset( $widget[ 'ajax' ] ) || $widget[ 'ajax' ] !== TRUE ) {
			wp_send_json_error();
		}
		$file = BLVB_DIR . '/widgets/' . $_REQUEST[ 'widget_name' ] . '/' . $_REQUEST[ 'widget_name' ] . '.php';
		if ( is_file( $file ) ) {
			require_once $file;
			$class_name = "\Bolvo_Builder\\" . ucfirst( $_REQUEST[ 'widget_name' ] );
			$method     = 'blvb_ajax';
			if ( method_exists( $class_name, $method ) ) {
				$class_name::$method();
			}
		}
	}

	/**
	 * @param $elements_manager \Elementor\Elements_Manager
	 * */
	public function register_widget_category( $elements_manager ) {
		$company_name = ' by Bolvo';
		if ( BOLVO_WHITE_LABEL ) {
			$company_name = '';
		}
		$elements_manager->add_category(
			'bolvo-widgets',
			[
				'title' => __( 'Premium Widgets' . $company_name, 'justshoppe-features' ),
				'icon'  => 'fa fa-plug',
			]
		);
		$elements_manager->add_category(
			'bolvo-plugins-widgets',
			[
				'title' => __( 'BOLVO Plugins', 'justshoppe-features' ),
				'icon'  => 'fa fa-plug',
			]
		);
		/* show sections only on template page! */
		if ( \Elementor\Plugin::instance()->editor->is_edit_mode() && Templates::get_instance()->is_elementor_template_type() ) {
			$elements_manager->add_category(
				'bolvo-builder-widgets',
				[
					'title' => __( 'Site Builder Widgets' . $company_name, 'justshoppe-features' ),
					'icon'  => 'fa fa-plug',
				]
			);
			$elements_manager->add_category(
				'bolvo-woocommerce-builder-widgets',
				[
					'title' => __( 'Woocommerce Builder Widgets' . $company_name, 'justshoppe-features' ),
					'icon'  => 'fa fa-plug',
				]
			);
		}
		$elements_manager->add_category(
			'bolvo-woocommerce-widgets',
			[
				'title' => __( 'Woocommerce Widgets' . $company_name, 'justshoppe-features' ),
				'icon'  => 'fa fa-plug',
			]
		);
	}

	public function enqueue_frontend_scripts() {
		// For post archive widget.
		wp_enqueue_script( 'underscore' );
		// Do not include admin scripts to front.
		if ( \Elementor\Plugin::instance()->preview->is_preview_mode() ) {
			$handle_editor = 'blvb-common-js';
			wp_enqueue_script( 'jquery-elementor-select2' );
			wp_enqueue_script( 'blvb-common-js', BLVB_URL . '/assets/common/js/common.js', [ 'jquery' ], BLVB_VERSION, TRUE );
			wp_enqueue_script( 'blvb-condition-js', BLVB_URL . '/assets/editor/js/condition.js', [ 'jquery' ], BLVB_VERSION, TRUE );
			wp_enqueue_style( 'blvb-common', BLVB_URL . '/assets/common/css/common.css', array(), BLVB_VERSION );
			wp_enqueue_style( 'blvb-condition', BLVB_URL . '/assets/editor/css/condition.css', array(), BLVB_VERSION );
			$rest_route         = add_query_arg( array( 'rest_route' => '/' ), get_home_url() . "/" );
			$blvb_template_type = Templates::get_instance()->is_blvb_template()[ 'template_type' ];
			$header_button      = Templates::get_instance()->is_blvb_template()[ 'header_button_show' ];
			wp_localize_script( $handle_editor, 'blvb_options', array(
				'loaded_templates'    => Templates::get_instance()->get_loaded_templates(),
				'post_id'             => get_the_ID(),
				'current_page'        => __( 'Current Page', 'justshoppe-features' ),
				'entire_site'         => __( 'Entire Site', 'justshoppe-features' ),
				'singular'            => __( 'Singular', 'justshoppe-features' ),
				'archive'             => __( 'Archive', 'justshoppe-features' ),
				'choose'              => __( 'Choose', 'justshoppe-features' ),
				'template'            => __( 'template', 'justshoppe-features' ),
				'blvb_page_type'      => Condition::get_instance()->get_page_type(),
				'edit'                => __( 'Edit', 'justshoppe-features' ),
				'edit_localy'         => __( 'Edit Localy', 'justshoppe-features' ),
				'edit_url'            => admin_url( 'post.php?post={post_id}&action=elementor' ),
				'popup_template_ajax' => add_query_arg( array( 'action' => 'popup_template_ajax' ), admin_url( 'admin-ajax.php' ) ),
				'is_post_template'    => ( get_post_type( get_the_ID() ) == 'elementor_library' ? 1 : 0 ),
				'header_button'       => $header_button,
				'blvb_header'         => __( 'Edit Header Template', 'justshoppe-features' ),
				'blvb_footer'         => __( 'Edit Footer Template', 'justshoppe-features' ),
				'blvb_single'         => __( 'Edit Single Template', 'justshoppe-features' ),
				'blvb_archive'        => __( 'Edit Archive Template', 'justshoppe-features' ),
				'blvb_template_type'  => $blvb_template_type,
				'plugin_url'          => plugin_dir_url( __FILE__ ),
			) );
			wp_localize_script( $handle_editor, 'blvb_editor', array(
				'texts'              => array(
					'include'           => __( 'Include', 'justshoppe-features' ),
					'exclude'           => __( 'Exclude', 'justshoppe-features' ),
					'general'           => __( 'Entire Site', 'justshoppe-features' ),
					'archive'           => __( 'Archive', 'justshoppe-features' ),
					'singular'          => __( 'Singular', 'justshoppe-features' ),
					'are_your_sure'     => __( 'Are you sure?', 'justshoppe-features' ),
					'condition_removed' => __( 'A condition has been removed.', 'justshoppe-features' ),
					'content_missing'   => __( 'Warning: There are no content widgets in this Single template. Please make sure to add some.', 'justshoppe-features' ),
					'publish'           => __( 'Publish', 'justshoppe-features' ),
					'continue'          => __( 'Continue', 'justshoppe-features' ),
				),
				'ajax_url'           => admin_url( 'admin-ajax.php' ),
				'rest_route'         => $rest_route,
				'rest_nonce'         => wp_create_nonce( 'wp_rest' ),
				'post_id'            => get_the_ID(),
				'conditions'         => Condition::get_instance()->get_template_condition( get_the_ID(), 'all', TRUE ),
				'blvb_template_type' => $blvb_template_type,
			) );
		}
		$handle_frontend = 'blvb-frontend-scripts';
		if ( BLVB_DEV === FALSE ) {
			if ( BLVB_DEBUG === TRUE ) {
				wp_enqueue_script( 'blvb-frontend-scripts', BLVB_URL . '/assets/frontend/js/frontend.js', array(
					'elementor-frontend-modules',
					'imagesloaded',
					'masonry',
				),                 BLVB_VERSION );
			} else {
				wp_enqueue_script( 'blvb-frontend-scripts', BLVB_URL . '/assets/frontend/js/frontend.min.js', array(
					'elementor-frontend-modules',
					'imagesloaded',
					'masonry',
				),                 BLVB_VERSION );
			}
		} else {
			$handle_frontend = 'blvb-posts-scripts';
			$widgets         = array_merge( $this->widgets_list, $this->custom_options );
			foreach ( $widgets as $widget_data ) {
				if ( empty( $widget_data[ 'scripts' ] ) ) {
					continue;
				}
				foreach ( $widget_data[ 'scripts' ] as $handle => $script_data ) {
					wp_enqueue_script( 'blvb-' . $handle . '-scripts', $script_data[ 'src' ], $script_data[ 'deps' ], BLVB_VERSION, TRUE );
				}
			}
		}
		wp_localize_script( $handle_frontend, 'blvb', array(
			'ajaxurl'  => admin_url( 'admin-ajax.php' ),
			'home_url' => home_url(),
			'nonce'    => wp_create_nonce( 'blvb' ),
		) );
		do_action( 'blvb_after_enqueue_scripts', $handle_frontend );

		if ( ! BOLVO_WHITE_LABEL ) {
			/* remove 'Edit with Elementor' from admin bar */
			wp_dequeue_script( 'elementor-admin-bar' );
		}
	}

	public function enqueue_frontend_styles() {
		if ( BLVB_DEV === FALSE ) {
			wp_enqueue_style( 'blvb-frontend-styles', BLVB_URL . '/assets/frontend/css/frontend.css', array(
				'elementor-icons'
			),                BLVB_VERSION );
			// Ensure the images remain visible while meta information is being generated after import.
			if ( get_option( 'bolvo_import_in_progress' ) ) {
				wp_add_inline_style( 'blvb-frontend-styles', 'img {width: initial !important; height: initial !important;}' );
			}
		} else {
			wp_enqueue_style( 'blvb-fonts', BLVB_URL . '/assets/frontend/css/fonts.css', array(), BLVB_VERSION );
			$widgets = array_merge( $this->widgets_list, $this->custom_options );
			foreach ( $widgets as $widget_data ) {
				if ( empty( $widget_data[ 'styles' ] ) ) {
					continue;
				}
				foreach ( $widget_data[ 'styles' ] as $handle => $style_data ) {
					if ( is_array( $style_data ) ) {
						wp_enqueue_style( 'blvb-' . $handle . '-style', $style_data[ 'src' ], $style_data[ 'deps' ], BLVB_VERSION );
					} else {
						wp_enqueue_style( $handle );
					}
				}
			}
		}
		do_action( 'blvb_after_enqueue_styles' );
	}

	public function register_elementor_assets( $assets ) {
		$version = '2.0.2';
		if ( ! isset( $assets[ 'version' ] ) || version_compare( $assets[ 'version' ], $version ) === - 1 ) {
			$assets[ 'version' ]  = $version;
			$assets[ 'css_path' ] = BLVB_URL . '/assets/frontend/css/fonts.css';
		}

		return $assets;
	}

	public function enqueue_editor_styles() {
		if ( BLVB_DEV === FALSE ) {
			wp_enqueue_style( 'blvb-admin-styles', BLVB_URL . '/assets/editor/css/editor.min.css', array(), BLVB_VERSION );
		} else {
			$key = 'blvb-editor-styles';
			wp_deregister_style( $key );
			$assets = apply_filters( 'tw_get_elementor_assets', array() );
			wp_enqueue_style( $key, $assets[ 'css_path' ], array(), $assets[ 'version' ] );
			wp_enqueue_style( 'blvb-el-editor-styles', BLVB_URL . '/assets/editor/css/editor.css', array(), BLVB_VERSION );
			wp_enqueue_style( 'blvb-condition', BLVB_URL . '/assets/editor/css/condition.css', array(), BLVB_VERSION );
			wp_enqueue_style( 'blvb-common', BLVB_URL . '/assets/common/css/common.css', array(), BLVB_VERSION );
		}
		// Compatibility with Font awesome 5, remove once Elementor deprecates fa4.
		wp_enqueue_style( 'font-awesome-5-all', self::get_fa_asset_url( 'all' ), array(), ELEMENTOR_VERSION );
		if ( BOLVO_WHITE_LABEL ) {
			wp_enqueue_style( 'blvb-white-label', BLVB_URL . '/assets/common/css/white_label.css', array(), BLVB_VERSION );
		}
	}

	public static function get_fa_asset_url( $filename, $ext_type = 'css', $add_suffix = TRUE ) {
		static $is_test_mode = NULL;
		if ( NULL === $is_test_mode ) {
			$is_test_mode = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG || defined( 'ELEMENTOR_TESTS' ) && ELEMENTOR_TESTS;
		}
		$url = ELEMENTOR_ASSETS_URL . 'lib/font-awesome/' . $ext_type . '/' . $filename;
		if ( ! $is_test_mode && $add_suffix ) {
			$url .= '.min';
		}

		return $url . '.' . $ext_type;
	}

	public function enqueue_editor_scripts() {
		if ( BLVB_DEV === FALSE ) {
			$requirements = array(
				'jquery',
				'backbone-marionette',
				'elementor-common-modules',
				'elementor-common',
				'elementor-editor-modules',
				'elementor-editor-document',
			);
			if ( BLVB_DEBUG === TRUE ) {
				wp_enqueue_script( 'blvb-editor-scripts', BLVB_URL . '/assets/editor/js/editor-bolvo.js', $requirements, BLVB_VERSION, TRUE );
			} else {
				wp_enqueue_script( 'blvb-editor-scripts', BLVB_URL . '/assets/editor/js/editor-bolvo.min.js', $requirements, BLVB_VERSION, TRUE );
			}
		} else {
			foreach ( $this->widgets_list as $widget_data ) {
				if ( empty( $widget_data[ 'admin-scripts' ] ) ) {
					continue;
				}
				foreach ( $widget_data[ 'admin-scripts' ] as $handle => $script_data ) {
					wp_enqueue_script( 'blvb-' . $handle . '-admin-scripts', $script_data[ 'src' ], $script_data[ 'deps' ], BLVB_VERSION, TRUE );
				}
			}
			wp_enqueue_script( 'blvb-editor-scripts', BLVB_URL . '/assets/editor/js/editor.js', [ 'jquery' ], BLVB_VERSION, TRUE );
			wp_enqueue_script( 'blvb-condition-js', BLVB_URL . '/assets/editor/js/condition.js', [ 'jquery' ], BLVB_VERSION, TRUE );
			wp_enqueue_script( 'blvb-common-js', BLVB_URL . '/assets/common/js/common.js', [ 'jquery' ], BLVB_VERSION, TRUE );
		}
		$rest_route         = add_query_arg( array( 'rest_route' => '/' ), get_home_url() . "/" );
		$blvb_template_type = Templates::get_instance()->is_blvb_template()[ 'template_type' ];
		wp_localize_script( 'blvb-editor-scripts', 'blvb_editor', array(
			'texts'              => array(
				'include'           => __( 'Include', 'justshoppe-features' ),
				'exclude'           => __( 'Exclude', 'justshoppe-features' ),
				'general'           => __( 'Entire Site', 'justshoppe-features' ),
				'archive'           => __( 'Archive', 'justshoppe-features' ),
				'singular'          => __( 'Singular', 'justshoppe-features' ),
				'are_your_sure'     => __( 'Are you sure?', 'justshoppe-features' ),
				'condition_removed' => __( 'A condition has been removed.', 'justshoppe-features' ),
				'content_missing'   => __( 'Warning: There are no content widgets in this Single template. Please make sure to add some.', 'justshoppe-features' ),
				'publish'           => __( 'Publish', 'justshoppe-features' ),
				'continue'          => __( 'Continue', 'justshoppe-features' ),
			),
			'ajax_url'           => admin_url( 'admin-ajax.php' ),
			'rest_route'         => $rest_route,
			'rest_nonce'         => wp_create_nonce( 'wp_rest' ),
			'post_id'            => get_the_ID(),
			'conditions'         => Condition::get_instance()->get_template_condition( get_the_ID(), 'all', TRUE ),
			'blvb_template_type' => $blvb_template_type,
		) );
		$edit_url         = admin_url( 'post.php?post={post_id}&action=elementor' );
		$is_post_template = ( get_post_type( get_the_ID() ) == 'elementor_library' ? 1 : 0 );
		$header_button    = Templates::get_instance()->is_blvb_template()[ 'header_button_show' ];
		wp_localize_script( 'blvb-editor-scripts', 'blvb_options', array(
			'ajaxurl'              => admin_url( 'admin-ajax.php' ),
			'nonce'                => wp_create_nonce( 'blvb' ),
			'loaded_templates'     => Templates::get_instance()->get_loaded_templates(),
			'rest_route'           => $rest_route,
			'rest_nonce'           => wp_create_nonce( 'wp_rest' ),
			'post_id'              => get_the_ID(),
			'edit_button_title'    => __( 'Edit Template', 'justshoppe-features' ),
			'teplate_popup_title'  => __( 'Choose templates for your web site', 'justshoppe-features' ),
			'current_page'         => __( 'Current Page', 'justshoppe-features' ),
			'entire_site'          => __( 'Entire Site', 'justshoppe-features' ),
			'singular'             => __( 'Singular', 'justshoppe-features' ),
			'archive'              => __( 'Archive', 'justshoppe-features' ),
			'choose'               => __( 'Choose', 'justshoppe-features' ),
			'template'             => __( 'template', 'justshoppe-features' ),
			'blvb_page_type'       => Condition::get_instance()->get_page_type(),
			'edit'                 => __( 'Edit', 'justshoppe-features' ),
			'edit_localy'          => __( 'Edit Locally', 'justshoppe-features' ),
			'edit_url'             => $edit_url,
			'edit_local_url'       => add_query_arg( array( 'action' => 'popup_template_ajax' ), admin_url( 'admin-ajax.php' ) ),
			'popup_template_draw'  => add_query_arg( array( 'action' => 'draw_popup' ), admin_url( 'admin-ajax.php' ) ),
			'page_title'           => get_the_title(),
			'is_post_template'     => $is_post_template,
			'header_button'        => $header_button,
			'plugin_url'           => plugin_dir_url( __FILE__ ),
			'remove_template_ajax' => add_query_arg( array( 'action' => 'remove_template_ajax' ), admin_url( 'admin-ajax.php' ) ),
			'blvb_header'          => __( 'Edit Header Template', 'justshoppe-features' ),
			'blvb_footer'          => __( 'Edit Footer Template', 'justshoppe-features' ),
			'blvb_single'          => __( 'Edit Single Template', 'justshoppe-features' ),
			'blvb_archive'         => __( 'Edit Archive Template', 'justshoppe-features' ),
			'blvb_template_type'   => $blvb_template_type,
		) );
		do_action( 'blvb_after_enqueue_scripts' );
		do_action( 'blvb_before_enqueue_editor_scripts' );
	}

	public function admin_enqueue_scripts() {
		wp_enqueue_script( BLVB_PREFIX . '-admin-script', BLVB_URL . '/assets/admin/js/admin.js', [ 'jquery' ], BLVB_VERSION, TRUE );
		wp_localize_script( BLVB_PREFIX . '-admin-script', 'blvb_admin',
		                    array(
			                    'ajax_url' => wp_nonce_url( admin_url( 'admin-ajax.php' ), 'blvb_remove_template_ajax', 'blvb_nonce' ),
		                    ) );
		wp_enqueue_style( BLVB_PREFIX . '-admin-style', BLVB_URL . '/assets/admin/css/admin.css', [], BLVB_VERSION );
	}

	public function elementor_compatibility_notice() {
		$elementor_notice = NULL;
		add_thickbox();
		$thickbox          = add_query_arg(
			array( 'tab' => 'plugin-information', 'plugin' => 'elementor', 'TB_iframe' => 'true' ),
			admin_url( 'plugin-install.php' )
		);
		$link              = "";
		$installed_plugins = get_plugins();
		if ( ! isset( $installed_plugins[ 'elementor/elementor.php' ] ) ) {
			$elementor_notice = __( 'Bolvo Builder requires Elementor plugin. Please install and activate the latest version of %s plugin.', 'justshoppe-features' );
			if ( isset( $_GET[ 'from' ] ) && 'bolvo' == $_GET[ 'from' ] ) {
				$link   = 'thickbox';
				$script = '<script>jQuery(window).load(function() {jQuery("#blvb_install_elementor").trigger("click")});</script>';
			} else {
				$link = add_query_arg(
					array( 's' => 'elementor', 'tab' => 'search', 'type' => 'term', 'from' => 'bolvo' ),
					admin_url( 'plugin-install.php' )
				);
			}
		} else if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
			$elementor_notice = __( 'Bolvo Builder requires Elementor plugin. Please activate %s plugin.', 'justshoppe-features' );
			$link             = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=elementor/elementor.php&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_elementor/elementor.php' );
		} else if ( version_compare( ELEMENTOR_VERSION, BLVB_ELEMENTOR_MIN_VERSION, '<' ) ) {
			$elementor_notice = __( 'Bolvo Builder requires latest version of Elementor plugin. Please update %s plugin.', 'justshoppe-features' );
			$link             = 'thickbox';
		}
		if ( $elementor_notice !== NULL ) {

			if ( current_user_can( 'activate_plugins' ) ) {

				if ( $link == 'thickbox' ) {
					$link = '<a id="blvb_install_elementor" class="thickbox" href="' . $thickbox . '">Elementor</a>';
				} else {
					$link = '<a href="' . $link . '">Elementor</a>';
				}
			} else {
				$link = 'Elementor';
			}
			echo '<div class="error blvb_notice">' . sprintf( $elementor_notice, $link ) . "</div>";
			if ( isset( $script ) ) {
				echo $script;
			}
		}
	}
}
