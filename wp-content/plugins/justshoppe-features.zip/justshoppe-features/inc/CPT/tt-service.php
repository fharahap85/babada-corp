<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.


/**
 * Register Post Type and Taxonomies
 *
 * @since 1.0
 */
function tt_service_module_cpt() {

	$with_front = $service_cpt_slug = $service_cpt_cat_slug = $service_cpt_single = $single_args = '';

	if( function_exists( 'tt_temptt_get_option' ) ) {
		$with_front = tt_temptt_get_option( 'cpt_with_front', '0' );
		$service_cpt_slug = tt_temptt_get_option( 'service_cpt_slug', 'service-item' );
		$service_cpt_cat_slug = tt_temptt_get_option( 'service_cpt_cat_slug', 'service-cats' );
		$service_cpt_single = tt_temptt_get_option( 'service_cpt_single', true );
	}
	// With Front
	if ( ! empty ( $with_front )  ) $with_front = true; else $with_front = false;

	// Single page
	if ( ! empty ( $service_cpt_single )  ) { // single item true
		$single_args =  array('show_ui' => true) ;
	} else {
		$single_args =  array(
						'exclude_from_search' => true,
						'show_in_admin_bar'   => false,
						'show_in_nav_menus'   => false,
						'publicly_queryable'  => false,
						'query_var'           => false,
		) ;
	}


	/**
	 * Register Post Type
	 */

	// Arguments
	$cpt_args = array(
		'labels' => array(
			'name' => esc_attr__( 'Service', 'justshoppe' ),
			'singular_name' => esc_attr__( 'Service', 'justshoppe' ),
			'add_new' => esc_attr__( 'Add Service', 'justshoppe' ),
			'add_new_item' => esc_attr__( 'Add Service', 'justshoppe' ),
			'edit' => esc_attr__( 'Edit', 'justshoppe' ),
			'edit_item' => esc_attr__( 'Edit Service', 'justshoppe' ),
			'new_item' => esc_attr__( 'New Service', 'justshoppe' ),
			'view' => esc_attr__( 'View Service', 'justshoppe' ),
			'view_item' => esc_attr__( 'View Service', 'justshoppe' ),
			'search_items' => esc_attr__( 'Search Service', 'justshoppe' ),
			'not_found' => esc_attr__( 'No Service found', 'justshoppe' ),
			'not_found_in_trash' => esc_attr__( 'No Service found in Trash', 'justshoppe' ),
			'parent' => esc_attr__( 'Parent Service', 'justshoppe' ),
		),
		'public' => true,
		'rewrite' => array( 'slug' => $service_cpt_slug, 'with_front' => $with_front ),
		'supports' => array( 'title', 'custom-fields', 'excerpt', 'editor', 'author', 'thumbnail', 'comments'  ),
	);

	// Single pages to be shown or not.
	$cpt_args = array_merge( $cpt_args, $single_args );

	// Apply filters
	$cpt_args = apply_filters( 'tt_service_cpt_args', $cpt_args );

	// Register Post Type
	register_post_type( 'tt_service', $cpt_args );

	/**
	 * Register Taxonomy ( Category )
	 */

	// Arguments
	$tax_args = array(
		'labels' => array(
			'name' => esc_attr__( 'Service Categories', 'justshoppe' ),
			'singular_name' => esc_attr__( 'Category', 'justshoppe' ),
			'search_items'  => esc_attr__( 'Search Categories', 'justshoppe' ),
			'all_items' => esc_attr__( 'All Categories', 'justshoppe' ),
			'parent_item' => esc_attr__( 'Parent Category', 'justshoppe' ),
			'parent_item_colon' => esc_attr__( 'Parent Category:', 'justshoppe' ),
			'edit_item' => esc_attr__( 'Edit Category', 'justshoppe' ),
			'update_item' => esc_attr__( 'Update Category', 'justshoppe' ),
			'add_new_item' => esc_attr__( 'Add New Category', 'justshoppe' ),
			'new_item_name' => esc_attr__( 'New Category Name', 'justshoppe' ),
			'menu_name' => esc_attr__( 'Categories', 'justshoppe' ),
		),
		'hierarchical' => true,
		'public' => true,
		'rewrite' => array(
			'slug' => $service_cpt_cat_slug,
			'with_front' => $with_front
		),
	);

	// Apply filters
	$tax_args = apply_filters( 'tt_service_cats_args', $tax_args );

	// Register Taxonomy
	register_taxonomy( 'tt_service_cats', 'tt_service', $tax_args );

} add_action( 'init', 'tt_service_module_cpt' );