<?php
/**
 *
 * The demo folders name should be the slug of their demo.
 * Screenshot should be named as screenshot.png ( if jpg, edit below var )
 * Edit variables as needed on top of the function.
 * Set homepage for each demo below.
 * Default Homepage page title should be Home, and menu name should be Primary Menu.
 * Enter folder name and the Title for that demo in below array(for now).
 *
 */
function justshoppe_import_files() {

	$justshoppe_url        = 'https://justshoppe.bolvo.com/';  /* root of multisite install*/
	$justshoppe_img_extn   = '.jpg'; /* Only need to edit if jpg is used for screenshot. */

	// Note: query import file path is set inside function.
	$justshoppe_local_import_path = trailingslashit( JUSTSHOPPE_FW_ROOT ) . 'inc/demo-import/';
	$justshoppe_local_import_url = trailingslashit( plugins_url( '/', __FILE__ ) );
	$justshoppe_xml_file         = 'data.xml';
	$justshoppe_widget_file      = 'widgets.wie';
	$justshoppe_customizer_file  = 'settings.dat';

	$demo_folders = array();
	$demo_folders['main-demo'] = 'Demo 1';
	$demo_folders['thebakerynew'] = 'Demo 2';
	$demo_folders['site3jsbakery'] = 'Demo 3';
	$demo_folders['site4jscompact'] = 'Demo 4';
	$demo_folders['site5-cake'] = 'Demo 5';
	$demo_folders['site6-coffee'] = 'Demo 6';
	$demo_folders['site7-chocolates'] = 'Demo 7';
	$demo_folders['site8-seafood'] = 'Demo 8';
	$demo_folders['site9-cakeshop'] = 'Demo 9';
	$demo_folders['site10-blog'] = 'Demo 10';
	$demo_folders['newsite11'] = 'Demo 11';
	$demo_folders['newsite-12'] = 'Demo 12';


// prepare the array with all folders inside.
// CREATES ISSUES WHEN NUMBER GOES ABOVE 10, DEBUG LATER.
	/*$demo_folders = array();
	$sub_directories = array_map('basename', glob($justshoppe_local_import_path . '*', GLOB_ONLYDIR));
	foreach ( $sub_directories as $dirname ) { // get all folders
		$demotitle    = preg_replace('/(\d+)/', ' ${1} ', $dirname); // separating the number
		$demotitle    = preg_replace('/(?<!\ )[A-Z]/', ' $0', $demotitle); // adding space before capital letters.
		$demotitle    = str_replace('-', ' ', $demotitle); // add space instead of -.
		$demotitle    = str_replace('  ', ' ', $demotitle); // add space instead of -.
		$demotitle    = trim($demotitle);
		$demotitle    = ucwords($demotitle);
		$demo_folders[$dirname] = $demotitle;
	}
	*/
// prepare array to initiate import.
// CREATES ISSUES WHEN NUMBER GOES ABOVE 10, DEBUG LATER.
	/*
	$demos = array();
	foreach( $demo_folders as $demo_folder => $demoname ) {
		$demos[] = array(
			'import_file_name'             => $demoname,
			'import_slug'                  => $demo_folder,
			'categories'                   => array( esc_html__('Main','justshoppe') ),
			'local_import_file'            => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . $justshoppe_xml_file,
			'local_import_widget_file'     => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . $justshoppe_widget_file,
			'local_import_customizer_file' => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . $justshoppe_customizer_file,
			'import_preview_image_url'     => $justshoppe_local_import_url . trailingslashit( $demo_folder ) . 'screenshot' . $justshoppe_img_extn,
			'import_notice'                => esc_html__( 'Please wait for a few minutes, do not close the window or refresh the page until the data is imported.', 'justshoppe' ),
			'preview_url'                  => $justshoppe_url . $demo_folder,
		);
	}*/

// prepare array to initiate import.
	$demos = array();
	foreach( $demo_folders as $demo_folder => $demoname ) {
		$demos[] = array(
			'import_file_name'             => $demoname,
			'import_slug'                  => $demo_folder,
			'categories'                   => array( esc_html__('Main','justshoppe') ),
			'local_import_file'            => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . $justshoppe_xml_file,
			'local_import_widget_file'     => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . $justshoppe_widget_file,
			'local_import_customizer_file' => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . $justshoppe_customizer_file,
			'import_preview_image_url'     => $justshoppe_local_import_url . trailingslashit( $demo_folder ) . 'screenshot' . $justshoppe_img_extn,
			'import_notice'                => esc_html__( 'Please wait for a few minutes, do not close the window or refresh the page until the data is imported.', 'justshoppe' ),
			'preview_url'                  => $justshoppe_url . $demo_folder,
		);
	}

	return $demos;

}
add_filter( 'pt-ocdi/import_files', 'justshoppe_import_files' );

function justshoppe_after_import_setup( $selected_import ) {
	function set_elementor_config() {
		add_option( 'elementor_disable_color_schemes', 'yes' ,'yes' );
		add_option( 'elementor_disable_typography_schemes', 'yes' ,'yes' );
	}
	function set_reading_options( $settings ) {
		$reading_settings = $settings['reading_settings'];
		if ( ! empty( $reading_settings ) ) {
			$homepage   = get_page_by_title( html_entity_decode( $reading_settings['homepage'] ) );
			$blog     = get_page_by_title( html_entity_decode( $reading_settings['blog'] ) );
			if ( ( isset( $homepage ) && $homepage->ID ) && ( isset( $blog ) && $blog->ID) ) {
				update_option( 'show_on_front',   'page' );
				update_option( 'page_on_front',   $homepage->ID );
				update_option( 'page_for_posts',  $blog->ID );
				return true;
			}
		}
		return false;
	}
	function set_woocommerce_pages( $settings ) {
		if ( class_exists( 'Woocommerce' ) && ! empty( $settings['woocommerce_pages'] ) ) {
			foreach ( $settings['woocommerce_pages'] as $woo_name => $woo_title ) {
				$woopage = get_page_by_title( $woo_title );
				if ( isset( $woopage ) && property_exists( $woopage, 'ID' ) ) {
					update_option( $woo_name, $woopage->ID );
				}
			}
			return true;
		}
		return false;
	}
	function set_nav_menus( $settings ) {

		if ( is_array( $settings['navigation'] ) ) {
			$locations = get_theme_mod( 'nav_menu_locations' );
			$menus = wp_get_nav_menus();

			foreach ( (array) $menus as $theme_menu ) {
				foreach ( (array) $settings['navigation'] as $import_menu ) {
					if ( $theme_menu->name == $import_menu['name'] ) {
						$locations[ $import_menu['location'] ] = $theme_menu->term_id;
					}
				}
			}

			set_theme_mod( 'nav_menu_locations', $locations );
			return true;
		}
		return false;
	}
	function justshoppe_get_demo_path() {
		$upload_dir = wp_upload_dir();
		$dir = path_join( $upload_dir['basedir'], 'demo_files' );

		return $dir;
	}
	function set_rev_sliders( $revsliders ) {

		if ( class_exists( 'RevSlider' ) && ! empty( $revsliders ) ) {
			$slider = new RevSlider();

			foreach( $revsliders as $filepath ) {
				$slider->importSliderFromPost(true,true,$filepath);
				@unlink( $filepath );
			}

			return true;
		}
		return false;
	}

	$json = null;
	$revsliders = array();
	$homepage = 'Home';

	/*    if( 'demo1' === $selected_import['import_slug'] ) {
		}*/

	function justshoppe_import_data( $file='', $addon_cat=false ) {

		require_once(ABSPATH . 'wp-admin/includes/file.php');

		WP_Filesystem();
		global $wp_filesystem;
		global $wpdb;

		if(!is_readable($file)) {
			echo 'File not found or not readable '.$file;
		}

		$query_ins = $wp_filesystem->get_contents( $file );

		// we need to add table name dynamically, so make sure its removed from sql file.
		global $wpdb;
		if( $addon_cat ) {

			$query_ins = "INSERT INTO ".$wpdb->prefix."addonlibrary_categories " . $query_ins;
			$rows_affected = $wpdb->query( $query_ins );
			if( $rows_affected ) {
				update_option('blv_addons_cat_import', 'done');
			}

		} else {

			$query_ins = "INSERT INTO ".$wpdb->prefix."addonlibrary_addons " . $query_ins;
			$rows_affected = $wpdb->query( $query_ins );
			if( $rows_affected ) {
				update_option('blv_addons_import', 'done');
			}

		}
	}

	function justshoppe_import_addons(){

		$justshoppe_local_import_addon = trailingslashit( get_template_directory_uri() ) . 'inc/demo-import/justshoppe-addons.txt';
		$justshoppe_local_import_cat = trailingslashit( get_template_directory_uri() ) . 'inc/demo-import/justshoppe-addons-cat.txt';
		if( class_exists( 'OCDI_Plugin' ) ) {
			$justshoppe_downloader         = new \OCDI\Downloader;
			$justshoppe_local_import_addon = $justshoppe_downloader->download_file( $justshoppe_local_import_addon, 'justshoppe-addons.txt' );
			$justshoppe_local_import_cat   = $justshoppe_downloader->download_file( $justshoppe_local_import_cat, 'justshoppe-addons-cat.txt' );
			if ( ! get_option( 'blv_addons_import' ) && ! is_object( $justshoppe_local_import_addon ) ) {
				justshoppe_import_data( $justshoppe_local_import_addon );
			}

			if ( ! get_option( 'blv_addons_cat_import' ) && ! is_object( $justshoppe_local_import_cat ) ) {
				justshoppe_import_data( $justshoppe_local_import_cat, true );
			}
		}
	}

	$settings = array (
		'reading_settings' =>
			array (
				'homepage' => $homepage,
				'blog' => 'Blog',
			),
		'woocommerce_pages' =>
			array (
				'woocommerce_shop_page_id' => 'Shop',
				'woocommerce_cart_page_id' => 'Cart',
				'woocommerce_checkout_page_id' => 'Checkout',
				'woocommerce_myaccount_page_id' => 'My Account',
			),
		'navigation' =>
			array (
				0 =>
					array (
						'name' => 'Primary Menu',
						'location' => 'header-menu-1',
					),
				1 =>
					array (
						'name' => 'Primary Menu',
						'location' => 'header-mobile-menu',
					),
			),
	);
	set_elementor_config();
	set_reading_options( $settings );
	set_woocommerce_pages( $settings );
	set_nav_menus( $settings );
	//justshoppe_import_addons( $settings );
	//set_rev_sliders( $revsliders );

	flush_rewrite_rules();
}
add_action( 'pt-ocdi/after_import', 'justshoppe_after_import_setup' );

add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );

function ocdi_before_content_import( $selected_import ) {
	if ( 'Demo 1' === $selected_import['import_file_name'] ) {
		// Here you can do stuff for the "Demo Import 1" before the content import starts.
		echo "before import 1";
	}
	else {
		// Here you can do stuff for all other imports before the content import starts.
		echo "before import 2";
	}
}
add_action( 'pt-ocdi/before_content_import', 'ocdi_before_content_import' );