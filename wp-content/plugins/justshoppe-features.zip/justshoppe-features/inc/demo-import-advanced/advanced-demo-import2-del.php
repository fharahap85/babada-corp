<?php
/**
 *
 * The demo folders name should be the slug of their demo.
 * Screenshot should be named as screenshot.png ( if jpg, edit below var )
 * Edit variables as needed on top of the function.
 * Set homepage for each demo below.
 * Default Homepage page title should be Home, and menu name should be Primary Menu.
 *
 */
/**
 * This file represents an example of the code that themes would use to register
 * the required plugins.
 *
 * It is expected that theme authors would copy and paste this code into their
 * functions.php file, and amend to suit.
 *
 * @see http://tgmpluginactivation.com/configuration/ for detailed documentation.
 *
 * @package    TGM-Plugin-Activation
 * @subpackage Example
 * @version    2.6.1 for parent theme justshoppe for publication on ThemeForest
 * @author     Thomas Griffin, Gary Jones, Juliette Reinders Folmer
 * @copyright  Copyright (c) 2011, Thomas Griffin
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       https://github.com/TGMPA/TGM-Plugin-Activation
 */

/**
 * Include the TGM_Plugin_Activation class.
 *
 * Depending on your implementation, you may want to change the include call:
 *
 * Parent Theme:
 * require_once get_template_directory() . '/path/to/class-tgm-plugin-activation.php';
 *
 * Child Theme:
 * require_once get_stylesheet_directory() . '/path/to/class-tgm-plugin-activation.php';
 *
 * Plugin:
 * require_once dirname( __FILE__ ) . '/path/to/class-tgm-plugin-activation.php';
 */
include_once JUSTSHOPPE_INCLUDES_DIR . '/theme-helpers/tgm-activation/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'justshoppe_fw_register_required_plugins2' );

/**
 * Register the required plugins for this theme.
 *
 * In this example, we register five plugins:
 * - one included with the TGMPA library
 * - two from an external source, one from an arbitrary source, one from a GitHub repository
 * - two from the .org repo, where one demonstrates the use of the `is_callable` argument
 *
 * The variables passed to the `tgmpa()` function should be:
 * - an array of plugin arrays;
 * - optionally a configuration array.
 * If you are not changing anything in the configuration array, you can remove the array and remove the
 * variable from the function call: `tgmpa( $plugins );`.
 * In that case, the TGMPA default settings will be used.
 *
 * This function is hooked into `tgmpa_register`, which is fired on the WP `init` action on priority 10.
 */
function justshoppe_fw_register_required_plugins2() {
	/*
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */

	$plugins = array(

		array(
			'name'			        => esc_html__( 'One Click Demo Import', 'justshoppe' ),
			'slug'     				=> 'one-click-demo-import', // The plugin slug (typically the folder name)
			'required' 				=> false, // If false, the plugin is only 'recommended' instead of required
		),

	);

	/*
	 * Array of configuration settings. Amend each line as needed.
	 *
	 * TGMPA will start providing localized text strings soon. If you already have translations of our standard
	 * strings available, please help us make TGMPA even better by giving us access to these translations or by
	 * sending in a pull-request with .po file(s) with the translations.
	 *
	 * Only uncomment the strings in the config array if you want to customize the strings.
	 */
	$config = array(
		'id'           => 'justshoppe2',                 // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => true,                   // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.


	);

	tgmpa( $plugins, $config );
}




function justshoppe_import_files() {

	$justshoppe_url        = 'https://justshoppe.bolvo.com/';  /* root of multisite install*/
	$justshoppe_img_extn   = '.png'; /* Only need to edit if jpg is used for screenshot. */

	// Note: query import file path is set inside function.
	$justshoppe_local_import_path = trailingslashit( JUSTSHOPPE_FW_ROOT ) . 'inc/demo-import/';
	$justshoppe_local_import_url = trailingslashit( plugins_url( '/', __FILE__ ) );
	$justshoppe_xml_file         = 'data.xml';
	$justshoppe_widget_file      = 'widgets.wie';
	$justshoppe_customizer_file  = 'settings.dat';

	// prepare the array with all folders inside.
	$demo_folders = array();
	$sub_directories = array_map('basename', glob($justshoppe_local_import_path . '*', GLOB_ONLYDIR));
	foreach ( $sub_directories as $dirname ) { // get all folders
		$demotitle    = preg_replace('/(\d+)/', ' ${1} ', $dirname); // separating the number
		$demotitle    = preg_replace('/(?<!\ )[A-Z]/', ' $0', $demotitle); // adding space before capital letters.
		$demotitle    = str_replace('-', ' ', $demotitle); // add space instead of -.
		$demotitle    = str_replace('  ', ' ', $demotitle); // add space instead of -.
		$demotitle    = trim($demotitle);
		$demotitle    = ucwords($demotitle);
		$demo_folders[$dirname] = $demotitle;
	}

	// prepare array to initiate import.
	$demos = array();
	foreach( $demo_folders as $demo_folder => $demoname ) {
		$demos[] = array(
			'import_file_name'             => $demoname,
			'import_slug'                  => $demo_folder,
			'categories'                   => array( esc_html__('Main','justshoppe') ),
			'local_import_file'            => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . $justshoppe_xml_file,
			'local_import_widget_file'     => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . $justshoppe_widget_file,
			'local_import_customizer_file' => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . $justshoppe_customizer_file,
			'import_preview_image_url'     => $justshoppe_local_import_url . trailingslashit( $demo_folder ) . 'screenshot' . $justshoppe_img_extn,
			'import_notice'                => esc_html__( 'Please wait for a few minutes, do not close the window or refresh the page until the data is imported.', 'justshoppe' ),
			'preview_url'                  => $justshoppe_url . $demo_folder,
		);
		$demos1[$demo_folder] = array(
			'title'          => $demoname, /*Title*/
			'is_pro'         => false, /*Is Premium*/
			'type'           => 'General', /*Optional eg gutentor, elementor or other page builders or type*/
			'author'         => __( 'Gutentor', 'text-domain' ), /*Author Name*/
			'keywords'       => array( 'General', 'multipurpose' ), /*Search keyword*/
			'categories'     => array( 'General', 'multipurpose' ), /*Categories*/
			'template_url'   => array(
				'content' => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . 'content.json', /*Full URL Path to content.json*/
				'options' => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . 'options.json', /*Full URL Path to options.json*/
				'widgets' => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . 'widgets.json', /*Full URL Path to widgets.json*/
			),
			'screenshot_url' => $justshoppe_local_import_url . trailingslashit( $demo_folder ) . 'screenshot' . $justshoppe_img_extn, /*Full URL Path to demo screenshot image*/
			'demo_url'       => $justshoppe_url . $demo_folder, /*Full URL Path to Live Demo*/
			/* Recommended plugin for this demo */
			'plugins'        => array(
				array(
					'name' => __( 'Gutentor', 'text-domain' ),
					'slug' => 'gutentor',
				),
			),
		);
	}

	return $demos1;

}
add_filter( 'advanced_import_demo_lists', 'justshoppe_import_files' );
add_filter( 'pt-ocdi/import_files', 'justshoppe_import_files' );

function justshoppe_after_import_setup( $selected_import ) {
	function set_elementor_config() {
		add_option( 'elementor_disable_color_schemes', 'yes' ,'yes' );
		add_option( 'elementor_disable_typography_schemes', 'yes' ,'yes' );
	}
	function set_reading_options( $settings ) {
		$reading_settings = $settings['reading_settings'];
		if ( ! empty( $reading_settings ) ) {
			$homepage   = get_page_by_title( html_entity_decode( $reading_settings['homepage'] ) );
			$blog     = get_page_by_title( html_entity_decode( $reading_settings['blog'] ) );
			if ( ( isset( $homepage ) && $homepage->ID ) && ( isset( $blog ) && $blog->ID) ) {
				update_option( 'show_on_front',   'page' );
				update_option( 'page_on_front',   $homepage->ID );
				update_option( 'page_for_posts',  $blog->ID );
				return true;
			}
		}
		return false;
	}
	function set_woocommerce_pages( $settings ) {
		if ( class_exists( 'Woocommerce' ) && ! empty( $settings['woocommerce_pages'] ) ) {
			foreach ( $settings['woocommerce_pages'] as $woo_name => $woo_title ) {
				$woopage = get_page_by_title( $woo_title );
				if ( isset( $woopage ) && property_exists( $woopage, 'ID' ) ) {
					update_option( $woo_name, $woopage->ID );
				}
			}
			return true;
		}
		return false;
	}
	function set_nav_menus( $settings ) {

		if ( is_array( $settings['navigation'] ) ) {
			$locations = get_theme_mod( 'nav_menu_locations' );
			$menus = wp_get_nav_menus();

			foreach ( (array) $menus as $theme_menu ) {
				foreach ( (array) $settings['navigation'] as $import_menu ) {
					if ( $theme_menu->name == $import_menu['name'] ) {
						$locations[ $import_menu['location'] ] = $theme_menu->term_id;
					}
				}
			}

			set_theme_mod( 'nav_menu_locations', $locations );
			return true;
		}
		return false;
	}
	function justshoppe_get_demo_path() {
		$upload_dir = wp_upload_dir();
		$dir = path_join( $upload_dir['basedir'], 'demo_files' );

		return $dir;
	}
	function set_rev_sliders( $revsliders ) {

		if ( class_exists( 'RevSlider' ) && ! empty( $revsliders ) ) {
			$slider = new RevSlider();

			foreach( $revsliders as $filepath ) {
				$slider->importSliderFromPost(true,true,$filepath);
				@unlink( $filepath );
			}

			return true;
		}
		return false;
	}

	$json = null;
	$revsliders = array();
	$homepage = 'Home';

	/*    if( 'demo1' === $selected_import['import_slug'] ) {
		}*/

	function justshoppe_import_data( $file='', $addon_cat=false ) {

		require_once(ABSPATH . 'wp-admin/includes/file.php');

		WP_Filesystem();
		global $wp_filesystem;
		global $wpdb;

		if(!is_readable($file)) {
			echo 'File not found or not readable '.$file;
		}

		$query_ins = $wp_filesystem->get_contents( $file );

		// we need to add table name dynamically, so make sure its removed from sql file.
		global $wpdb;
		if( $addon_cat ) {

			$query_ins = "INSERT INTO ".$wpdb->prefix."addonlibrary_categories " . $query_ins;
			$rows_affected = $wpdb->query( $query_ins );
			if( $rows_affected ) {
				update_option('blv_addons_cat_import', 'done');
			}

		} else {

			$query_ins = "INSERT INTO ".$wpdb->prefix."addonlibrary_addons " . $query_ins;
			$rows_affected = $wpdb->query( $query_ins );
			if( $rows_affected ) {
				update_option('blv_addons_import', 'done');
			}

		}
	}

	function justshoppe_import_addons(){

		$justshoppe_local_import_addon = trailingslashit( get_template_directory_uri() ) . 'inc/demo-import/justshoppe-addons.txt';
		$justshoppe_local_import_cat = trailingslashit( get_template_directory_uri() ) . 'inc/demo-import/justshoppe-addons-cat.txt';
		if( class_exists( 'OCDI_Plugin' ) ) {
			$justshoppe_downloader         = new \OCDI\Downloader;
			$justshoppe_local_import_addon = $justshoppe_downloader->download_file( $justshoppe_local_import_addon, 'justshoppe-addons.txt' );
			$justshoppe_local_import_cat   = $justshoppe_downloader->download_file( $justshoppe_local_import_cat, 'justshoppe-addons-cat.txt' );
			if ( ! get_option( 'blv_addons_import' ) && ! is_object( $justshoppe_local_import_addon ) ) {
				justshoppe_import_data( $justshoppe_local_import_addon );
			}

			if ( ! get_option( 'blv_addons_cat_import' ) && ! is_object( $justshoppe_local_import_cat ) ) {
				justshoppe_import_data( $justshoppe_local_import_cat, true );
			}
		}
	}

	$settings = array (
		'reading_settings' =>
			array (
				'homepage' => $homepage,
				'blog' => 'Blog',
			),
		'woocommerce_pages' =>
			array (
				'woocommerce_shop_page_id' => 'Shop',
				'woocommerce_cart_page_id' => 'Cart',
				'woocommerce_checkout_page_id' => 'Checkout',
				'woocommerce_myaccount_page_id' => 'My Account',
			),
		'navigation' =>
			array (
				0 =>
					array (
						'name' => 'Primary Menu',
						'location' => 'header-menu-1',
					),
				1 =>
					array (
						'name' => 'Primary Menu',
						'location' => 'header-mobile-menu',
					),
			),
	);
	set_elementor_config();
	set_reading_options( $settings );
	set_woocommerce_pages( $settings );
	set_nav_menus( $settings );
	//justshoppe_import_addons( $settings );
	//set_rev_sliders( $revsliders );

	flush_rewrite_rules();
}
//add_action( 'pt-ocdi/after_import', 'justshoppe_after_import_setup' );

//add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );
