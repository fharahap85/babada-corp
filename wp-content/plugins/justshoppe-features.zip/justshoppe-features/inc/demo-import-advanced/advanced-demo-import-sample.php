<?php
/**
 *
 * The demo folders name should be the slug of their demo.
 * Screenshot should be named as screenshot.png ( if jpg, edit below var )
 * Edit variables as needed on top of the function.
 * Set homepage for each demo below.
 * Default Homepage page title should be Home, and menu name should be Primary Menu.
 *
 */

function justshoppe_import_files() {

	$justshoppe_url        = 'https://justshoppe.bolvo.com/';  /* root of multisite install*/
	$justshoppe_img_extn   = '.png'; /* Only need to edit if jpg is used for screenshot. */

	// Note: query import file path is set inside function.
	$justshoppe_local_import_path = trailingslashit( JUSTSHOPPE_FW_ROOT ) . 'inc/demo-import-advanced/';
	$justshoppe_local_import_url = trailingslashit( plugins_url( '/', __FILE__ ) );

	// prepare the array with all folders inside.
	$demo_folders = array();
	$sub_directories = array_map('basename', glob($justshoppe_local_import_path . '*', GLOB_ONLYDIR));
	foreach ( $sub_directories as $dirname ) { // get all folders
		$demotitle    = preg_replace('/(\d+)/', ' ${1} ', $dirname); // separating the number
		$demotitle    = preg_replace('/(?<!\ )[A-Z]/', ' $0', $demotitle); // adding space before capital letters.
		$demotitle    = str_replace('-', ' ', $demotitle); // add space instead of -.
		$demotitle    = str_replace('  ', ' ', $demotitle); // add space instead of -.
		$demotitle    = trim($demotitle);
		$demotitle    = ucwords($demotitle);
		$demo_folders[$dirname] = $demotitle;
	}

	// prepare array to initiate import.
	$demos = array();
	foreach( $demo_folders as $demo_folder => $demoname ) {
		$config_file = $justshoppe_local_import_path . trailingslashit( $demo_folder ) . 'config.json';
		global $wp_filesystem;
		WP_Filesystem();
		if (file_exists($config_file)) {
			$file_contents = $wp_filesystem->get_contents($config_file);
			$other_vital = json_decode($file_contents, true);
			$main_vital = array(
				'title'          => $demoname, /*Title*/
				'template_url'   => array(
					'content' => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . 'content.json', /*Full URL Path to content.json*/
					'options' => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . 'options.json', /*Full URL Path to options.json*/
					'widgets' => $justshoppe_local_import_path . trailingslashit( $demo_folder ) . 'widgets.json', /*Full URL Path to widgets.json*/
				),
				'screenshot_url' => $justshoppe_local_import_url . trailingslashit( $demo_folder ) . 'screenshot' . $justshoppe_img_extn, /*Full URL Path to demo screenshot image*/
				'demo_url'       => $justshoppe_url . $demo_folder, /*Full URL Path to Live Demo*/
				/* Recommended plugin for this demo */
			);
			$demos1[$demo_folder] = array_merge($main_vital, $other_vital);
		}
	}

	return $demos1;

}
add_filter( 'advanced_import_demo_lists', 'justshoppe_import_files' );

function justshoppe_after_import_setup( $selected_import ) {

	function set_elementor_config() {
		add_option( 'elementor_disable_color_schemes', 'yes' ,'yes' );
		add_option( 'elementor_disable_typography_schemes', 'yes' ,'yes' );
	}

	function justshoppe_get_demo_path() {
		$upload_dir = wp_upload_dir();
		$dir = path_join( $upload_dir['basedir'], 'demo_files' );

		return $dir;
	}

	function set_rev_sliders( $revsliders ) {

		if ( class_exists( 'RevSlider' ) && ! empty( $revsliders ) ) {
			$slider = new RevSlider();

			foreach( $revsliders as $filepath ) {
				$slider->importSliderFromPost(true,true,$filepath);
				@unlink( $filepath );
			}

			return true;
		}
		return false;
	}

	$json = null;
	$revsliders = array();

	function justshoppe_import_data( $file='', $addon_cat=false ) {

		require_once(ABSPATH . 'wp-admin/includes/file.php');

		WP_Filesystem();
		global $wp_filesystem;
		global $wpdb;

		if(!is_readable($file)) {
			echo 'File not found or not readable '.$file;
		}

		$query_ins = $wp_filesystem->get_contents( $file );

		// we need to add table name dynamically, so make sure its removed from sql file.
		global $wpdb;
		if( $addon_cat ) {

			$query_ins = "INSERT INTO ".$wpdb->prefix."addonlibrary_categories " . $query_ins;
			$rows_affected = $wpdb->query( $query_ins );
			if( $rows_affected ) {
				update_option('blv_addons_cat_import', 'done');
			}

		} else {

			$query_ins = "INSERT INTO ".$wpdb->prefix."addonlibrary_addons " . $query_ins;
			$rows_affected = $wpdb->query( $query_ins );
			if( $rows_affected ) {
				update_option('blv_addons_import', 'done');
			}

		}
	}

	function justshoppe_import_addons(){

		$justshoppe_local_import_addon = trailingslashit( get_template_directory_uri() ) . 'inc/demo-import/justshoppe-addons.txt';
		$justshoppe_local_import_cat = trailingslashit( get_template_directory_uri() ) . 'inc/demo-import/justshoppe-addons-cat.txt';
		if( class_exists( 'OCDI_Plugin' ) ) {
			$justshoppe_downloader         = new \OCDI\Downloader;
			$justshoppe_local_import_addon = $justshoppe_downloader->download_file( $justshoppe_local_import_addon, 'justshoppe-addons.txt' );
			$justshoppe_local_import_cat   = $justshoppe_downloader->download_file( $justshoppe_local_import_cat, 'justshoppe-addons-cat.txt' );
			if ( ! get_option( 'blv_addons_import' ) && ! is_object( $justshoppe_local_import_addon ) ) {
				justshoppe_import_data( $justshoppe_local_import_addon );
			}

			if ( ! get_option( 'blv_addons_cat_import' ) && ! is_object( $justshoppe_local_import_cat ) ) {
				justshoppe_import_data( $justshoppe_local_import_cat, true );
			}
		}
	}

	set_elementor_config();
	//justshoppe_import_addons();
	//set_rev_sliders();

	flush_rewrite_rules();
}
add_action( 'advanced_import_after_content_screen', 'justshoppe_after_import_setup' );
