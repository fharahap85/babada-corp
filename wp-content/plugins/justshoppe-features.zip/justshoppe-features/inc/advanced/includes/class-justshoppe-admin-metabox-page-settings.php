<?php
/**
 * Justshoppe Individual Page Settings metabox
 *
 * @package Justshoppe
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

class Justshoppe_Admin_Metabox_Page_Settings {
	/**
	 * Singleton instance
	 *
	 * @var Justshoppe_Admin_Metabox_Page_Settings
	 */
	private static $instance;

	/**
	 * ====================================================
	 * Singleton & constructor functions
	 * ====================================================
	 */

	/**
	 * Get singleton instance.
	 *
	 * @return Justshoppe_Admin_Metabox_Page_Settings
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Class constructor
	 */
	protected function __construct() {
		// Post meta box
		add_action( 'add_meta_boxes', array( $this, 'add_post_meta_box' ), 10, 2 );
		add_action( 'save_post', array( $this, 'save_post_meta_box' ) );

		// Term meta box
		add_action( 'admin_init', array( $this, 'init_term_meta_boxes' ) );

		// Render actions
		add_action( 'justshoppe/admin/metabox/page_settings/fields/content', array( $this, 'render_options__content_layout' ), 10 );
		add_action( 'justshoppe/admin/metabox/page_settings/fields/hero', array( $this, 'render_options__content_header' ), 10 );
		add_action( 'justshoppe/admin/metabox/page_settings/fields/header', array( $this, 'render_options__header' ), 10 );
		add_action( 'justshoppe/admin/metabox/page_settings/fields/footer', array( $this, 'render_options__footer' ), 10 );
		add_action( 'justshoppe/admin/metabox/page_settings/fields/custom_blocks', array( $this, 'render_options__custom_blocks' ), 10 );
		add_action( 'justshoppe/admin/metabox/page_settings/fields/preloader_screen', array( $this, 'render_options__preloader_screen' ), 10 );
	}

	/**
	 * ====================================================
	 * Private functions
	 * ====================================================
	 */

	/**
	 * Return the key and label of available tabs.
	 *
	 * @return array
	 */
	private function get_tabs() {
		return apply_filters( 'justshoppe/admin/metabox/page_settings/tabs', array(
			'content'          => esc_html__( 'Content & Sidebar', 'justshoppe' ),
			'hero'             => esc_html__( 'Content Header', 'justshoppe' ),
			'header'           => esc_html__( 'Header', 'justshoppe' ),
			'footer'           => esc_html__( 'Footer', 'justshoppe' ),
			'custom-blocks'    => esc_html__( 'Custom Blocks (Hooks)', 'justshoppe' ),
			'preloader-screen' => esc_html__( 'Preloader Screen', 'justshoppe' ),
		) );
	}

	/**
	 * ====================================================
	 * Public functions
	 * ====================================================
	 */

	/**
	 * Return page settings values of the specified object (post or term object).
	 *
	 * @param WP_Post|WP_Term $obj
	 * @return array
	 */
	public function get_values( $obj ) {
		$option_key = 'justshoppe_page_settings';

		if ( is_a( $obj, 'WP_Post' ) ) {
			$values = get_post_meta( $obj->ID, '_' . $option_key, true );
		} elseif ( is_a( $obj, 'WP_Term' ) ) {
			$values = get_term_meta( $obj->term_id, $option_key, true );
		} else {
			$values = array();
		}

		return $values;
	}

	/**
	 * ====================================================
	 * Hook functions
	 * ====================================================
	 */

	/**
	 * Add page settings meta box to post edit page.
	 *
	 * @param string $post_type
	 * @param WP_Post $post
	 */
	public function add_post_meta_box( $post_type, $post ) {
		$post_types = justshoppe_get_post_types_for_page_settings();

		add_meta_box(
			'justshoppe_page_settings',
			/* translators: %s: theme name. */
			sprintf( esc_html__( 'Individual Page Settings (%s)', 'justshoppe' ), esc_html( justshoppe_get_theme_info( 'name' ) ) ),
			array( $this, 'render_meta_box__post' ),
			$post_types,
			'normal',
			apply_filters( 'justshoppe/admin/metabox/page_settings/priority', 'high' )
		);
	}

	/**
	 * Handle save action for page settings meta box on post edit page.
	 *
	 * @param integer $post_id
	 */
	public function save_post_meta_box( $post_id ) {
		// Check if our nonce is set.
		if ( ! isset( $_POST['justshoppe_post_page_settings_nonce'] ) ) return;

		// Verify that the nonce is valid.
		if ( ! wp_verify_nonce( sanitize_key( $_POST['justshoppe_post_page_settings_nonce'] ), 'justshoppe_post_page_settings' ) ) return;

		// If this is an autosave, our form has not been submitted, so we don't want to do anything.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

		// Check the user's permissions.
		if ( ! current_user_can( 'edit_post', $post_id ) ) return;

		// Sanitize values.
		$sanitized = array();

		if ( isset( $_POST['justshoppe_page_settings'] ) && is_array( $_POST['justshoppe_page_settings'] ) ) {
			$page_settings = array_map( 'sanitize_key', wp_unslash( $_POST['justshoppe_page_settings'] ) );

			foreach ( $page_settings as $key => $value ) {
				if ( '' === $value ) continue;

				// If value is 0 or 1, cast to integer.
				if ( '0' === $value || '1' === $value ) {
					$value = intval( $value );
				}

				$sanitized[ $key ] = $value;
			}
		}

		// Update the meta field in the database.
		update_post_meta( $post_id, '_justshoppe_page_settings', $sanitized );
	}

	/**
	 * Initialize meta box on all public taxonomies.
	 */
	public function init_term_meta_boxes() {
		$taxonomies = array_merge(
			array( 'category', 'post_tag' ),
			get_taxonomies( array(
				'public'             => true,
				'publicly_queryable' => true,
				'rewrite'            => true,
				'_builtin'           => false,
			), 'names' )
		);
		foreach ( $taxonomies as $taxonomy ) {
			// add_action( $taxonomy . '_add_form_fields', array( $this, 'render_meta_box__term_add' ) );
			add_action( $taxonomy . '_edit_form_fields', array( $this, 'render_meta_box__term_edit' ) );

			// add_action( 'create_' . $taxonomy, array( $this, 'save_term_meta_box' ), 10, 2 );
			add_action( 'edit_' . $taxonomy, array( $this, 'save_term_meta_box' ), 10, 2 );
		}
	}

	/**
	 * Handle save action for page settings meta box on edit term page.
	 *
	 * @param integer $term_id
	 * @param integer $tt_id
	 */
	public function save_term_meta_box( $term_id, $tt_id ) {
		// Check if our nonce is set.
		if ( ! isset( $_POST['justshoppe_term_page_settings_nonce'] ) ) return;

		// Verify that the nonce is valid.
		if ( ! wp_verify_nonce( sanitize_key( $_POST['justshoppe_term_page_settings_nonce'] ), 'justshoppe_term_page_settings' ) ) return;

		// Sanitize values.
		$sanitized = array();
		if ( isset( $_POST['justshoppe_page_settings'] ) && is_array( $_POST['justshoppe_page_settings'] ) ) {
			$page_settings = array_map( 'sanitize_key', wp_unslash( $_POST['justshoppe_page_settings'] ) );

			foreach ( $page_settings as $key => $value ) {
				if ( '' === $value ) continue;

				// If value is 0 or 1, cast to integer.
				if ( '0' === $value || '1' === $value ) {
					$value = intval( $value );
				}

				$sanitized[ $key ] = $value;
			}
		}

		// Update the meta field in the database.
		update_term_meta( $term_id, 'justshoppe_page_settings', $sanitized );
	}

	/**
	 * ====================================================
	 * Render functions
	 * ====================================================
	 */

	/**
	 * Render page settings meta box on post / page edit page.
	 *
	 * @param WP_Post $post
	 */
	public function render_meta_box__post( $post ) {
		// Define an array of post IDs that will disable Individual Page Settings meta box.
		// The Individual Page Settings fields would not be displayed on those disabled IDs meta box.
		// Instead, The meta box would show the defined string specified on the disabled array.
		$disabled_ids = array();

		// Add posts page to disabled IDs.
		if ( 'page' === get_option( 'show_on_front' ) && $posts_page_id = get_option( 'page_for_posts' ) ) {
			$disabled_ids[ $posts_page_id ] = '<p><a href="' . esc_url( add_query_arg( array( 'autofocus[section]' => 'justshoppe_section_page_settings_post_archive', 'url' => esc_url( get_permalink( get_option( 'page_for_posts' ) ) ) ), admin_url( 'customize.php' ) ) ) . '">' .  esc_html__( 'Edit Page settings here', 'justshoppe' ) . '</a></p>';
		}

		// Filter to modify disabled IDs.
		$disabled_ids = apply_filters( 'justshoppe/admin/metabox/page_settings/disabled_posts', $disabled_ids, $post );

		// Check if current post ID is one of the disabled IDs
		if ( array_key_exists( $post->ID, $disabled_ids ) ) {
			// Print the notice here.
			echo $disabled_ids[ $post->ID ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			// There is no other content should be rendered.
			return;
		}

		// Add a nonce field so we can check for it later.
		wp_nonce_field( 'justshoppe_post_page_settings', 'justshoppe_post_page_settings_nonce' );

		// Render meta box.
		$this->render_meta_box_content( $post );
	}

	/**
	 * Render page settings meta box on add term page.
	 */
	public function render_meta_box__term_add() {
		?>
		<div class="form-field justshoppe-add-term-page-settings" style="margin: 2em 0;">
			<h2>
				<?php
				/* translators: %s: theme name. */
				printf( esc_html__( 'Individual Page Settings (%s)', 'justshoppe' ), esc_html( justshoppe_get_theme_info( 'name' ) ) );
				?>
			</h2>
			<?php
			// Add a nonce field so we can check for it later.
			wp_nonce_field( 'justshoppe_term_page_settings', 'justshoppe_term_page_settings_nonce' );

			// Render meta box
			echo '<div class="justshoppe-term-metabox-container">';
			$this->render_meta_box_content();
			echo '</div>';
			?>
		</div>
	<?php
	}

	/**
	 * Render page settings meta box on edit term page.
	 *
	 * @param string $taxonomy
	 */
	public function render_meta_box__term_edit( $term ) {
		?>
		<tr class="form-field justshoppe-edit-term-page-settings">
			<td colspan="2" style="padding: 0;">
				<h3>
					<?php
					/* translators: %s: tdeme name. */
					printf( esc_html__( 'Individual Page Settings (%s)', 'justshoppe' ), esc_html( justshoppe_get_theme_info( 'name' ) ) );
					?>
				</h3>
				<?php
				// Add a nonce field so we can check for it later.
				wp_nonce_field( 'justshoppe_term_page_settings', 'justshoppe_term_page_settings_nonce' );

				// Render meta box
				echo '<div class="justshoppe-term-metabox-container">';
				$this->render_meta_box_content( $term );
				echo '</div>';
				?>
			</th>
		</tr>
	<?php
	}

	/**
	 * Render meta box wrapper.
	 *
	 * @param WP_Post|WP_Term $obj
	 */
	public function render_meta_box_content( $obj = null ) {
		$tabs = $this->get_tabs();
		$first_tab = key( $tabs );
		?>
		<div id="justshoppe-metabox-page-settings" class="justshoppe-admin-metabox-page-settings justshoppe-admin-metabox justshoppe-admin-form">
			<ul class="justshoppe-admin-metabox-nav">
				<?php foreach ( $tabs as $key => $label ) : ?>
					<li class="justshoppe-admin-metabox-nav-item <?php echo esc_attr( $key == $first_tab ? 'active' : '' ); ?>">
						<a href="<?php echo esc_attr( '#justshoppe-metabox-page-settings--' . $key ); ?>"><?php echo $label; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
					</li>
				<?php endforeach; ?>
			</ul>

			<div class="justshoppe-admin-metabox-panels">
				<?php foreach ( $tabs as $key => $label ) : ?>
					<div id="<?php echo esc_attr( 'justshoppe-metabox-page-settings--' . $key ); ?>" class="justshoppe-admin-metabox-panel <?php echo esc_attr( $key == $first_tab ? 'active' : '' ); ?>">
						<?php
						/**
						 * Hook: justshoppe/admin/metabox/page_settings/fields/{tab}
						 */
						do_action( 'justshoppe/admin/metabox/page_settings/fields/' . str_replace( '-', '_', $key ), $obj );

						/**
						 * Hook: justshoppe/admin/metabox/page_settings/fields/
						 */
						do_action( 'justshoppe/admin/metabox/page_settings/fields', $obj, $key );
						?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	<?php
	}

	/**
	 * Render page settings meta box fields for Header.
	 *
	 * @param WP_Post|WP_Term $obj
	 */
	public function render_options__header( $obj ) {
		$option_key = 'justshoppe_page_settings';
		$values = $this->get_values( $obj );
		?>
		<div class="justshoppe-admin-form-row">
			<div class="justshoppe-admin-form-label"><label><?php esc_html_e( 'Header', 'justshoppe' ); ?></label></div>
			<div class="justshoppe-admin-form-field">
				<label class="justshoppe-admin-form-field-device-group">
					<span class="dashicons dashicons-desktop"></span>
					<?php
					$key = 'disable_header';
					Justshoppe_Admin_Fields::render_field( array(
						'name'        => $option_key . '[' . $key . ']',
						'type'        => 'select',
						'choices'     => array(
							''  => esc_html__( '&#x2714; Visible', 'justshoppe' ),
							'1' => esc_html__( '&#x2718; Hidden', 'justshoppe' ),
						),
						'value'       => justshoppe_array_value( $values, $key ),
					) );
					?>
				</label>
				<label class="justshoppe-admin-form-field-device-group">
					<span class="dashicons dashicons-tablet"></span>
					<?php
					$key = 'disable_mobile_header';
					Justshoppe_Admin_Fields::render_field( array(
						'name'        => $option_key . '[' . $key . ']',
						'type'        => 'select',
						'choices'     => array(
							''  => esc_html__( '&#x2714; Visible', 'justshoppe' ),
							'1' => esc_html__( '&#x2718; Hidden', 'justshoppe' ),
						),
						'value'       => justshoppe_array_value( $values, $key ),
					) );
					?>
				</label>
			</div>
		</div>

		<?php if ( justshoppe_show_pro_teaser() ) : ?>
			<div class="notice notice-info notice-alt inline justshoppe-metabox-field-pro-teaser">
				<h3><?php echo esc_html_x( 'More Options Available', 'Justshoppe Pro upsell', 'justshoppe' ); ?></h3>
				<p><?php echo esc_html_x( 'Enable / disable Transparent Header on this page.', 'Justshoppe Pro upsell', 'justshoppe' ); ?><br><?php echo esc_html_x( 'Enable / disable Sticky Header on this page.', 'Justshoppe Pro upsell', 'justshoppe' ); ?><br>
					<?php echo esc_html_x( 'Enable / disable Alternate Header Colors on this page.', 'Justshoppe Pro upsell', 'justshoppe' ); ?><br>
				</p>
				<p><a href="<?php echo esc_url( add_query_arg( array( 'utm_source' => 'justshoppe-page-settings-metabox', 'utm_medium' => 'learn-more', 'utm_campaign' => 'theme-upsell' ), JUSTSHOPPE_PRO_WEBSITE_URL ) ); ?>" class="button button-secondary" target="_blank" rel="noopener"><?php echo esc_html_x( 'Learn More', 'Justshoppe Pro upsell', 'justshoppe' ); ?></a></p>
			</div>
		<?php endif;
	}

	/**
	 * Render page settings meta box fields for Footer.
	 *
	 * @param WP_Post|WP_Term $obj
	 */
	public function render_options__footer( $obj ) {
		$option_key = 'justshoppe_page_settings';
		$values = $this->get_values( $obj );
		?>
		<div class="justshoppe-admin-form-row">
			<div class="justshoppe-admin-form-label"><label><?php esc_html_e( 'Footer widgets', 'justshoppe' ); ?></label></div>
			<div class="justshoppe-admin-form-field">
				<?php
				$key = 'disable_footer_widgets';
				Justshoppe_Admin_Fields::render_field( array(
					'name'        => $option_key . '[' . $key . ']',
					'type'        => 'select',
					'choices'     => array(
						''  => esc_html__( '&#x2714; Visible', 'justshoppe' ),
						'1' => esc_html__( '&#x2718; Hidden', 'justshoppe' ),
					),
					'value'       => justshoppe_array_value( $values, $key ),
				) );
				?>
			</div>
		</div>

		<div class="justshoppe-admin-form-row">
			<div class="justshoppe-admin-form-label"><label><?php esc_html_e( 'Footer bottom', 'justshoppe' ); ?></label></div>
			<div class="justshoppe-admin-form-field">
				<?php
				$key = 'disable_footer_bottom';
				Justshoppe_Admin_Fields::render_field( array(
					'name'        => $option_key . '[' . $key . ']',
					'type'        => 'select',
					'choices'     => array(
						''  => esc_html__( '&#x2714; Visible', 'justshoppe' ),
						'1' => esc_html__( '&#x2718; Hidden', 'justshoppe' ),
					),
					'value'       => justshoppe_array_value( $values, $key ),
				) );
				?>
			</div>
		</div>
	<?php
	}

	/**
	 * Render page settings meta box fields for Content & Sidebar layout.
	 *
	 * @param WP_Post|WP_Term $obj
	 */
	public function render_options__content_layout( $obj ) {
		$option_key = 'justshoppe_page_settings';
		$values = $this->get_values( $obj );
		?>
		<div class="justshoppe-admin-form-row">
			<div class="justshoppe-admin-form-label"><label><?php esc_html_e( 'Container', 'justshoppe' ); ?></label></div>
			<div class="justshoppe-admin-form-field">
				<?php
				$key = 'content_container';
				Justshoppe_Admin_Fields::render_field( array(
					'name'        => $option_key . '[' . $key . ']',
					'type'        => 'radioimage',
					'choices'     => array(
						''           => array(
							'label' => esc_html__( '(Customizer)', 'justshoppe' ),
							'image' => JUSTSHOPPE_IMAGES_URL . '/customizer/customizer.svg',
						),
						'default'    => array(
							'label' => esc_html__( 'Normal', 'justshoppe' ),
							'image' => JUSTSHOPPE_IMAGES_URL . '/customizer/content-container--default.svg',
						),
						'full-width' => array(
							'label' => esc_html__( 'Full width', 'justshoppe' ),
							'image' => JUSTSHOPPE_IMAGES_URL . '/customizer/content-container--full-width.svg',
						),
						'narrow'     => array(
							'label' => esc_html__( 'Narrow', 'justshoppe' ),
							'image' => JUSTSHOPPE_IMAGES_URL . '/customizer/content-container--narrow.svg',
						),
					),
					'value'       => justshoppe_array_value( $values, $key ),
				) );
				?>
				<div class="notice notice-info notice-alt inline">
					<p><?php esc_html_e( 'If you are using Page Builder and want a full width layout, please set the "Page Attributes > Template" to "Page Builder" or the one provided by your page builder.', 'justshoppe' ); ?></p>
				</div>
			</div>
		</div>

		<div class="justshoppe-admin-form-row">
			<div class="justshoppe-admin-form-label"><label><?php esc_html_e( 'Sidebar', 'justshoppe' ); ?></label></div>
			<div class="justshoppe-admin-form-field">
				<?php
				$key = 'content_layout';
				Justshoppe_Admin_Fields::render_field( array(
					'name'        => $option_key . '[' . $key . ']',
					'type'        => 'radioimage',
					'choices'     => array(
						''              => array(
							'label' => esc_html__( '(Customizer)', 'justshoppe' ),
							'image' => JUSTSHOPPE_IMAGES_URL . '/customizer/customizer.svg',
						),
						'right-sidebar' => array(
							'label' => is_rtl() ? esc_html__( 'Left', 'justshoppe' ) : esc_html__( 'Right', 'justshoppe' ),
							'image' => JUSTSHOPPE_IMAGES_URL . '/customizer/content-sidebar-layout--right-sidebar.svg',
						),
						'left-sidebar'  => array(
							'label' => is_rtl() ? esc_html__( 'Right', 'justshoppe' ) : esc_html__( 'Left', 'justshoppe' ),
							'image' => JUSTSHOPPE_IMAGES_URL . '/customizer/content-sidebar-layout--left-sidebar.svg',
						),
						'wide'          => array(
							'label' => esc_html__( 'Disabled', 'justshoppe' ),
							'image' => JUSTSHOPPE_IMAGES_URL . '/customizer/content-sidebar-layout--wide.svg',
						),
					),
					'value'       => justshoppe_array_value( $values, $key ),
				) );
				?>
			</div>
		</div>
	<?php
	}

	/**
	 * Render page settings meta box fields for Content Header.
	 *
	 * @param WP_Post|WP_Term $obj
	 */
	public function render_options__content_header( $obj ) {
		$option_key = 'justshoppe_page_settings';
		$values = $this->get_values( $obj );
		?>
		<div class="justshoppe-admin-form-row">
			<div class="justshoppe-admin-form-label"><label><?php esc_html_e( 'Content header', 'justshoppe' ); ?></label></div>
			<div class="justshoppe-admin-form-field">
				<?php
				$key = 'disable_content_header';
				Justshoppe_Admin_Fields::render_field( array(
					'name'        => $option_key . '[' . $key . ']',
					'type'        => 'select',
					'choices'     => array(
						''  => esc_html__( '&#x2714; Visible', 'justshoppe' ),
						'1' => esc_html__( '&#x2718; Hidden', 'justshoppe' ),
					),
					'value'       => justshoppe_array_value( $values, $key ),
				) );
				?>
			</div>
		</div>

		<div class="justshoppe-admin-form-row">
			<div class="justshoppe-admin-form-label"><label><?php esc_html_e( 'Hero section', 'justshoppe' ); ?></label></div>
			<div class="justshoppe-admin-form-field">
				<?php
				$key = 'hero';
				Justshoppe_Admin_Fields::render_field( array(
					'name'        => $option_key . '[' . $key . ']',
					'type'        => 'select',
					'choices'     => array(
						''  => esc_html__( '(Customizer)', 'justshoppe' ),
						'0' => esc_html__( '&#x2718; Disabled', 'justshoppe' ),
						'1' => esc_html__( '&#x2714; Enabled', 'justshoppe' ),
					),
					'value'       => justshoppe_array_value( $values, $key ),
				) );
				?>
			</div>
		</div>

		<?php if ( is_a( $obj, 'WP_Post' ) ) {
			$post_type = get_post_type( $obj );

			/**
			 * Disable thumbnail.
			 */

			if ( post_type_supports( $post_type, 'thumbnail' ) ) {
				?>
				<div class="justshoppe-admin-form-row">
					<div class="justshoppe-admin-form-label"><label><?php esc_html_e( 'Featured image', 'justshoppe' ); ?></label></div>
					<div class="justshoppe-admin-form-field">
						<?php
						$key = 'disable_thumbnail';
						Justshoppe_Admin_Fields::render_field( array(
							'name'        => $option_key . '[' . $key . ']',
							'type'        => 'select',
							'choices'     => array(
								''  => esc_html__( '&#x2714; Visible', 'justshoppe' ),
								'1' => esc_html__( '&#x2718; Hidden', 'justshoppe' ),
							),
							'value'       => justshoppe_array_value( $values, $key ),
						) );
						?>
					</div>
				</div>
			<?php
			}
		}
	}

	/**
	 * Render page settings meta box fields for Preloader Screen.
	 *
	 * @param WP_Post|WP_Term $obj
	 */
	public function render_options__preloader_screen( $obj ) {
		if ( justshoppe_show_pro_teaser() ) :
			?>
			<div class="notice notice-info notice-alt inline justshoppe-metabox-field-pro-teaser">
				<h3><?php echo esc_html_x( 'More Options Available', 'Justshoppe Pro upsell', 'justshoppe' ); ?></h3>
				<p><?php echo esc_html_x( 'Enable / disable Preloader Screen on this page.', 'Justshoppe Pro upsell', 'justshoppe' ); ?></p>
				<p><a href="<?php echo esc_url( add_query_arg( array( 'utm_source' => 'justshoppe-page-settings-metabox', 'utm_medium' => 'learn-more', 'utm_campaign' => 'theme-upsell' ), JUSTSHOPPE_PRO_WEBSITE_URL ) ); ?>" class="button button-secondary" target="_blank" rel="noopener"><?php echo esc_html_x( 'Learn More', 'Justshoppe Pro upsell', 'justshoppe' ); ?></a></p>
			</div>
		<?php
		endif;
	}

	/**
	 * Render page settings meta box fields for Custom Blocks.
	 *
	 * @param WP_Post|WP_Term $obj
	 */
	public function render_options__custom_blocks( $obj ) {
		if ( justshoppe_show_pro_teaser() ) :
			?>
			<div class="notice notice-info notice-alt inline justshoppe-metabox-field-pro-teaser">
				<h3><?php echo esc_html_x( 'More Options Available', 'Justshoppe Pro upsell', 'justshoppe' ); ?></h3>
				<p><?php echo esc_html_x( 'Insert Custom Blocks (section / element) on any part of this page (header, footer, etc.).', 'Justshoppe Pro upsell', 'justshoppe' ); ?></p>
				<p><a href="<?php echo esc_url( add_query_arg( array( 'utm_source' => 'justshoppe-page-settings-metabox', 'utm_medium' => 'learn-more', 'utm_campaign' => 'theme-upsell' ), JUSTSHOPPE_PRO_WEBSITE_URL ) ); ?>" class="button button-secondary" target="_blank" rel="noopener"><?php echo esc_html_x( 'Learn More', 'Justshoppe Pro upsell', 'justshoppe' ); ?></a></p>
			</div>
		<?php
		endif;
	}
}

Justshoppe_Admin_Metabox_Page_Settings::instance();