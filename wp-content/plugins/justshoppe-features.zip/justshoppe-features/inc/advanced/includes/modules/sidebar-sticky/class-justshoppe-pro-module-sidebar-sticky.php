<?php
/**
 * Justshoppe Pro module: Sticky Sidebar
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

class Justshoppe_Pro_Module_Sidebar_Sticky extends Justshoppe_Pro_Module {

	/**
	 * Module name
	 *
	 * @var string
	 */
	const MODULE_SLUG = 'sidebar-sticky';

	/**
	 * ====================================================
	 * Singleton & constructor functions
	 * ====================================================
	 */

	/**
	 * Class constructor
	 */
	protected function __construct() {
		parent::__construct();

		/**
		 * Customizer settings & values
		 */

		add_action( 'customize_register', array( $this, 'register_customizer_settings' ) );
		add_filter( 'justshoppe/customizer/setting_defaults', array( $this, 'add_customizer_setting_defaults' ) );

		/**
		 * Individual Page Settings
		 */

		add_action( 'justshoppe/admin/metabox/page_settings/fields/content', array( $this, 'render_meta_box_options' ), 15 );
		add_filter( 'justshoppe/dataset/fallback_page_settings', array( $this, 'add_fallback_page_settings' ) );

		/**
		 * Frontend
		 */

		add_filter( 'justshoppe/frontend/pro_localize_script', array( $this, 'add_localize_script' ) );
		add_filter( 'justshoppe/frontend/sidebar_classes', array( $this, 'add_sidebar_classes' ) );
	}
	
	/**
	 * ====================================================
	 * Hook functions
	 * ====================================================
	 */

	/**
	 * Add localize script for frontend Javascript.
	 *
	 * @param string $array
	 * @return string
	 */
	public function add_localize_script( $array ) {
		if ( intval( justshoppe_get_current_page_setting( 'sidebar_sticky' ) ) ) {
			$array['stickySidebar'] = array(
				'spacingTop'    => justshoppe_get_theme_mod( 'sidebar_sticky_spacing_top' ),
				'spacingBottom' => justshoppe_get_theme_mod( 'sidebar_sticky_spacing_bottom' ),
				'anchor'        => justshoppe_get_theme_mod( 'sidebar_sticky_anchor' ),
			);
		}

		return $array;
	}

	/**
	 * Add custom classes to the array of sidebar classes.
	 *
	 * @param array $classes
	 * @return array
	 */
	public function add_sidebar_classes( $classes ) {
		if ( intval( justshoppe_get_current_page_setting( 'sidebar_sticky' ) ) ) {
			$classes['sticky-sidebar'] = esc_attr( 'justshoppe-sidebar-sticky' );
		}

		return $classes;
	}

	/**
	 * Register customizer sections, settings, and controls.
	 *
	 * @param WP_Customize_Manager $wp_customize
	 */
	public function register_customizer_settings( $wp_customize ) {
		$defaults = Justshoppe_Customizer::instance()->get_setting_defaults();

		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/_sections.php' );
		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/content--sidebar-sticky.php' );
		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/_page-settings.php' );
	}
	
	/**
	 * Add default values for all Customizer settings.
	 *
	 * @param array $defaults
	 * @return array
	 */
	public function add_customizer_setting_defaults( $defaults = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/defaults.php' );

		return array_merge_recursive( $defaults, $add );
	}

	/**
	 * Add Page Settings metabox fields.
	 *
	 * @param WP_Post $obj
	 */
	public function render_meta_box_options( $obj ) {
		$option_key = 'justshoppe_page_settings';
		$values = Justshoppe_Admin_Metabox_Page_Settings::instance()->get_values( $obj );
		?>
		<div class="justshoppe-admin-form-row">
			<div class="justshoppe-admin-form-label"><label><?php esc_html_e( 'Sticky sidebar', 'justshoppe-features' ); ?></label></div>
			<div class="justshoppe-admin-form-field">
				<?php
				$key = 'sticky_sidebar';
				Justshoppe_Admin_Fields::render_field( array(
					'name'        => $option_key . '[' . $key . ']',
					'type'        => 'select',
					'choices'     => array(
						''  => esc_html__( '(Customizer)', 'justshoppe-features' ),
						'0' => esc_html__( '&#x2718; Disabled', 'justshoppe-features' ),
						'1' => esc_html__( '&#x2714; Enabled', 'justshoppe-features' ),
					),
					'value'       => justshoppe_array_value( $values, $key ),
				) );
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Modify fallback page settings.
	 *
	 * @param array $settings
	 * @return array
	 */
	public function add_fallback_page_settings( $settings ) {
		$settings['sidebar_sticky'] = justshoppe_get_theme_mod( 'sidebar_sticky', 0 );

		return $settings;
	}
}

Justshoppe_Pro_Module_Sidebar_Sticky::instance();