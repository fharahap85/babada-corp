<?php
/**
 * Justshoppe Pro module: White Label
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

class Justshoppe_Pro_Module_White_Label extends Justshoppe_Pro_Module {

	/**
	 * Module name
	 *
	 * @var string
	 */
	const MODULE_SLUG = 'white-label';

	/**
	 * ====================================================
	 * Singleton & constructor functions
	 * ====================================================
	 */

	/**
	 * Class constructor
	 */
	protected function __construct() {
		parent::__construct();

		/**
		 * Admin page
		 */

		if ( is_admin() ) {
			require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/class-justshoppe-pro-module-' . self::MODULE_SLUG . '-admin.php' );
		}
	}
}

Justshoppe_Pro_Module_White_Label::instance();