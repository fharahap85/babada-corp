<?php
/**
 * Justshoppe Pro module: Transparent Header
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

class Justshoppe_Pro_Module_Header_Transparent extends Justshoppe_Pro_Module {

	/**
	 * Module name
	 *
	 * @var string
	 */
	const MODULE_SLUG = 'header-transparent';

	/**
	 * ====================================================
	 * Singleton & constructor functions
	 * ====================================================
	 */

	/**
	 * Class constructor
	 */
	protected function __construct() {
		parent::__construct();

		/**
		 * Customizer settings & values
		 */

		add_action( 'customize_register', array( $this, 'register_customizer_settings' ) );
		add_filter( 'justshoppe/customizer/setting_defaults', array( $this, 'add_customizer_setting_defaults' ) );
		add_filter( 'justshoppe/customizer/setting_postmessages', array( $this, 'add_customizer_setting_postmessages' ) );
		add_filter( 'justshoppe/customizer/control_contexts', array( $this, 'add_customizer_control_contexts' ) );

		/**
		 * Individual Page Settings
		 */

		add_action( 'justshoppe/admin/metabox/page_settings/fields/header', array( $this, 'render_meta_box_options' ), 20 );
		add_filter( 'justshoppe/dataset/fallback_page_settings', array( $this, 'add_fallback_page_settings' ) );

		/**
		 * Frontend
		 */

		add_filter( 'justshoppe/frontend/header_classes', array( $this, 'add_header_classes' ) );
		add_filter( 'justshoppe/frontend/header_mobile_classes', array( $this, 'add_header_mobile_classes' ) );
		add_filter( 'justshoppe/frontend/pro_dynamic_css', array( $this, 'add_dynamic_css' ) );
	}
	
	/**
	 * ====================================================
	 * Hook functions
	 * ====================================================
	 */

	/**
	 * Add dynamic CSS from customizer settings into the inline CSS.
	 *
	 * @param string $css
	 * @return string
	 */
	public function add_dynamic_css( $css ) {
		// Skip adding dynamic CSS on customizer preview frame.
		if ( is_customize_preview() ) {
			return $css;
		}

		$postmessages = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/postmessages.php' );
		$defaults = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/defaults.php' );

		$css .= Justshoppe_Customizer::instance()->convert_postmessages_to_css_string( $postmessages, $defaults );

		return $css;
	}

	/**
	 * Register customizer sections, settings, and controls.
	 *
	 * @param WP_Customize_Manager $wp_customize
	 */
	public function register_customizer_settings( $wp_customize ) {
		$defaults = Justshoppe_Customizer::instance()->get_setting_defaults();

		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/_sections.php' );
		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/header--transparent.php' );
		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/header--alt-colors.php' );
		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/_page-settings.php' );
	}
	
	/**
	 * Add default values for all Customizer settings.
	 *
	 * @param array $defaults
	 * @return array
	 */
	public function add_customizer_setting_defaults( $defaults = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/defaults.php' );

		return array_merge_recursive( $defaults, $add );
	}

	/**
	 * Add postmessage rules for some Customizer settings.
	 *
	 * @param array $postmessages
	 * @return array
	 */
	public function add_customizer_setting_postmessages( $postmessages = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/postmessages.php' );

		return array_merge_recursive( $postmessages, $add );
	}
	
	/**
	 * Add dependency contexts for some Customizer settings.
	 *
	 * @param array $contexts
	 * @return array
	 */
	public function add_customizer_control_contexts( $contexts = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/contexts.php' );

		return array_merge_recursive( $contexts, $add );
	}

	/**
	 * Add Page Settings metabox fields.
	 *
	 * @param WP_Post $obj
	 */
	public function render_meta_box_options( $obj ) {
		$option_key = 'justshoppe_page_settings';
		$values = Justshoppe_Admin_Metabox_Page_Settings::instance()->get_values( $obj );
		?>
		<div class="justshoppe-admin-form-row">
			<div class="justshoppe-admin-form-label"><label><?php esc_html_e( 'Transparent header', 'justshoppe-features' ); ?></label></div>
			<div class="justshoppe-admin-form-field">
				<label class="justshoppe-admin-form-field-device-group">
					<span class="dashicons dashicons-desktop"></span>
					<?php
					$key = 'header_transparent';
					Justshoppe_Admin_Fields::render_field( array(
						'name'        => $option_key . '[' . $key . ']',
						'type'        => 'select',
						'choices'     => array(
							''  => esc_html__( '(Customizer)', 'justshoppe-features' ),
							'0' => esc_html__( '&#x2718; Disabled', 'justshoppe-features' ),
							'1' => esc_html__( '&#x2714; Enabled', 'justshoppe-features' ),
						),
						'value'       => justshoppe_array_value( $values, $key ),
					) );
					?>
				</label>
				<label class="justshoppe-admin-form-field-device-group">
					<span class="dashicons dashicons-tablet"></span>
					<?php
					$key = 'header_mobile_transparent';
					Justshoppe_Admin_Fields::render_field( array(
						'name'        => $option_key . '[' . $key . ']',
						'type'        => 'select',
						'choices'     => array(
							''  => esc_html__( '(Customizer)', 'justshoppe-features' ),
							'0' => esc_html__( '&#x2718; Disabled', 'justshoppe-features' ),
							'1' => esc_html__( '&#x2714; Enabled', 'justshoppe-features' ),
						),
						'value'       => justshoppe_array_value( $values, $key ),
					) );
					?>
				</label>
				
			</div>
		</div>
		<?php
	}

	/**
	 * Add custom classes to the array of main header classes.
	 *
	 * @param array $classes
	 * @return array
	 */
	public function add_header_classes( $classes ) {
		if ( intval( justshoppe_get_current_page_setting( 'header_transparent' ) ) ) {
			$classes['transparent'] = esc_attr( 'justshoppe-header-main-transparent justshoppe-header-transparent' );
		}

		return $classes;
	}

	/**
	 * Add custom classes to the array of mobile header classes.
	 *
	 * @param array $classes
	 * @return array
	 */
	public function add_header_mobile_classes( $classes ) {
		if ( intval( justshoppe_get_current_page_setting( 'header_mobile_transparent' ) ) ) {
			$classes['transparent'] = esc_attr( 'justshoppe-header-mobile-transparent justshoppe-header-transparent' );
		}

		return $classes;
	}

	/**
	 * Modify fallback page settings.
	 *
	 * @param array $settings
	 * @return array
	 */
	public function add_fallback_page_settings( $settings ) {
		$settings['header_transparent'] = justshoppe_get_theme_mod( 'header_transparent', 0 );
		$settings['header_mobile_transparent'] = justshoppe_get_theme_mod( 'header_mobile_transparent', 0 );

		return $settings;
	}
}

Justshoppe_Pro_Module_Header_Transparent::instance();