<?php
/**
 * Justshoppe Pro module: Vertical Header
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

class Justshoppe_Pro_Module_Header_Vertical extends Justshoppe_Pro_Module {

	/**
	 * Module name
	 *
	 * @var string
	 */
	const MODULE_SLUG = 'header-vertical';

	/**
	 * ====================================================
	 * Singleton & constructor functions
	 * ====================================================
	 */

	/**
	 * Class constructor
	 */
	protected function __construct() {
		parent::__construct();

		/**
		 * Global
		 */

		add_action( 'init', array( $this, 'register_new_menus' ) );

		/**
		 * Customizer settings & values
		 */

		add_action( 'customize_register', array( $this, 'register_customizer_settings' ) );
		add_filter( 'justshoppe/customizer/setting_defaults', array( $this, 'add_customizer_setting_defaults' ) );
		add_filter( 'justshoppe/customizer/setting_postmessages', array( $this, 'add_customizer_setting_postmessages' ) );
		add_filter( 'justshoppe/customizer/control_contexts', array( $this, 'add_customizer_control_contexts' ) );
		add_filter( 'justshoppe/dataset/header_builder_configurations', array( $this, 'modify_header_builder_configurations' ) );

		/**
		 * Frontend
		 */

		add_action( 'justshoppe/frontend/before_canvas', array( $this, 'render_vertical_header' ) );
		add_filter( 'justshoppe/frontend/header_vertical_classes', array( $this, 'header_vertical_classes' ), 10, 2 );
		add_filter( 'justshoppe/frontend/pro_dynamic_css', array( $this, 'add_dynamic_css' ) );
	}
	
	/**
	 * ====================================================
	 * Hook functions
	 * ====================================================
	 */

	/**
	 * Add dynamic CSS from customizer settings into the inline CSS.
	 *
	 * @param string $css
	 * @return string
	 */
	public function add_dynamic_css( $css ) {
		// Skip adding dynamic CSS on customizer preview frame.
		if ( is_customize_preview() ) {
			return $css;
		}

		$postmessages = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/postmessages.php' );
		$defaults = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/defaults.php' );

		$css .= Justshoppe_Customizer::instance()->convert_postmessages_to_css_string( $postmessages, $defaults );

		return $css;
	}

	/**
	 * Registers additional menu locations.
	 */
	public function register_new_menus() {
		register_nav_menus( array(
			'header-vertical-menu' => esc_html__( 'Vertical Header Menu', 'justshoppe-features' ),
		) );
	}

	/**
	 * Register customizer sections, settings, and controls.
	 *
	 * @param WP_Customize_Manager $wp_customize
	 */
	public function register_customizer_settings( $wp_customize ) {
		$defaults = Justshoppe_Customizer::instance()->get_setting_defaults();

		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/_sections.php' );
		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/header--vertical-bar.php' );
	}
	
	/**
	 * Add default values for all Customizer settings.
	 *
	 * @param array $defaults
	 * @return array
	 */
	public function add_customizer_setting_defaults( $defaults = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/defaults.php' );

		return array_merge_recursive( $defaults, $add );
	}

	/**
	 * Add postmessage rules for some Customizer settings.
	 *
	 * @param array $postmessages
	 * @return array
	 */
	public function add_customizer_setting_postmessages( $postmessages = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/postmessages.php' );

		return array_merge_recursive( $postmessages, $add );
	}

	/**
	 * Add dependency contexts for some Customizer settings.
	 *
	 * @param array $contexts
	 * @return array
	 */
	public function add_customizer_control_contexts( $contexts = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/contexts.php' );

		return array_merge_recursive( $contexts, $add );
	}

	/**
	 * Modify header builder configurations.
	 *
	 * @param array $config
	 * @return array
	 */
	public function modify_header_builder_configurations( $config ) {
		$config = array_merge_recursive( array(
			'locations' => array(
				'vertical_top'    => esc_html__( 'Vertical - Top', 'justshoppe-features' ),
				'vertical_middle' => esc_html__( 'Vertical - Middle', 'justshoppe-features' ),
				'vertical_bottom' => esc_html__( 'Vertical - Bottom', 'justshoppe-features' ),
			),
			'choices' => array(
				'vertical-menu'   => '<span class="dashicons dashicons-admin-links"></span>' . esc_html__( 'Vertical Menu', 'justshoppe-features' ),
				'vertical-toggle' => '<span class="dashicons dashicons-menu"></span>' . esc_html__( 'Vertical Toggle', 'justshoppe-features' ),
			),
			'limitations' => array(
				// Free elements
				'menu-1'          => array( 'vertical_top', 'vertical_middle', 'vertical_bottom' ),
				'search-dropdown' => array( 'vertical_top', 'vertical_middle', 'vertical_bottom' ),

				// Pro elements
				'menu-2'          => array( 'vertical_top', 'vertical_middle', 'vertical_bottom' ),
				'menu-3'          => array( 'vertical_top', 'vertical_middle', 'vertical_bottom' ),
				'vertical-menu'   => array( 'top_left', 'top_center', 'top_right', 'main_left', 'main_center', 'main_right', 'bottom_left', 'bottom_center', 'bottom_right' ),
				'vertical-toggle' => array( 'vertical_top', 'vertical_middle', 'vertical_bottom' ),
			),
		), $config );

		// WooCommerce
		if ( class_exists( 'WooCommerce' ) ) {
			$config['limitations'] = array_merge_recursive( $config['limitations'], array(
				'cart-link'       => array( 'vertical_top', 'vertical_middle', 'vertical_bottom' ),
				'cart-dropdown'   => array( 'vertical_top', 'vertical_middle', 'vertical_bottom' ),
				'cart-off-canvas' => array( 'vertical_top', 'vertical_middle', 'vertical_bottom' ),
			) );
		}

		return $config;
	}

	/**
	 * Add custom classes to the array of header main bar section classes.
	 *
	 * @param array $classes
	 * @return array
	 */
	function header_vertical_classes( $classes ) {
		$display = justshoppe_get_theme_mod( 'header_vertical_bar_display' );

		$classes['display'] = esc_attr( 'justshoppe-header-vertical-display-' . $display );

		if ( 'full-screen' == $display ) {
			$classes['position'] = esc_attr( 'justshoppe-header-vertical-position-' . justshoppe_get_theme_mod( 'header_vertical_bar_full_screen_position' ) );
		} else {
			$classes['position'] = esc_attr( 'justshoppe-header-vertical-position-' . justshoppe_get_theme_mod( 'header_vertical_bar_position' ) );
		}

		if ( 'fixed' !== $display ) {
			$classes['popup'] = esc_attr( 'justshoppe-popup' );
		}

		$classes['alignment'] = esc_attr( 'justshoppe-text-align-' . justshoppe_get_theme_mod( 'header_vertical_bar_alignment' ) );

		return $classes;
	}

	/**
	 * ====================================================
	 * Render functions
	 * ====================================================
	 */

	/**
	 * Render vertical header.
	 */
	public function render_vertical_header() {
		if ( intval( justshoppe_get_current_page_setting( 'disable_header' ) ) ) {
			return;
		}

		justshoppe_get_template_part( 'header-vertical' );
	}
}

Justshoppe_Pro_Module_Header_Vertical::instance();