<?php
/**
 * Justshoppe Pro module: Footer Widgets Columns Width
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

class Justshoppe_Pro_Module_Footer_Widgets_Columns_Width extends Justshoppe_Pro_Module {

	/**
	 * Module name
	 *
	 * @var string
	 */
	const MODULE_SLUG = 'footer-widgets-columns-width';

	/**
	 * ====================================================
	 * Singleton & constructor functions
	 * ====================================================
	 */

	/**
	 * Class constructor
	 */
	protected function __construct() {
		parent::__construct();

		/**
		 * Customizer settings & values
		 */

		add_action( 'customize_register', array( $this, 'register_customizer_settings' ) );
		add_filter( 'justshoppe/customizer/setting_postmessages', array( $this, 'add_customizer_setting_postmessages' ) );
		add_filter( 'justshoppe/customizer/control_contexts', array( $this, 'add_customizer_control_contexts' ) );
		
		/**
		 * Frontend
		 */

		add_filter( 'justshoppe/frontend/pro_dynamic_css', array( $this, 'add_dynamic_css' ) );
	}
	
	/**
	 * ====================================================
	 * Hook functions
	 * ====================================================
	 */

	/**
	 * Add dynamic CSS from customizer settings into the inline CSS.
	 *
	 * @param string $css
	 * @return string
	 */
	public function add_dynamic_css( $css ) {
		// Skip adding dynamic CSS on customizer preview frame.
		if ( is_customize_preview() ) {
			return $css;
		}

		$postmessages = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/postmessages.php' );

		$css .= Justshoppe_Customizer::instance()->convert_postmessages_to_css_string( $postmessages );

		return $css;
	}

	/**
	 * Register customizer sections, settings, and controls.
	 *
	 * @param WP_Customize_Manager $wp_customize
	 */
	public function register_customizer_settings( $wp_customize ) {
		$defaults = Justshoppe_Customizer::instance()->get_setting_defaults();

		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/footer--builder.php' );
	}

	/**
	 * Add postmessage rules for some Customizer settings.
	 *
	 * @param array $postmessages
	 * @return array
	 */
	public function add_customizer_setting_postmessages( $postmessages = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/postmessages.php' );

		return array_merge_recursive( $postmessages, $add );
	}

	/**
	 * Add dependency contexts for some Customizer settings.
	 *
	 * @param array $contexts
	 * @return array
	 */
	public function add_customizer_control_contexts( $contexts = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/contexts.php' );

		return array_merge_recursive( $contexts, $add );
	}
}

Justshoppe_Pro_Module_Footer_Widgets_Columns_Width::instance();