<?php
/**
 * Justshoppe Pro module: Blocks Admin page
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

class Justshoppe_Pro_Module_WooCommerce_Layout_Plus_Admin {

	/**
	 * Singleton instance
	 *
	 * @var Justshoppe_Pro_Module_WooCommerce_Layout_Plus_Admin
	 */
	private static $instance;

	/**
	 * ====================================================
	 * Singleton & constructor functions
	 * ====================================================
	 */

	/**
	 * Get singleton instance.
	 *
	 * @return Justshoppe_Pro_Module_WooCommerce_Layout_Plus_Admin
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Class constructor
	 */
	protected function __construct() {
		// Page Settings
		add_action( 'justshoppe/admin/metabox/page_settings/fields', array( $this, 'render_page_settings_fields__product' ), 10, 2 );
	}
	
	/**
	 * ====================================================
	 * Hook functions
	 * ====================================================
	 */

	/**
	 * Render "Product Layout" options on Page Settings meta box.
	 *
	 * @param WP_Post|WP_Term $obj
	 * @param string $tab
	 */
	public function render_page_settings_fields__product( $obj, $tab ) {
		if ( 'woocommerce-single' !== $tab ) {
			return;
		}

		$option_key = 'justshoppe_page_settings';

		$values = get_post_meta( $obj->ID, '_' . $option_key, true );

		$keys = array(
			'woocommerce_single_breadcrumb' => esc_html__( 'Show breadcrumb', 'justshoppe-features' ),
			'woocommerce_single_gallery' => esc_html__( 'Show gallery', 'justshoppe-features' ),
			'woocommerce_single_tabs' => esc_html__( 'Show tabs', 'justshoppe-features' ),
			'woocommerce_single_up_sells' => esc_html__( 'Show up-sells', 'justshoppe-features' ),
			'woocommerce_single_related' => esc_html__( 'Show related products', 'justshoppe-features' ),
		);

		foreach ( $keys as $key => $label ) : ?>
			<div class="justshoppe-admin-form-row">
				<div class="justshoppe-admin-form-label"><label><?php echo $label; // WPCS: XSS OK ?></label></div>
				<div class="justshoppe-admin-form-field">
					<?php
					Justshoppe_Admin_Fields::render_field( array(
						'name'        => $option_key . '[' . $key . ']',
						'type'        => 'select',
						'choices'     => array(
							''  => esc_html__( '(Customizer)', 'justshoppe-features' ),
							'0' => esc_html__( '&#x2718; No', 'justshoppe-features' ),
							'1' => esc_html__( '&#x2714; Yes', 'justshoppe-features' ),
						),
						'value'       => justshoppe_array_value( $values, $key ),
					) );
					?>
				</div>
			</div>

			<?php if ( 'woocommerce_single_gallery' === $key ) : ?>
				<div class="justshoppe-admin-form-row">
					<div class="justshoppe-admin-form-label"><label><?php esc_html_e( 'Gallery layout', 'justshoppe-features' ); ?></label></div>
					<div class="justshoppe-admin-form-field">
						<?php
						Justshoppe_Admin_Fields::render_field( array(
							'name'        => $option_key . '[woocommerce_single_gallery_layout]',
							'type'        => 'radioimage',
							'choices'     => array(
								''           => array(
									'label' => esc_html__( '(Customizer)', 'justshoppe-features' ),
									'image' => JUSTSHOPPE_IMAGES_URL . '/customizer/customizer.svg',
								),
								'bottom' => array(
									'label' => esc_html__( 'Bottom', 'justshoppe-features' ),
									'image' => trailingslashit( JUSTSHOPPE_PRO_IMAGES_URL ) . 'customizer/woocommerce-gallery-layout--bottom.svg',
								),
								'left'   => array(
									'label' => is_rtl() ? esc_html__( 'Right', 'justshoppe-features' ) : esc_html__( 'Left', 'justshoppe-features' ),
									'image' => trailingslashit( JUSTSHOPPE_PRO_IMAGES_URL ) . 'customizer/woocommerce-gallery-layout--left.svg',
								),
								'right'  => array(
									'label' => is_rtl() ? esc_html__( 'Left', 'justshoppe-features' ) : esc_html__( 'Right', 'justshoppe-features' ),
									'image' => trailingslashit( JUSTSHOPPE_PRO_IMAGES_URL ) . 'customizer/woocommerce-gallery-layout--right.svg',
								),
							),
							'value'       => justshoppe_array_value( $values, 'woocommerce_single_gallery_layout' ),
						) );
						?>
					</div>
				</div>
			<?php endif; ?>
		<?php endforeach;
	}
}

Justshoppe_Pro_Module_WooCommerce_Layout_Plus_Admin::instance();