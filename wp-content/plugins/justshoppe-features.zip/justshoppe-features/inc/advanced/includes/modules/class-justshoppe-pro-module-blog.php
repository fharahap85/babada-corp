<?php
/**
 * Justshoppe Pro Blog module base class
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

abstract class Justshoppe_Pro_Module_Blog extends Justshoppe_Pro_Module {

	/**
	 * ====================================================
	 * Singleton & constructor functions
	 * ====================================================
	 */

	/**
	 * Class constructor
	 */
	protected function __construct() {
		parent::__construct();
	}

	/**
	 * ====================================================
	 * Hook functions
	 * ====================================================
	 */

	
}