<?php
/**
 * Justshoppe Pro module: Sticky Header
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

class Justshoppe_Pro_Module_Header_Sticky extends Justshoppe_Pro_Module {

	/**
	 * Module name
	 *
	 * @var string
	 */
	const MODULE_SLUG = 'header-sticky';

	/**
	 * ====================================================
	 * Singleton & constructor functions
	 * ====================================================
	 */

	/**
	 * Class constructor
	 */
	protected function __construct() {
		parent::__construct();

		/**
		 * Customizer settings & values
		 */

		add_action( 'customize_register', array( $this, 'register_customizer_settings' ) );
		add_filter( 'justshoppe/customizer/setting_defaults', array( $this, 'add_customizer_setting_defaults' ) );
		add_filter( 'justshoppe/customizer/setting_postmessages', array( $this, 'add_customizer_setting_postmessages' ) );
		add_filter( 'justshoppe/customizer/control_contexts', array( $this, 'add_customizer_control_contexts' ) );

		/**
		 * Individual Page Settings
		 */

		add_action( 'justshoppe/admin/metabox/page_settings/fields/header', array( $this, 'render_meta_box_options' ), 30 );
		add_filter( 'justshoppe/dataset/fallback_page_settings', array( $this, 'add_fallback_page_settings' ) );

		/**
		 * Frontend
		 */

		add_filter( 'justshoppe/frontend/pro_localize_script', array( $this, 'add_localize_script' ) );
		add_filter( 'justshoppe/frontend/pro_dynamic_css', array( $this, 'add_dynamic_css' ) );

		add_filter( 'justshoppe/frontend/header_' . justshoppe_get_theme_mod( 'header_sticky_bar' ) . '_bar_classes', array( $this, 'add_header_sticky_bar_classes' ) );
		add_action( 'justshoppe/frontend/logo', array( $this, 'render_header_sticky_logo' ), 20 );

		add_filter( 'justshoppe/frontend/header_mobile_main_bar_classes', array( $this, 'add_header_mobile_sticky_bar_classes' ) );
		add_action( 'justshoppe/frontend/mobile_logo', array( $this, 'render_header_mobile_sticky_logo' ), 20 );
	}
	
	/**
	 * ====================================================
	 * Hook functions
	 * ====================================================
	 */

	/**
	 * Add localize script for frontend Javascript.
	 *
	 * @param string $array
	 * @return string
	 */
	public function add_localize_script( $array ) {
		if ( intval( justshoppe_get_current_page_setting( 'header_sticky' ) ) ) {
			$bar = justshoppe_get_theme_mod( 'header_sticky_bar' );

			$array['stickyHeader'] = array(
				'bar'             => $bar,
				'normalHeight'    => intval( justshoppe_get_theme_mod( 'header_' . $bar . '_bar_height' ) ),
				'stickyHeight'    => min( intval( justshoppe_get_theme_mod( 'header_sticky_height' ) ), intval( justshoppe_get_theme_mod( 'header_' . $bar . '_bar_height' ) ) ),
				'stickyDisplay'   => justshoppe_get_theme_mod( 'header_sticky_display' ),
				'logoNormalWidth' => intval( justshoppe_get_theme_mod( 'header_logo_width' ) ),
				'logoStickyWidth' => intval( justshoppe_get_theme_mod( 'header_sticky_logo_width', justshoppe_get_theme_mod( 'header_logo_width' ) ) ),
				
				'containedWidth'  => intval( justshoppe_get_theme_mod( 'container_width' ) ),
			);
		}

		if ( intval( justshoppe_get_current_page_setting( 'header_mobile_sticky' ) ) ) {
			$array['stickyMobileHeader'] = array(
				'normalHeight'    => intval( justshoppe_get_theme_mod( 'header_mobile_main_bar_height' ) ),
				'stickyHeight'    => min( intval( justshoppe_get_theme_mod( 'header_mobile_sticky_height' ) ), intval( justshoppe_get_theme_mod( 'header_mobile_main_bar_height' ) ) ),
				'stickyDisplay'   => justshoppe_get_theme_mod( 'header_mobile_sticky_display' ),
				'logoNormalWidth' => intval( justshoppe_get_theme_mod( 'header_mobile_logo_width' ) ),
				'logoStickyWidth' => intval( justshoppe_get_theme_mod( 'header_mobile_sticky_logo_width', justshoppe_get_theme_mod( 'header_mobile_logo_width' ) ) ),
			);
		}

		return $array;
	}

	/**
	 * Add dynamic CSS from customizer settings into the inline CSS.
	 *
	 * @param string $css
	 * @return string
	 */
	public function add_dynamic_css( $css ) {
		// Skip adding dynamic CSS on customizer preview frame.
		if ( is_customize_preview() ) {
			return $css;
		}

		$postmessages = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/postmessages.php' );
		$defaults = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/defaults.php' );

		$css .= Justshoppe_Customizer::instance()->convert_postmessages_to_css_string( $postmessages, $defaults );

		return $css;
	}

	/**
	 * Add custom classes to the array of sticky header bar classes.
	 *
	 * @param array $classes
	 * @return array
	 */
	public function add_header_sticky_bar_classes( $classes ) {
		if ( intval( justshoppe_get_current_page_setting( 'header_sticky' ) ) ) {
			$classes['sticky'] = esc_attr( 'justshoppe-header-sticky' );
			$classes['sticky_display'] = esc_attr( 'justshoppe-header-sticky-display-' . justshoppe_get_theme_mod( 'header_sticky_display' ) );
		}

		return $classes;
	}

	/**
	 * Add custom classes to the array of sticky mobile header bar classes.
	 *
	 * @param array $classes
	 * @return array
	 */
	public function add_header_mobile_sticky_bar_classes( $classes ) {
		if ( intval( justshoppe_get_current_page_setting( 'header_mobile_sticky' ) ) ) {
			$classes['sticky'] = esc_attr( 'justshoppe-header-sticky' );
			$classes['sticky_display'] = esc_attr( 'justshoppe-header-sticky-display-' . justshoppe_get_theme_mod( 'header_mobile_sticky_display' ) );
		}

		return $classes;
	}

	/**
	 * Register customizer sections, settings, and controls.
	 *
	 * @param WP_Customize_Manager $wp_customize
	 */
	public function register_customizer_settings( $wp_customize ) {
		$defaults = Justshoppe_Customizer::instance()->get_setting_defaults();

		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/_sections.php' );
		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/header--sticky.php' );
		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/_page-settings.php' );
	}
	
	/**
	 * Add default values for all Customizer settings.
	 *
	 * @param array $defaults
	 * @return array
	 */
	public function add_customizer_setting_defaults( $defaults = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/defaults.php' );

		return array_merge_recursive( $defaults, $add );
	}

	/**
	 * Add postmessage rules for some Customizer settings.
	 *
	 * @param array $postmessages
	 * @return array
	 */
	public function add_customizer_setting_postmessages( $postmessages = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/postmessages.php' );

		return array_merge_recursive( $postmessages, $add );
	}
	
	/**
	 * Add dependency contexts for some Customizer settings.
	 *
	 * @param array $contexts
	 * @return array
	 */
	public function add_customizer_control_contexts( $contexts = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/contexts.php' );

		return array_merge_recursive( $contexts, $add );
	}

	/**
	 * Add Page Settings metabox fields.
	 *
	 * @param WP_Post $obj
	 */
	public function render_meta_box_options( $obj ) {
		$option_key = 'justshoppe_page_settings';
		$values = Justshoppe_Admin_Metabox_Page_Settings::instance()->get_values( $obj );
		?>
		<div class="justshoppe-admin-form-row">
			<div class="justshoppe-admin-form-label"><label><?php esc_html_e( 'Sticky header', 'justshoppe-features' ); ?></label></div>
			<div class="justshoppe-admin-form-field">
				<label class="justshoppe-admin-form-field-device-group">
					<span class="dashicons dashicons-desktop"></span>
					<?php
					$key = 'header_sticky';
					Justshoppe_Admin_Fields::render_field( array(
						'name'        => $option_key . '[' . $key . ']',
						'type'        => 'select',
						'choices'     => array(
							''  => esc_html__( '(Customizer)', 'justshoppe-features' ),
							'0' => esc_html__( '&#x2718; Disabled', 'justshoppe-features' ),
							'1' => esc_html__( '&#x2714; Enabled', 'justshoppe-features' ),
						),
						'value'       => justshoppe_array_value( $values, $key ),
					) );
					?>
				</label>
				<label class="justshoppe-admin-form-field-device-group">
					<span class="dashicons dashicons-tablet"></span>
					<?php
					$key = 'header_mobile_sticky';
					Justshoppe_Admin_Fields::render_field( array(
						'name'        => $option_key . '[' . $key . ']',
						'type'        => 'select',
						'choices'     => array(
							''  => esc_html__( '(Customizer)', 'justshoppe-features' ),
							'0' => esc_html__( '&#x2718; Disabled', 'justshoppe-features' ),
							'1' => esc_html__( '&#x2714; Enabled', 'justshoppe-features' ),
						),
						'value'       => justshoppe_array_value( $values, $key ),
					) );
					?>
				</label>
			</div>
		</div>
		<?php
	}

	/**
	 * Modify fallback page settings.
	 *
	 * @param array $settings
	 * @return array
	 */
	public function add_fallback_page_settings( $settings ) {
		$settings['header_sticky'] = justshoppe_get_theme_mod( 'header_sticky', 0 );
		$settings['header_mobile_sticky'] = justshoppe_get_theme_mod( 'header_mobile_sticky', 0 );

		return $settings;
	}

	/**
	 * ====================================================
	 * Render functions
	 * ====================================================
	 */

	/**
	 * Render sticky logo.
	 */
	public function render_header_sticky_logo() {
		?>
		<span class="justshoppe-sticky-logo justshoppe-logo"><?php justshoppe_logo( justshoppe_get_theme_mod( 'custom_logo_sticky', justshoppe_get_theme_mod( 'custom_logo' ) ) ); ?></span>
		<?php
	}

	/**
	 * Render sticky mobile logo.
	 */
	public function render_header_mobile_sticky_logo() {
		?>
		<span class="justshoppe-sticky-logo justshoppe-logo"><?php justshoppe_logo( justshoppe_get_theme_mod( 'custom_logo_mobile_sticky', justshoppe_get_theme_mod( 'custom_logo_mobile' ) ) ); ?></span>
		<?php
	}
}

Justshoppe_Pro_Module_Header_Sticky::instance();