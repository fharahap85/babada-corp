<?php
/**
 * Justshoppe Pro module: Alt_Colors Header
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

class Justshoppe_Pro_Module_Header_Alt_Colors extends Justshoppe_Pro_Module {

	/**
	 * Module name
	 *
	 * @var string
	 */
	const MODULE_SLUG = 'header-alt-colors';

	/**
	 * ====================================================
	 * Singleton & constructor functions
	 * ====================================================
	 */

	/**
	 * Class constructor
	 */
	protected function __construct() {
		parent::__construct();

		/**
		 * Customizer settings & values
		 */

		add_action( 'customize_register', array( $this, 'register_customizer_settings' ) );
		add_filter( 'justshoppe/customizer/setting_postmessages', array( $this, 'add_customizer_setting_postmessages' ) );
		add_filter( 'justshoppe/customizer/control_contexts', array( $this, 'add_customizer_control_contexts' ) );

		/**
		 * Individual Page Settings
		 */
		
		add_filter( 'justshoppe/dataset/fallback_page_settings', array( $this, 'add_fallback_page_settings' ) );
		add_action( 'justshoppe/admin/metabox/page_settings/fields/header', array( $this, 'render_meta_box_options' ), 40 );

		/**
		 * Frontend
		 */

		add_filter( 'justshoppe/frontend/pro_dynamic_css', array( $this, 'add_dynamic_css' ) );

		add_filter( 'justshoppe/frontend/header_classes', array( $this, 'add_header_classes' ) );
		add_filter( 'justshoppe/frontend/header_mobile_classes', array( $this, 'add_header_mobile_classes' ) );

		add_action( 'justshoppe/frontend/logo', array( $this, 'render_header_alt_colors_logo' ), 9 );
		add_action( 'justshoppe/frontend/mobile_logo', array( $this, 'render_header_mobile_alt_colors_logo' ), 9 );
	}
	
	/**
	 * ====================================================
	 * Hook functions
	 * ====================================================
	 */

	/**
	 * Add dynamic CSS from customizer settings into the inline CSS.
	 *
	 * @param string $css
	 * @return string
	 */
	public function add_dynamic_css( $css ) {
		// Skip adding dynamic CSS on customizer preview frame.
		if ( is_customize_preview() ) {
			return $css;
		}

		$postmessages = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/postmessages.php' );

		$css .= Justshoppe_Customizer::instance()->convert_postmessages_to_css_string( $postmessages );

		return $css;
	}

	/**
	 * Register customizer sections, settings, and controls.
	 *
	 * @param WP_Customize_Manager $wp_customize
	 */
	public function register_customizer_settings( $wp_customize ) {
		$defaults = Justshoppe_Customizer::instance()->get_setting_defaults();

		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/_sections.php' );
		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/header--alt-colors.php' );
		require_once( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/options/_page-settings.php' );
	}

	/**
	 * Add postmessage rules for some Customizer settings.
	 *
	 * @param array $postmessages
	 * @return array
	 */
	public function add_customizer_setting_postmessages( $postmessages = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/postmessages.php' );

		return array_merge_recursive( $postmessages, $add );
	}
	
	/**
	 * Add dependency contexts for some Customizer settings.
	 *
	 * @param array $contexts
	 * @return array
	 */
	public function add_customizer_control_contexts( $contexts = array() ) {
		$add = include( trailingslashit( JUSTSHOPPE_PRO_INCLUDES_DIR ) . 'modules/' . self::MODULE_SLUG . '/customizer/contexts.php' );

		return array_merge_recursive( $contexts, $add );
	}

	/**
	 * Add Page Settings metabox fields.
	 *
	 * @param WP_Post $obj
	 */
	public function render_meta_box_options( $obj ) {
		$option_key = 'justshoppe_page_settings';
		$values = Justshoppe_Admin_Metabox_Page_Settings::instance()->get_values( $obj );
		?>
		<div class="justshoppe-admin-form-row">
			<div class="justshoppe-admin-form-label"><label><?php esc_html_e( 'Colors', 'justshoppe-features' ); ?></label></div>
			<div class="justshoppe-admin-form-field">
				<label class="justshoppe-admin-form-field-device-group">
					<span class="dashicons dashicons-desktop"></span>
					<?php
					$key = 'header_alt_colors';
					Justshoppe_Admin_Fields::render_field( array(
						'name'        => $option_key . '[' . $key . ']',
						'type'        => 'select',
						'choices'     => array(
							''  => esc_html__( '(Customizer)', 'justshoppe-features' ),
							'0' => esc_html__( '&#x25cb; Primary', 'justshoppe-features' ),
							'1' => esc_html__( '&#x25cf; Alternate', 'justshoppe-features' ),
						),
						'value'       => justshoppe_array_value( $values, $key ),
					) );
					?>
				</label>
				<label class="justshoppe-admin-form-field-device-group">
					<span class="dashicons dashicons-tablet"></span>
					<?php
					$key = 'header_mobile_alt_colors';
					Justshoppe_Admin_Fields::render_field( array(
						'name'        => $option_key . '[' . $key . ']',
						'type'        => 'select',
						'choices'     => array(
							''  => esc_html__( '(Customizer)', 'justshoppe-features' ),
							'0' => esc_html__( '&#x25cb; Primary', 'justshoppe-features' ),
							'1' => esc_html__( '&#x25cf; Alternate', 'justshoppe-features' ),
						),
						'value'       => justshoppe_array_value( $values, $key ),
					) );
					?>
				</label>
			</div>
		</div>
		<?php
	}

	/**
	 * Add custom classes to the array of main header classes.
	 *
	 * @param array $classes
	 * @return array
	 */
	public function add_header_classes( $classes ) {
		if ( intval( justshoppe_get_current_page_setting( 'header_alt_colors' ) ) ) {
			$classes['alt_colors'] = esc_attr( 'justshoppe-header-main-alt-colors' );
		}

		return $classes;
	}

	/**
	 * Add custom classes to the array of mobile header classes.
	 *
	 * @param array $classes
	 * @return array
	 */
	public function add_header_mobile_classes( $classes ) {
		if ( intval( justshoppe_get_current_page_setting( 'header_mobile_alt_colors' ) ) ) {
			$classes['alt_colors'] = esc_attr( 'justshoppe-header-mobile-alt-colors' );
		}

		return $classes;
	}

	/**
	 * Modify fallback page settings.
	 *
	 * @param array $settings
	 * @return array
	 */
	public function add_fallback_page_settings( $settings ) {
		$settings['header_alt_colors'] = justshoppe_get_theme_mod( 'header_alt_colors', 0 );
		$settings['header_mobile_alt_colors'] = justshoppe_get_theme_mod( 'header_mobile_alt_colors', 0 );

		return $settings;
	}

	/**
	 * Render alt_colors logo.
	 */
	public function render_header_alt_colors_logo() {
		if ( intval( justshoppe_get_current_page_setting( 'header_alt_colors' ) ) ) {
			remove_action( 'justshoppe/frontend/logo', 'justshoppe_default_logo' );
			
			$alt_colors_logo_id = justshoppe_get_theme_mod( 'custom_logo_alt' );
			if ( empty( $alt_colors_logo_id ) ) {
				$alt_colors_logo_id = justshoppe_get_theme_mod( 'custom_logo' );
			}
			?>
			<span class="justshoppe-alt-colors-logo justshoppe-default-logo justshoppe-logo"><?php justshoppe_logo( $alt_colors_logo_id ); ?></span>
			<?php
		}
	}

	/**
	 * Render alt_colors mobile logo.
	 */
	public function render_header_mobile_alt_colors_logo() {
		if ( intval( justshoppe_get_current_page_setting( 'header_mobile_alt_colors' ) ) ) {
			remove_action( 'justshoppe/frontend/mobile_logo', 'justshoppe_default_mobile_logo' );

			$alt_colors_logo_id = justshoppe_get_theme_mod( 'custom_logo_mobile_alt' );
			if ( empty( $alt_colors_logo_id ) ) {
				$alt_colors_logo_id = justshoppe_get_theme_mod( 'custom_logo_mobile' );
			}
			?>
			<span class="justshoppe-alt-colors-logo justshoppe-default-logo justshoppe-logo"><?php justshoppe_logo( $alt_colors_logo_id ); ?></span>
			<?php
		}
	}
}

Justshoppe_Pro_Module_Header_Alt_Colors::instance();