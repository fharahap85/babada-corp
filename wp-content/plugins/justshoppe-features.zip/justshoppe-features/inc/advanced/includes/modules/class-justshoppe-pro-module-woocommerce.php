<?php
/**
 * Justshoppe Pro WooCommerce module base class
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

abstract class Justshoppe_Pro_Module_WooCommerce extends Justshoppe_Pro_Module {

	/**
	 * ====================================================
	 * Singleton & constructor functions
	 * ====================================================
	 */

	/**
	 * Class constructor
	 */
	protected function __construct() {
		parent::__construct();
	}

	/**
	 * ====================================================
	 * Hook functions
	 * ====================================================
	 */

	/**
	 * Enqueue frontend CSS.
	 */
	public function enqueue_css() {
		parent::enqueue_css();

		if ( ! wp_style_is( 'justshoppe-pro-woocommerce', 'enqueued' ) ) {
			// WooCommerce CSS
			wp_enqueue_style( 'justshoppe-pro-woocommerce', trailingslashit( JUSTSHOPPE_PRO_CSS_URL ) . 'compatibilities/pro-woocommerce' . JUSTSHOPPE_ASSETS_SUFFIX . '.css', array( 'justshoppe-features' ), JUSTSHOPPE_PRO_VERSION );
			wp_style_add_data( 'justshoppe-pro-woocommerce', 'rtl', 'replace' );

			// Inline CSS
			$dynamic_css = trim( apply_filters( 'justshoppe/frontend/woocommerce/pro_dynamic_css', '' ) );
			if ( ! empty( $dynamic_css ) ) {
				$dynamic_css = "/* Justshoppe Pro + WooCommerce Dynamic CSS */\n" . $dynamic_css;
			}

			wp_add_inline_style( 'justshoppe-pro-woocommerce', $dynamic_css );
		}
	}

	/**
	 * Enqueue frontend JS.
	 */
	public function enqueue_js() {
		parent::enqueue_js();

		if ( ! wp_script_is( 'justshoppe-pro-woocommerce', 'enqueued' ) ) {
			// WooCommerce JS
			wp_enqueue_script( 'justshoppe-pro-woocommerce', trailingslashit( JUSTSHOPPE_PRO_JS_URL ) . 'compatibilities/pro-woocommerce' . JUSTSHOPPE_ASSETS_SUFFIX . '.js', array( 'jquery', 'flexslider', 'wc-add-to-cart-variation' ), JUSTSHOPPE_PRO_VERSION, true );
		}
	}
}