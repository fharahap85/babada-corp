<?php
/**
 * Migrate to 1.2.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

class Justshoppe_Pro_Migrate_1_2_0 {

	/**
	 * Singleton instance
	 *
	 * @var Justshoppe_Pro_Migrate_1_2_0
	 */
	private static $instance;

	/**
	 * ====================================================
	 * Singleton & constructor functions
	 * ====================================================
	 */

	/**
	 * Get singleton instance.
	 *
	 * @return Justshoppe_Pro_Migrate_1_2_0
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Class constructor
	 */
	protected function __construct() {
		$this->migrate_header_vertical_bar_full_screen_position();
	}

	/**
	 * ====================================================
	 * Private functions
	 * ====================================================
	 */

	/**
	 * Split header vertical bar position
	 *
	 * The previous implementation:
	 * - Full screen mode doesn't have dedicated option for "position", and only use the "header_vertical_bar_position" option.
	 *
	 * The new implementation:
	 * - Full screen mode has dedicated option for "position", named "header_vertical_bar_full_screen_position".
	 */
	private function migrate_header_vertical_bar_full_screen_position() {
		// Copy value from "header_vertical_bar_position" option. 
		set_theme_mod( 'header_vertical_bar_full_screen_position', get_theme_mod( 'header_vertical_bar_position' ) );
		
		// If "header_vertical_bar_position" is set to "center", change to "left".
		if ( 'center' === get_theme_mod( 'header_vertical_bar_position' ) ) {
			set_theme_mod( 'header_vertical_bar_position', 'left' );
		}
	}
}

Justshoppe_Pro_Migrate_1_2_0::instance();