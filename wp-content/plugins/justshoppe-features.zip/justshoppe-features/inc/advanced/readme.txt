=== Justshoppe Pro ===
Contributors: justshoppewp
Tags: 
Stable tag: 1.2.0
Requires at least: 4.5
Tested up to: 5.4
Requires PHP: 5.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Premium add-on for the Justshoppe WordPress Theme, learn more at https://justshoppewp.com/pro/

== Description ==

Premium add-on for the Justshoppe WordPress Theme, learn more at https://justshoppewp.com/pro/

== Changelog ==

Changelog are available on changelog.txt

== Credits ==

Translation contributors:

- French - [Bruno Tritsch](https://wp-traduction.com/).

== Copyright ==

Additional UI icons (svg icons) are customly designed for Justshoppe WordPress Theme by David Rozando (Justshoppe WordPress Theme team)

Justshoppe Pro bundles the following third-party resources:

Pace (Automatic page load progress bar)
License: MIT
Source: https://github.com/HubSpot/pace

Tiny Slider
License: MIT
Source: https://github.com/ganlanyuan/tiny-slider

Select2
License: MIT
Source: https://github.com/select2/select2

jQuery Repeater
License: MIT
Source: https://github.com/DubFriend/jquery.repeater