<?php
/**
 * WooCommerce quick view popup template.
 *
 * @package Justshoppe
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

wp_enqueue_script( 'flexslider' );
wp_enqueue_script( 'wc-add-to-cart-variation' );
?>
<div id="product-quick-view" class="justshoppe-product-quick-view justshoppe-popup">
	<div class="justshoppe-popup-background justshoppe-popup-close">
		<?php Justshoppe_Helper_CSS_Spinner::render( 'ball-clip-rotate' ); ?>
	</div>

	<div class="justshoppe-product-quick-view-box justshoppe-popup-content">
		<div class="justshoppe-product-quick-view-content woocommerce"><?php // Populated via Javascript ?></div>

		<button class="justshoppe-popup-close-icon justshoppe-popup-close justshoppe-toggle"><?php justshoppe_icon( 'close' ); ?></button>
	</div>
</div>