<?php
/**
 * Header contact template.
 *
 * Passed variables:
 *
 * @type string $slug Header element slug.
 *
 * @package Justshoppe
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

$items = justshoppe_get_theme_mod( 'header_contact_items', array() );

if ( empty( $items ) ) {
	return;
}

?>
<ul class="<?php echo esc_attr( 'justshoppe-header-' . $slug ); ?> justshoppe-header-menu menu">
	<?php foreach ( $items as $item ) : ?>
		<?php
		$title = justshoppe_get_theme_mod( 'header_contact_' . $item . '_title' );
		$text = justshoppe_get_theme_mod( 'header_contact_' . $item . '_text' );
		$url = justshoppe_get_theme_mod( 'header_contact_' . $item . '_url' );
		?>
		<li class="menu-item">
			<<?php echo ( ! empty( $url ) ) ? 'a href="' . esc_url( $url ) . '"' : 'span'; ?>>
				<?php justshoppe_icon( $item, array( 'class' => 'justshoppe-menu-icon' ) ); ?>
				<?php if ( '' !== trim( $title . $text ) ) : ?>
					<span class="justshoppe-header-contact-item-content">
						<?php if ( 'large' === justshoppe_get_theme_mod( 'header_contact_style' ) ) : ?>
							<span class="justshoppe-header-contact-item-title"><?php echo $title; // WPCS: XSS OK. ?></span>
						<?php endif; ?>
						<span class="justshoppe-header-contact-item-text"><?php echo $text; // WPCS: XSS OK. ?></span>
					</span>
				<?php endif; ?>
			</<?php echo ( ! empty( $url ) ) ? 'a' : 'span'; ?>>
		</li>
	<?php endforeach; ?>
</ul>