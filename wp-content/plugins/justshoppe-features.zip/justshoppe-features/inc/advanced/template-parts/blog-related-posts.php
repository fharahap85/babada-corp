<?php
/**
 * Blog Related Posts template.
 *
 * @package Justshoppe
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

$thumbnail_display = justshoppe_get_theme_mod( 'blog_related_posts_thumbnail_display' );
$meta_display = justshoppe_get_theme_mod( 'blog_related_posts_meta_display' );
$columns = justshoppe_get_theme_mod( 'blog_related_posts_columns' );
?>
<div class="justshoppe-related-posts">
	<?php if ( '' !== $heading = trim( justshoppe_get_theme_mod( 'blog_related_posts_heading_text' ) ) ) : ?>
		<h2 class="justshoppe-related-posts-heading small-title"><?php echo $heading; // WPCS: XSS OK ?></h2>
	<?php endif; ?>
	<ul class="justshoppe-related-posts-list <?php echo esc_attr( 'justshoppe-related-posts-thumbnail-display-' . $thumbnail_display ); ?> <?php echo esc_attr( 'justshoppe-related-posts-columns-' . $columns ); ?>">
		<?php while ( have_posts() ) : the_post(); ?>
			<li class="justshoppe-related-post">
				<?php if ( '' !== $thumbnail_display && has_post_thumbnail() ) : ?>
					<a href="<?php the_permalink(); ?>" class="justshoppe-related-post-thumbnail">
						<?php echo get_the_post_thumbnail( null, justshoppe_get_theme_mod( 'blog_related_posts_thumbnail_size' ) ); ?>
					</a>
				<?php endif; ?>
				<div class="justshoppe-related-post-text">
					<h3 class="justshoppe-related-post-title">
						<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
					</h3>
					<?php if ( '' !== $meta_display ) : ?>
						<div class="justshoppe-related-post-meta entry-meta">
							<?php switch ( $meta_display ) {
								case 'date':
									echo esc_html( get_the_date( '') );
									break;
								
								case 'categories':
									$cat_objects = get_the_category();
									$cat_names = wp_list_pluck( $cat_objects, 'name' );

									echo esc_html( implode( esc_html_x( ', ', 'terms list separator', 'justshoppe-features' ), $cat_names ) );
									break;
							}
							?>
						</div>
					<?php endif; ?>
				</div>
			</li>
		<?php endwhile; ?>
	</ul>
</div>