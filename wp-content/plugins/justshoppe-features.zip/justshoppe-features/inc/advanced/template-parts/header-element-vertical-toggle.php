<?php
/**
 * Header vertical toggle template.
 *
 * Passed variables:
 *
 * @type string $slug Header element slug.
 *
 * @package Justshoppe
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

if ( 'fixed' === justshoppe_get_theme_mod( 'header_vertical_bar_display' ) ) {
	return;
}

?>
<div class="<?php echo esc_attr( 'justshoppe-header-' . $slug ); ?>">
	<button class="justshoppe-popup-toggle justshoppe-toggle" data-target="vertical-header">
		<?php justshoppe_icon( 'menu', array( 'class' => 'justshoppe-menu-icon' ) ); ?>
		<span class="screen-reader-text"><?php esc_html_e( 'Vertical Header', 'justshoppe-features' ); ?></span>
	</button>
</div>