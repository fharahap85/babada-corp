<?php
/**
 * Vertical header template.
 *
 * @package Justshoppe
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

$elements = array();
$count = 0;
$rows = array( 'top', 'middle', 'bottom' );

foreach ( $rows as $row ) {
	$elements[ $row ] = justshoppe_get_theme_mod( 'header_elements_vertical_' . $row, array() );
	$count += count( $elements[ $row ] );
}

if ( 1 > $count ) {
	return;
}

$display = justshoppe_get_theme_mod( 'header_vertical_bar_display' );
?>
<div id="vertical-header" class="justshoppe-header-vertical <?php echo esc_attr( implode( ' ', apply_filters( 'justshoppe/frontend/header_vertical_classes', array() ) ) ); ?> justshoppe-header" itemscope itemtype="https://schema.org/WPHeader">
	<?php if ( 'fixed' !== $display ) : ?>
		<div class="justshoppe-popup-background justshoppe-popup-close"></div>
	<?php endif; ?>

	<div class="justshoppe-header-vertical-bar justshoppe-header-section-vertical <?php echo esc_attr( 'fixed' !== $display ? 'justshoppe-popup-content' : '' ); ?>">
		<div class="justshoppe-header-section-vertical-column <?php echo esc_attr( ( 0 < count( $elements['middle'] ) ) ? 'justshoppe-header-section-vertical-column-with-middle' : '' ); ?>">
			<?php foreach ( $rows as $row ) : ?>
				<?php
				// Skip middle column if it's empty
				if ( 'middle' === $row && 0 === count( $elements[ $row ] ) ) {
					continue;
				}
				?>
				<div class="<?php echo esc_attr( 'justshoppe-header-vertical-bar-' . $row ); ?> justshoppe-header-section-vertical-row">
					<?php foreach ( $elements[ $row ] as $element ) justshoppe_header_element( $element ); ?>
				</div>
			<?php endforeach; ?>
		</div>

		<?php if ( 'full-screen' === $display ) : ?>
			<button class="justshoppe-popup-close-icon justshoppe-popup-close justshoppe-toggle"><?php justshoppe_icon( 'close' ); ?></button>
		<?php endif; ?>
	</div>
</div>