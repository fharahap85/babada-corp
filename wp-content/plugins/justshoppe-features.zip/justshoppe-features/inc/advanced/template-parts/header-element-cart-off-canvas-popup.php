<?php
/**
 * Header shopping cart off canvas panel template.
 *
 * @package Justshoppe
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

// Dropdown
ob_start();
the_widget( 'WC_Widget_Cart', array(
	'title'         => '',
	'hide_if_empty' => false,
) );
$dropdown_html = ob_get_clean();
if ( ! empty( $dropdown_html ) ) {
	$is_dropdown = true;
} else {
	$is_dropdown = false;
}

if ( ! $is_dropdown ) {
	return;
}

?>
<div id="off-canvas-cart" class="justshoppe-off-canvas-cart justshoppe-popup">
	<div class="justshoppe-popup-background justshoppe-popup-close">
		<button class="justshoppe-popup-close-icon justshoppe-popup-close justshoppe-toggle"><?php justshoppe_icon( 'close' ); ?></button>
	</div>
	<div class="justshoppe-off-canvas-cart-bar justshoppe-popup-content">
		<h2 class="screen-reader-text"><?php esc_html_e( 'Shopping Cart', 'justshoppe-features' ); ?></h2>

		<?php echo $dropdown_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</div>
</div>