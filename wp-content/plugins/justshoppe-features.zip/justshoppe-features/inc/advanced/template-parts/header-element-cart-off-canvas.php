<?php
/**
 * Header shopping cart off canvas template.
 *
 * Passed variables:
 *
 * @type string $slug Header element slug.
 *
 * @package Justshoppe
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

$cart = WC()->cart;

if ( empty( $cart ) ) {
	return;
}

// Dropdown
ob_start();
the_widget( 'WC_Widget_Cart', array(
	'title'         => '',
	'hide_if_empty' => false,
) );
$dropdown_html = ob_get_clean();
if ( ! empty( $dropdown_html ) ) {
	$is_dropdown = true;
} else {
	$is_dropdown = false;
}

// Amount
$amount_position = justshoppe_get_theme_mod( 'header_cart_amount', '' );
$amount_html = '';
if ( '' !== $amount_position ) {
	$classes = array();
	$hide_devices = array_diff( array( 'desktop', 'tablet', 'mobile' ), justshoppe_get_theme_mod( 'header_cart_amount_visibility' ) );
	foreach( $hide_devices as $device ) {
		$classes[] = esc_attr( 'justshoppe-hide-on-' . $device );
	}

	ob_start();
	?>
	<span class="cart-amount <?php echo esc_attr( implode( ' ', $classes ) ); ?>"><?php echo $cart->get_cart_total(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
	<?php
	$amount_html = ob_get_clean();
}
?>
<div class="<?php echo esc_attr( 'justshoppe-header-' . $slug ); ?> justshoppe-header-cart menu <?php echo $is_dropdown ? esc_attr( 'justshoppe-toggle-menu' ) : ''; ?>">
	<div class="menu-item">
		<?php if ( $is_dropdown ) : ?>
			<button class="cart-link justshoppe-menu-item-link justshoppe-popup-toggle justshoppe-toggle" data-target="off-canvas-cart" aria-expanded="false">
		<?php else: ?>
			<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="cart-link justshoppe-menu-item-link">
		<?php endif; ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Shopping Cart', 'justshoppe-features' ); ?></span>

				<?php if ( 'before' === $amount_position ) {
					echo $amount_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				} ?>

				<span class="cart-icon">
					<?php justshoppe_icon( 'cart', array( 'class' => 'justshoppe-menu-icon' ) ); ?>
				</span>
				
				<span class="cart-count" data-count="<?php echo esc_attr( $cart->get_cart_contents_count() ); ?>"><?php echo $cart->get_cart_contents_count(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>

				<?php if ( 'after' === $amount_position ) {
					echo $amount_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				} ?>
		<?php if ( $is_dropdown ) : ?>
			</button>
		<?php else: ?>
			</a>
		<?php endif; ?>
	</div>
</div>