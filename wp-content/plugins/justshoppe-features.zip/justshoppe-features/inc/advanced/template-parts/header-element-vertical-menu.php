<?php
/**
 * Header vertical menu template.
 *
 * Passed variables:
 *
 * @type string $slug Header element slug.
 *
 * @package Justshoppe
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

?>
<nav class="<?php echo esc_attr( 'justshoppe-header-' . $slug ); ?> justshoppe-header-menu site-navigation" role="navigation" itemscope itemtype="https://schema.org/SiteNavigationElement" aria-label="<?php esc_attr_e( 'Vertical Header Menu', 'justshoppe-features' ); ?>">
	<?php wp_nav_menu( array(
		'theme_location' => 'header-' . $slug,
		'menu_class'     => 'menu justshoppe-toggle-menu',
		'container'      => false,
		'fallback_cb'    => 'justshoppe_unassigned_menu',
	) ); ?>
</nav>