<?php
/**
 * WooCommerce off-canvas filters popup template.
 *
 * @package Justshoppe
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

$classes = array(
	'widget_title_alignment' => esc_attr( 'justshoppe-widget-title-alignment-' . justshoppe_get_theme_mod( 'woocommerce_off_canvas_filters_widget_title_alignment' ) ),
	'widget_title_decoration' => esc_attr( 'justshoppe-widget-title-decoration-' . justshoppe_get_theme_mod( 'woocommerce_off_canvas_filters_widget_title_decoration' ) ),
);
?>
<div id="products-off-canvas-filters" class="justshoppe-products-off-canvas-filters <?php echo esc_attr( 'justshoppe-products-off-canvas-filters-position-' . justshoppe_get_theme_mod( 'woocommerce_off_canvas_filters_position' ) ); ?> justshoppe-popup">
	<div class="justshoppe-popup-background justshoppe-popup-close"></div>

	<div class="justshoppe-products-off-canvas-filters-bar <?php echo esc_attr( implode( ' ', $classes ) ); ?> justshoppe-popup-content woocommerce">
		<?php if ( is_active_sidebar( 'justshoppe-woocommerce-off-canvas-filters' ) ) {
			dynamic_sidebar( 'justshoppe-woocommerce-off-canvas-filters' );
		} ?>
	</div>
</div>