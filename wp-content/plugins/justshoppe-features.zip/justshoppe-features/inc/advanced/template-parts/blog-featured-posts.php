<?php
/**
 * Blog Featured Posts template.
 *
 * @package Justshoppe
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

$layout = justshoppe_get_theme_mod( 'blog_featured_posts_layout' );
$meta_1 = justshoppe_get_theme_mod( 'blog_featured_posts_meta_1' );
$meta_2 = justshoppe_get_theme_mod( 'blog_featured_posts_meta_2' );

$classes = array( 'justshoppe-featured-posts', 'justshoppe-featured-posts-' . $layout );

// Grid
if ( 0 === strpos( $layout, 'grid-' ) ) {
	$classes[] = 'justshoppe-featured-posts-grid';
}

// Slider & Carousel
if ( in_array( $layout, array( 'slider', 'carousel' ) ) ) {
	$classes[] = 'justshoppe-featured-posts-tiny-slider';
}

// Backround
if ( 'slider' !== $layout ) {
	$bg = justshoppe_get_theme_mod( 'blog_featured_posts_content_bg_mode' );
} else {
	$bg = 'solid';
}
$classes[] = 'justshoppe-featured-posts-content-bg-mode--' . $bg;

?>
<div id="justshoppe-featured-posts" class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
	<ul class="justshoppe-featured-posts-list">
		<?php $i = 0; while ( have_posts() ) : the_post(); ?>
			<li class="justshoppe-featured-post <?php echo esc_attr( 'justshoppe-featured-post-' . ( $i + 1 ) ); ?>">
				<div class="justshoppe-featured-post-inner">
					<?php printf(
						/* translators: %1$s: HTML tag (a or div), %2$s: href attribute (if it's a link), %3$s: image URL. */
						'<%1$s %2$s class="justshoppe-featured-post-background" style="background-image: url(%3$s)"></%1$s>',
						intval( justshoppe_get_theme_mod( 'blog_featured_posts_image_link' ) ) ? 'a' : 'div',
						intval( justshoppe_get_theme_mod( 'blog_featured_posts_image_link' ) ) ? 'href="' . esc_url( get_permalink() ) . '"' : '',
						esc_attr( get_the_post_thumbnail_url( null, 'full' ) )
					); ?>

					<div class="justshoppe-featured-post-text <?php echo esc_attr( 'justshoppe-text-align-' . justshoppe_get_theme_mod( 'blog_featured_posts_content_alignment' ) ); ?>">
						<?php if ( '' !== $meta_1 ) : ?>
							<div class="justshoppe-featured-post-meta-1 justshoppe-featured-post-meta entry-meta"><?php justshoppe_entry_meta_element( $meta_1 ); ?></div>
						<?php endif; ?>

						<?php
						$title_class = 'title';
						if ( 'slider' !== $layout ) {
							$title_class = 'small-title';
						}
						?>
						<h2 class="justshoppe-featured-post-title <?php echo esc_attr( $title_class ); ?>"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>

						<?php if ( '' !== $meta_2 ) : ?>
							<div class="justshoppe-featured-post-meta-2 justshoppe-featured-post-meta entry-meta"><?php justshoppe_entry_meta_element( $meta_2 ); ?></div>
						<?php endif; ?>
					</div>
				</div>
			</li>
		<?php $i++; endwhile; ?>
	</ul>

	<?php if ( in_array( $layout, array( 'slider', 'carousel' ) ) ) : ?>
		<div class="justshoppe-featured-posts-navigation">
			<button class="justshoppe-featured-posts-navigation-button justshoppe-featured-posts-navigation-button-prev"><?php echo justshoppe_icon( 'chevron-left' ); ?></button>
			<button class="justshoppe-featured-posts-navigation-button justshoppe-featured-posts-navigation-button-next"><?php echo justshoppe_icon( 'chevron-right' ); ?></button>
		</div>
	<?php endif; ?>
</div>