<?php
/**
 * WooCommerce off-canvas filters button template.
 *
 * @package Justshoppe
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) exit;

$text = justshoppe_get_theme_mod( 'woocommerce_off_canvas_filters_button_text' );
?>
<div class="justshoppe-products-off-canvas-filters-button-wrapper">
	<button class="justshoppe-products-off-canvas-filters-button justshoppe-popup-toggle" data-target="products-off-canvas-filters">
		<?php justshoppe_icon( 'filter' ); ?><?php echo esc_html( $text ? '&nbsp;&nbsp;' . $text : '' ); ?>
	</button>
</div>