<?php
if ( ! defined( 'ABSPATH' ) ) exit;


/*-----------------------------------------------------------------------------------*/
/* Initiating shortcodes.
/*-----------------------------------------------------------------------------------*/


include JUSTSHOPPE_FW_ROOT . '/inc/shortcodes/social.php';
//Include Hero sc
if ( '1' === $justshoppe_theme_components['ttnew_hero_sc'] ) {
	include JUSTSHOPPE_FW_ROOT . '/inc/shortcodes/ttnew-hero-sc.php';
}
if ( '1' === $justshoppe_theme_components['ttnew_hero_sc'] ) {
	add_shortcode( 'justshoppe_hero', 'justshoppe_hero_sc' );
}
